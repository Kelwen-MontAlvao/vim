import axios from 'axios';

const PEXELS_API_KEY = 'RTasT3vquHM7zuALTB85W5zZtBTEZHgw5Siu8qTzhFrTrEqDmPHb0q6z';

const api = axios.create({
  baseURL: 'https://api.pexels.com/v1/',
  headers: {
    Authorization: PEXELS_API_KEY,
  },
});

export const searchPhotos = async (query) => {
  try {
    const response = await api.get('search', {
      params: { query, per_page: 20 },
    });
    return response.data.photos;
  } catch (error) {
    console.error(error);
    return [];
  }
};
