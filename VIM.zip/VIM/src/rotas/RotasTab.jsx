import {createBottomTabNavigator} from '@react-navigation/bottom-tabs'
import {Home} from '../telas/Home'
import {Sobre} from '../telas/Sobre'
import {Perfil} from '../telas/Perfil'
import {Configuracoes} from '../telas/Configuracoes'
import {Exercicio} from '../telas/Exercicio'
import {Dicionario} from '../telas/Dicionario'
import {Contatenos} from '../telas/Contatenos'
import {Sugestao} from '../telas/Sugestao'

//Telas de Estudos
import {Estudos} from '../telas/Estudos/Estudos'
import {LetrasVagalume} from '../telas/Estudos/LetrasVagalume'
import {Poemas} from '../telas/Estudos/Poemas'
import {MeusPoemas} from '../telas/Estudos/MeusPoemas'
import {Gramatica} from '../telas/Estudos/Gramatica'
import {Videoaulas} from '../telas/Estudos/Videoaulas'
import {Exercicios} from '../telas/Estudos/Exercicios'
import {CriarExercicio} from '../telas/Estudos/CriarExercicio'

//Telas de gêneros musicais
import {Genero1} from '../telas/generos/Genero1'
import {Genero2} from '../telas/generos/Genero2'
import {Genero3} from '../telas/generos/Genero3'
import {Genero4} from '../telas/generos/Genero4'
import {Genero5} from '../telas/generos/Genero5'

//musicas iniciantes
import {Musica} from '../telas/Musica'
import {Musica2} from '../telas/Musica2'
import {Musica3} from '../telas/Musica3'
import {Musica4} from '../telas/Musica4'

//Musicas Rock
import {Rock1} from '../telas/generos/Rock/Rock1'
import {Rock2} from '../telas/generos/Rock/Rock2'
import {Rock3} from '../telas/generos/Rock/Rock3'
import {Rock4} from '../telas/generos/Rock/Rock4'
import {Rock5} from '../telas/generos/Rock/Rock5'
import {Rock6} from '../telas/generos/Rock/Rock6'
import {Rock7} from '../telas/generos/Rock/Rock7'

//Musicas Pop
import {Pop1} from '../telas/generos/Pop/Pop1'
import {Pop2} from '../telas/generos/Pop/Pop2'
import {Pop3} from '../telas/generos/Pop/Pop3'
import {Pop4} from '../telas/generos/Pop/Pop4'
import {Pop5} from '../telas/generos/Pop/Pop5'
import {Pop6} from '../telas/generos/Pop/Pop6'
import {Pop7} from '../telas/generos/Pop/Pop7'

//Musicas Pop
import {Rap1} from '../telas/generos/Rap/Rap1'
import {Rap2} from '../telas/generos/Rap/Rap2'
import {Rap3} from '../telas/generos/Rap/Rap3'
import {Rap4} from '../telas/generos/Rap/Rap4'
import {Rap5} from '../telas/generos/Rap/Rap5'
import {Rap6} from '../telas/generos/Rap/Rap6'
import {Rap7} from '../telas/generos/Rap/Rap7'

//Musicas Indie
import {Indie1} from '../telas/generos/Indie/Indie1'
import {Indie2} from '../telas/generos/Indie/Indie2'
import {Indie3} from '../telas/generos/Indie/Indie3'
import {Indie4} from '../telas/generos/Indie/Indie4'
import {Indie5} from '../telas/generos/Indie/Indie5'
import {Indie6} from '../telas/generos/Indie/Indie6'
import {Indie7} from '../telas/generos/Indie/Indie7'

//Musicas Blues
import {Blues1} from '../telas/generos/Blues/Blues1'
import {Blues2} from '../telas/generos/Blues/Blues2'
import {Blues3} from '../telas/generos/Blues/Blues3'
import {Blues4} from '../telas/generos/Blues/Blues4'
import {Blues5} from '../telas/generos/Blues/Blues5'
import {Blues6} from '../telas/generos/Blues/Blues6'
import {Blues7} from '../telas/generos/Blues/Blues7'

import { MaterialIcons } from '@expo/vector-icons'

const {Navigator, Screen} = createBottomTabNavigator()

export function RotasTab(){
    return(

        <Navigator 
            screenOptions={{
                headerShown: false,
                tabBarShowLabel: false,
                tabBarActiveTintColor: '#9dc3ff',
                tabBarInactiveTintColor: '#2d7de6',
                tabBarStyle: {
                    backgroundColor: '#000',
                    height: 55,
                    borderTopWidth: 2,
                    borderColor: '#2d7de6'
                },
                }}
        >

            <Screen 
                name='sobre'
                component={Sobre}
                options={{
                    tabBarIcon: ({size, color}) => (
                        <MaterialIcons name="bookmarks" size={size} color={color} />
                    )
                }}
            />

            <Screen 
                name='home'
                component={Home}
                options={{
                    tabBarIcon: ({size, color}) => (
                        <MaterialIcons name="home" size={size} color={color} />
                    )
                }}
            />

            <Screen
                name='Dicionario'
                component={Dicionario}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="book" size={size} color={color} />
                    ),
                }}
            />

            <Screen 
                name='Perfil'
                component={Perfil}
                options={{
                    tabBarIcon: ({size, color}) => (
                        <MaterialIcons name="person" size={size} color={color} />
                    )
                }}
            />
            <Screen
                name='Configuracoes'
                component={Configuracoes}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Contatenos'
                component={Contatenos}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Sugestao'
                component={Sugestao}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
           

    {
        //--------------------------------Página de Estudos---------------------------------------
    }
            <Screen
                name='Estudos'
                component={Estudos}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='LetrasVagalume'
                component={LetrasVagalume}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Poemas'
                component={Poemas}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='MeusPoemas'
                component={MeusPoemas}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='Gramatica'
                component={Gramatica}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Videoaulas'
                component={Videoaulas}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Exercicios'
                component={Exercicios}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='CriarExercicio'
                component={CriarExercicio}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />


    {
        //--------------------------------Página de Gêneros e musicas---------------------------------------
    }
            <Screen
                name='Genero1'
                component={Genero1}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='Genero2'
                component={Genero2}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='Genero3'
                component={Genero3}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='Genero4'
                component={Genero4}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='Genero5'
                component={Genero5}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='Musica'
                component={Musica}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='Musica2'
                component={Musica2}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='Musica3'
                component={Musica3}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='Musica4'
                component={Musica4}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='Exercicio'
                component={Exercicio}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
{
            //--------------------------------Páginas de Rocks---------------------------------------
}
            <Screen
                name='Rock1'
                component={Rock1}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='Rock2'
                component={Rock2}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='Rock3'
                component={Rock3}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

            <Screen
                name='Rock4'
                component={Rock4}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Rock5'
                component={Rock5}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Rock6'
                component={Rock6}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Rock7'
                component={Rock7}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

{
            //--------------------------------Páginas de Pop---------------------------------------
}

            <Screen
                name='Pop1'
                component={Pop1}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Pop2'
                component={Pop2}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Pop3'
                component={Pop3}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Pop4'
                component={Pop4}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Pop5'
                component={Pop5}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Pop6'
                component={Pop6}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Pop7'
                component={Pop7}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
                
{
            //--------------------------------Páginas de Rap ---------------------------------------
}

            <Screen
                name='Rap1'
                component={Rap1}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Rap2'
                component={Rap2}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Rap3'
                component={Rap3}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Rap4'
                component={Rap4}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
             <Screen
                name='Rap5'
                component={Rap5}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
             <Screen
                name='Rap6'
                component={Rap6}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
             <Screen
                name='Rap7'
                component={Rap7}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
                
                         
{
            //--------------------------------Páginas de indie ---------------------------------------
}

            <Screen
                name='Indie1'
                component={Indie1}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Indie2'
                component={Indie2}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Indie3'
                component={Indie3}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Indie4'
                component={Indie4}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Indie5'
                component={Indie5}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Indie6'
                component={Indie6}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Indie7'
                component={Indie7}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />

{
//--------------------------------Páginas de blues ---------------------------------------
}

            <Screen
                name='Blues1'
                component={Blues1}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Blues2'
                component={Blues2}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Blues3'
                component={Blues3}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Blues4'
                component={Blues4}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Blues5'
                component={Blues5}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Blues6'
                component={Blues6}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />
            <Screen
                name='Blues7'
                component={Blues7}
                options={{
                    tabBarIcon: ({ size, color }) => (
                        <MaterialIcons name="settings" size={size} color={color} />
                    ),
            tabBarButton: () => null, // Não renderiza um botão de navegação para esta aba
                }}
            />



        </Navigator>
    )
}