import {NavigationContainer} from '@react-navigation/native'
import {createNativeStackNavigator} from '@react-navigation/native-stack'
import {RotasTab} from '../rotas/RotasTab'
import {Login} from '../telas/Login'
import {Cadastro} from '../telas/Cadastro'


const {Navigator, Screen} = createNativeStackNavigator()

export function RotasStack(){
    return(
        <NavigationContainer>
            <Navigator screenOptions={{ headerShown: false }} >


                <Screen 
                    name='Login'
                    component={Login}
                />

                <Screen 
                    name='Cadastro'
                    component={Cadastro}
                />
                
                <Screen 
                    name='Inicial'
                    component={RotasTab}
                />

                
            </Navigator>
        </NavigationContainer>
    )
}
