import React from 'react';
import { View, Text, Image, ScrollView, StyleSheet } from 'react-native';
import { Cabecalho } from '../componentes/Cabecalho';


export function Vazio() {
  return (
    <>
      <Cabecalho />

      <View style={estilos.conteinerTitulo}>
        <Text style={estilos.titulo}>Vazio:</Text>
      </View>

      <ScrollView 
        style={estilos.scrollContent}
        vertical={true}
      >
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
 
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center",
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
  },
  scrollContainer: {
    alignItems: 'center',
  },
});

export default Vazio;
