import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../componentes/Cabecalho';
import { Botao } from '../componentes/Botao';
import { BotaoVoltar } from '../componentes/Voltar';

export function Musica3() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'P5ZJui3aPoQ'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='home'/>
        <Text style={estilos.titulo}>
          Kansas - Carry Wayward Son
        </Text>

        <Text style={estilos.letraMusica}>

        <Botao palavra='Carry on'
               destino='Exercicio' 
               imagem='Carry on' 
               palavrasCorretas={['continue', 'continuar']}
               voltar={'Musica3'}/>,my
               
        <Botao palavra='wayward'
               destino='Exercicio' 
               imagem='rebellious son'
               palavrasCorretas={['desobediente', 'rebelde']}
               contexto={"Quando alguém não escuta os pais, não obedece"}
               voltar={'Musica3'}/>son{"\n"}
        There'll be peace when you are done {"\n"}

        <Botao palavra='Lay'
               destino='Exercicio' 
               imagem='bed'
               palavrasCorretas={['deitar','deitando']}
               contexto={"Quando vamos dormir"}
               voltar={'Musica3'}/>your

        <Botao palavra='weary'
               destino='Exercicio' 
               imagem='weary'
               palavrasCorretas={['Cansado', 'Cansada']}
               voltar={'Musica3'}/> head to rest{"\n"}

        Don't you <Botao palavra='cry'
                         destino='Exercicio' 
                         imagem='cry'
                         palavrasCorretas={['Chorar', 'chora']}
                         voltar={'Musica3'}/>no more{"\n"}{"\n"}

        Once I <Botao palavra='rose'
                    destino='Exercicio' 
                    imagem='overcome'
                    palavrasCorretas={['Superar', 'superei']}
                    contexto={"Quando alguém passa por obstáculos difíceis, sendo melhor do que era"}
                    voltar={'Musica3'}/>above the
                    
             <Botao palavra='noise'
                    destino='Exercicio' 
                    imagem='too much noise'
                    palavrasCorretas={['barulho']}
                    contexto='Diversos sons altos'
                    voltar={'Musica3'}/> and

             <Botao palavra='confusion'
                    destino='Exercicio' 
                    imagem='confusion'
                    palavrasCorretas={['confusão']}
                    voltar={'Musica3'}/>{"\n"}

        Just to get a <Botao palavra='glimpse'
                             destino='Exercicio' 
                             imagem='sunset'
                             palavrasCorretas={['vislumbre' , 'vislumbrar']}
                             contexto={"Quando você tem reflexo de uma boa paisagem, quando voce observa algo bonito, verbo"}
                             voltar={'Musica3'}/>beyond this illusion{"\n"}

        I was<Botao palavra='soaring'
                     destino='Exercicio' 
                     imagem='going up to the stairs'
                     palavrasCorretas={['subindo']}
                     contexto={"Uma ação que está acontecendo"}
                     voltar={'Musica3'}/> ever higher{"\n"}

        But I<Botao palavra='flew'
                     destino='Exercicio' 
                     imagem='plane'
                     palavrasCorretas={['voar' ,'voei']}
                     contexto={"Está no passado, relacionado a primeira pessoa"}
                     voltar={'Musica3'}/> too high{"\n"}{"\n"}

        Though my eyes could see, I still was a <Botao palavra='blind'
                                                       destino='Exercicio' 
                                                       imagem='blind man'
                                                       palavrasCorretas={['cego']}
                                                       voltar={'Musica3'}/>man{"\n"}

        Though my mind could think, I still was a <Botao palavra='mad'
                                                         destino='Exercicio' 
                                                         imagem='crazy man'
                                                         palavrasCorretas={['louco', 'doido', 'maluco']}
                                                         voltar={'Musica3'}/>man{"\n"}

        I hear the voices when I'm <Botao palavra='dreaming'
                                          destino='Exercicio' 
                                          imagem='dreaming'
                                          palavrasCorretas={['sonhando', 'sonhar']}
                                          contexto='Acontece quando está dormindo'
                                          voltar={'Musica3'}/>{"\n"}

        I can hear them <Botao palavra='say'
                         destino='Exercicio' 
                         imagem='tell'
                         palavrasCorretas={['dizer', 'falar']}
                         voltar={'Musica3'}/>{"\n"}{"\n"}

        <Botao palavra='Carry on'
               destino='Exercicio' 
               imagem='carry on'
               palavrasCorretas={['continue', 'continuar']}
               voltar={'Musica3'}/>,my 
               
        <Botao palavra='wayward'
               destino='Exercicio' 
               imagem='wayward'
               palavrasCorretas={['Desobediente', 'Rebelde']}
               voltar={'Musica3'}/>son{"\n"}

        There'll be peace when you are done{"\n"}

        <Botao palavra='lay'
               destino='Exercicio' 
               imagem='lay' 
               palavrasCorretas={['Deitar', 'Deitando']}
               voltar={'Musica3'}/> your 
               
               <Botao palavra='weary'
                      destino='Exercicio' 
                      imagem='weary'
                      palavrasCorretas={['Cansado', 'Cansada']}
                      voltar={'Musica3'}/> head to rest{"\n"}
        Don't you cry no more{"\n"}{"\n"}

        <Botao palavra='Masquerading'
               destino='Exercicio' 
               imagem='masquerading'
               palavrasCorretas={['disfarce', 'disfarçando', 'se disfarçando', 'se mascarando', 'mascarando']}
               voltar={'Musica3'}/> as a man with a 
              
       <Botao palavra='reason'
              destino='Exercicio' 
              imagem='reason'
              palavrasCorretas={['razão']}
              contexto='Palavra quando uma pessoa tem lógica'
              voltar={'Musica3'}/>{"\n"}

        My <Botao palavra='charade'
                  destino='Exercicio' 
                  imagem='question mark'
                  palavrasCorretas={['charada']}
                  contexto={"Uma pergunta com uma resposta que te faz pensar muito, muitas vezes que possui uma resposta icônica"}
                  voltar={'Musica3'}/> is the event of the 
                  
           <Botao palavra='season'
                  destino='Exercicio' 
                  imagem='season'
                  palavrasCorretas={['temporada', 'estações', 'estação']}
                  voltar={'Musica3'}/>{"\n"}

        And if I claim to be a <Botao palavra='wise'
                                      destino='Exercicio' 
                                      imagem='wise'
                                      palavrasCorretas={['sábio']}
                                      contexto={"Experiente, de mais idade"}
                                      voltar={'Musica3'}/> man, well{"\n"}

        It surely means that I don't know{"\n"}{"\n"}

        On a <Botao palavra='stormy'
                    destino='Exercicio' 
                    imagem='stormy'
                    palavrasCorretas={['Tempestade']}
                    voltar={'Musica3'}/> sea of moving emotion{"\n"}

        <Botao palavra='Tossed About'
               destino='Exercicio' 
               imagem='ship in the stormy'
               palavrasCorretas={['Jogando de um lado para o outro', 'Jogado sobre', 'Jogando para lá e para cá']}
               contexto={"Quando um navio entra em uma tempestade, o mar fica afetando ele de alguma forma"}
               voltar={'Musica3'}/>, I'm like a 
               
               
        <Botao palavra='ship'
               destino='Exercicio' 
               imagem='ship'
               palavrasCorretas={['Navio']}
               voltar={'Musica3'}/> on the ocean{"\n"}

        I set a course for <Botao palavra='wind'
                                  destino='Exercicio' 
                                  imagem='wind'
                                  palavrasCorretas={['Vento']}
                                  voltar={'Musica3'}/> of 
                                  
                           <Botao palavra='fortune'
                                  destino='Exercicio' 
                                  imagem='gold bars'
                                  palavrasCorretas={['Fortuna']}
                                  voltar={'Musica3'}/>{"\n"}

        But I <Botao palavra='hear'
                     destino='Exercicio' 
                     imagem='hear'
                     palavrasCorretas={['Escutar', 'Ouvir']}
                     voltar={'Musica3'}/> the voices say{"\n"}{"\n"}

        Carry on, my wayward son{"\n"}
        There'll be peace when you are done{"\n"}
        Lay your weary head to rest{"\n"}
        Don't you cry no more, no{"\n"}{"\n"}

        (Carry on) you will always remember{"\n"}
        (Carry on) nothing <Botao palavra='equals'
                                  destino='Exercicio' 
                                  imagem='same things'
                                  palavrasCorretas={['Igual']}
                                  contexto='Quando algo é totalmente parecido, semelhante.'
                                  voltar={'Musica3'}/> the splendor{"\n"}

        Now your life's no longer <Botao palavra='empty'
                                         destino='Exercicio' 
                                         imagem='empty cup'
                                         palavrasCorretas={['Vazio']}
                                         contexto={"O copo está?"}
                                         voltar={'Musica3'}/>{"\n"}

        But surely <Botao palavra='heaven'
                          destino='Exercicio' 
                          imagem='heaven'
                          palavrasCorretas={['Céu', 'Ceu', 'paraiso', 'paraíso']}
                          voltar={'Musica3'}/>waits for you{"\n"}{"\n"}

        Carry on, my wayward son{"\n"}
        There'll be peace when you are done{"\n"}
        Lay your weary head to rest{"\n"}
        (Don't you cry) don't you cry no more{"\n"}{"\n"}

        No more{"\n"}{"\n"}


        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Musica3;