import React, { useState } from 'react';
import { View, Text, Image, TextInput, ScrollView, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { auth } from '../../firebaseConfig';
import { createUserWithEmailAndPassword } from 'firebase/auth';

export function Cadastro() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const navegacao = useNavigation();

  const handleCadastro = async () => {
    if (!email || !senha) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos');
      return;
    }

    try {
      await createUserWithEmailAndPassword(auth, email, senha);
      Alert.alert('Sucesso', 'Cadastro realizado com sucesso!');
      navegacao.navigate('Login'); // Navega para a tela de login após o cadastro
    } catch (error) {
      console.error(error);
      Alert.alert('Erro', 'Não foi possível realizar o cadastro. Verifique suas informações.');
    }
  };

  return (
    <ScrollView contentContainerStyle={estilos.scrollContainer} style={estilos.scrollContent}>
      <View style={estilos.conteinerTitulo}>
        <Text style={estilos.titulo}>CADASTRAR-SE</Text>
      </View>
      <View style={estilos.formContainer}>
        <Image
          source={require('../../assets/logo.png')} 
          style={estilos.imagem}
        />
        <TextInput
          style={estilos.input}
          placeholder="Email"
          placeholderTextColor="#999"
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
        />
        <TextInput
          style={estilos.input}
          placeholder="Senha"
          placeholderTextColor="#999"
          secureTextEntry
          value={senha}
          onChangeText={setSenha}
        />
        <TouchableOpacity style={estilos.botao} onPress={handleCadastro}>
          <Text style={estilos.textoBotao}>Cadastrar</Text>  
        </TouchableOpacity>
        <TouchableOpacity style={estilos.link} onPress={() => navegacao.navigate('Login')}>
          <Text style={estilos.textoLink}>Já possuo conta</Text> 
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
    paddingVertical: 10,
    width: '100%',
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center",
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
  },
  scrollContainer: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  formContainer: {
    alignItems: 'center',
    width: '80%',
  },
  imagem: {
    width: 250,
    height: 250,
    marginVertical: 10,
  },
  input: {
    width: '100%',
    height: 40,
    backgroundColor: '#fff',
    marginBottom: 10,
    paddingHorizontal: 10,
    borderRadius: 5,
  },
  botao: {
    backgroundColor: '#2d7de6',
    borderRadius: 20,
    width: 250,
    marginTop: 20
  },
  textoBotao: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center"
  },
  link: {
    marginTop: 10,
  },
  textoLink: {
    color: 'rgba(255, 255, 255, 0.8)', // Meio transparente
    fontSize: 18,
    padding: 10,
    textAlign: "center",
    textDecorationLine: 'underline'
  }
});

export default Cadastro;
