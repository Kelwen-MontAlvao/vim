import React from 'react';
import { View, Text, ScrollView, StyleSheet, ImageBackground, TouchableOpacity, Button } from 'react-native';
import { Cabecalho } from '../../componentes/Cabecalho';
import { useNavigation } from '@react-navigation/native';
import { useMusic } from '../../MusicContext';

// Exemplo de dados de músicas com datas de lançamento e imagens
const postsMusicas = [
  { nome: 'Bad Habit', artista: 'Steve Lacy', dataLancamento: '2022-06-29', destino: 'Indie1', imagem: require('../../imgs/indie.jpg') },
  { nome: 'Money', artista: 'The Drums', dataLancamento: '2021-03-12', destino: 'Indie2', imagem: require('../../imgs/indie.jpg') },
  { nome: 'Heaven Knows I’m Miserable Now', artista: 'The Smiths', dataLancamento: '1984-05-07', destino: 'Indie3', imagem: require('../../imgs/indie.jpg') },
  { nome: 'The Rare Occasions', artista: 'Notion', dataLancamento: '2021-09-01', destino: 'Indie4', imagem: require('../../imgs/indie.jpg') },
  { nome: 'My Kind Of Woman', artista: 'Mac DeMarco', dataLancamento: '2012-10-16', destino: 'Indie5', imagem: require('../../imgs/indie.jpg') },
  { nome: 'Breezeblocks', artista: 'Alt-J', dataLancamento: '2012-05-18', destino: 'Indie6', imagem: require('../../imgs/indie.jpg') },
  { nome: 'Do I Wanna Know?', artista: 'Arctic Monkeys', dataLancamento: '2013-06-18', destino: 'Indie7', imagem: require('../../imgs/indie.jpg') }
];


export function Genero4() {
  const navegacao = useNavigation();
  const { saveMusic } = useMusic();

  const navegar = (rota) => {
    navegacao.navigate(rota);
  };

  return (
    <>
      <Cabecalho />

      <ImageBackground
        source={require('../../imgs/indie.jpg')}
        style={estilos.conteinerTitulo}
      >
        <Text style={estilos.titulo}>Gênero: Indie</Text>
      </ImageBackground>

      <ScrollView 
        style={estilos.scrollContent}
        contentContainerStyle={estilos.scrollContainer}
        vertical={true}
      >
        {postsMusicas.map((musica, index) => (
          <TouchableOpacity
            key={index}
            style={estilos.postContainer}
            onPress={() => navegar(musica.destino)}
          > 
            <View>
              <Text style={estilos.postTitulo}>{musica.nome}</Text>
              <Text style={estilos.postArtista}>Artista: {musica.artista}</Text>
              <Text style={estilos.postData}>Lançamento: {musica.dataLancamento}</Text>
              <Button title="Salvar Música" onPress={() => saveMusic(musica)} />
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#2d7de6',
    height: 200, // Altura da imagem de fundo
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center",
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
  },
  scrollContainer: {
    alignItems: 'center',
    paddingBottom: 20, // Espaçamento opcional na parte inferior do ScrollView
  },
  postContainer: {
    backgroundColor: '#e0f7fa', // Fundo azul claro
    width: '80%',
    padding: 20,
    marginVertical: 10,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
  },
  postTitulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  postArtista: {
    fontSize: 16,
    color: '#555',
  },
  postData: {
    fontSize: 14,
    color: '#777',
    marginBottom: 12
  },
});

export default Genero4;
