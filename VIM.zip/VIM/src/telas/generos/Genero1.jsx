import React from 'react';
import { View, Text, ScrollView, StyleSheet, ImageBackground, TouchableOpacity, Button } from 'react-native';
import { Cabecalho } from '../../componentes/Cabecalho';
import { useNavigation } from '@react-navigation/native';
import { useMusic } from '../../MusicContext';

const postsMusicas = [
  { nome: 'Sweet Child o Mine', artista: 'Guns n Roses', dataLancamento: '1987-09-17', destino: 'Rock1', imagem: require('../../imgs/rock.jpg') },
  { nome: 'Wish You Were Here', artista: 'Pink Floyd', dataLancamento: '1975-09-12', destino: 'Rock2', imagem: require('../../imgs/rock.jpg') },
  { nome: 'Wonderwall', artista: 'Oasis', dataLancamento: '1995-10-30', destino: 'Rock3', imagem: require('../../imgs/rock.jpg') },
  { nome: 'Drive', artista: 'Incubus', dataLancamento: '2001-10-09', destino: 'Rock4', imagem: require('../../imgs/rock.jpg') },
  { nome: 'Stairway To Heaven', artista: 'Led Zeppelin', dataLancamento: '1971-11-08', destino: 'Rock5', imagem: require('../../imgs/rock.jpg') },
  { nome: 'Smells Like Teen Spirit', artista: 'Nirvana', dataLancamento: '1991-09-10', destino: 'Rock6', imagem: require('../../imgs/rock.jpg') },
  { nome: 'Back in Black', artista: 'AC/DC', dataLancamento: '1980-07-25', destino: 'Rock7', imagem: require('../../imgs/rock.jpg') },
];



export function Genero1() {
  const navegacao = useNavigation();
  const { saveMusic } = useMusic();

  const navegar = (rota) => {
    navegacao.navigate(rota);
  };

  return (
    <>
      <Cabecalho />

      <ImageBackground
        source={require('../../imgs/rock.jpg')}
        style={estilos.conteinerTitulo}
      >
        <Text style={estilos.titulo}>Gênero: Rock</Text>
      </ImageBackground>

      <ScrollView
        style={estilos.scrollContent}
        contentContainerStyle={estilos.scrollContainer}
        vertical={true}
      >
        {postsMusicas.map((musica, index) => (
          <TouchableOpacity
            key={index}
            style={estilos.postContainer}
            onPress={() => navegar(musica.destino)}
          >
            <View>
              <Text style={estilos.postTitulo}>{musica.nome}</Text>
              <Text style={estilos.postArtista}>Artista: {musica.artista}</Text>
              <Text style={estilos.postData}>Lançamento: {musica.dataLancamento}</Text>
              <Button title="Salvar Música" onPress={() => saveMusic(musica)} />
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#2d7de6',
    height: 200,
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center",
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
  },
  scrollContainer: {
    alignItems: 'center',
    paddingBottom: 20,
  },
  postContainer: {
    backgroundColor: '#e0f7fa',
    width: '80%',
    padding: 20,
    marginVertical: 10,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
  },
  postTitulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  postArtista: {
    fontSize: 16,
    color: '#555',
  },
  postData: {
    fontSize: 14,
    color: '#777',
    marginBottom: 12
  },
});
