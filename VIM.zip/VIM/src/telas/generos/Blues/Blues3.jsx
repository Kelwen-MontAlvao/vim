import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Blues3() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'Nuanwn3v-2I'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero5'/>
        <Text style={estilos.titulo}>
        Bill withers - Ain't no sunshine
        </Text>

        <Text style={estilos.letraMusica}>  
        Ain't no <Botao palavra='sunshine' 
                 destino='Exercicio' 
                 imagem='sunshine' 
                 palavrasCorretas={['sol', 'raio', 'raio de sol']}  
                 contexto='' 
                 voltar={'Blues3'}/> when she's gone{'\n'}

It's not <Botao palavra='warm' 
                    destino='Exercicio' 
                    imagem='warm' 
                    palavrasCorretas={['quente', 'aconchegante']}  
                    contexto='' 
                    voltar={'Blues3'}/> when she's away{'\n'}

Ain't no <Botao palavra='sunshine' 
                 destino='Exercicio' 
                 imagem='sunshine' 
                 palavrasCorretas={['sol', 'raio', 'raio de sol']}  
                 contexto='' 
                 voltar={'Blues3'}/> when she's gone{'\n'}

And she's always gone too long{'\n'}

Anytime she goes away{'\n'}{'\n'}

Wonder this time where she's <Botao palavra='gone' 
                                 destino='Exercicio' 
                                 imagem='gone' 
                                 palavrasCorretas={['foi', 'partiu']}  
                                 contexto='' 
                                 voltar={'Blues3'}/>{'\n'}

Wonder if she's <Botao palavra='gone' 
                       destino='Exercicio' 
                       imagem='gone' 
                       palavrasCorretas={['foi', 'partiu']}  
                       contexto='' 
                       voltar={'Blues3'}/> to stay{'\n'}

Ain't no <Botao palavra='sunshine' 
                 destino='Exercicio' 
                 imagem='sunshine' 
                 palavrasCorretas={['sol', 'raio', 'raio de sol']}  
                 contexto='' 
                 voltar={'Blues3'}/> when she's gone{'\n'}

And this house just ain't no <Botao palavra='home' 
                                destino='Exercicio' 
                                imagem='home' 
                                palavrasCorretas={['lar', 'casa']}  
                                contexto='' 
                                voltar={'Blues3'}/>{'\n'}

Anytime she goes away{'\n'}{'\n'}

And I <Botao palavra='know' 
              destino='Exercicio' 
              imagem='know' 
              palavrasCorretas={['sei']}  
              contexto='' 
              voltar={'Blues3'}/>, I know, I know, I know, I know{'\n'}

I know, I know, I know, I know, I know{'\n'}

I know, I know, I know, I know{'\n'}

Hey, I ought to leave young thing alone{'\n'}{'\n'}

But ain't no <Botao palavra='sunshine' 
                 destino='Exercicio' 
                 imagem='sunshine' 
                 palavrasCorretas={['sol', 'raio', 'raio de sol']}  
                 contexto='' 
                 voltar={'Blues3'}/> when she's gone, whoa-whoa{'\n'}

Ain't no <Botao palavra='sunshine' 
                 destino='Exercicio' 
                 imagem='sunshine' 
                 palavrasCorretas={['sol', 'raio', 'raio de sol']}  
                 contexto='' 
                 voltar={'Blues3'}/> when she's gone{'\n'}

Only <Botao palavra='darkness' 
                  destino='Exercicio' 
                  imagem='darkness' 
                  palavrasCorretas={['escuridão']}  
                  contexto='' 
                  voltar={'Blues3'}/> every day{'\n'}

Ain't no <Botao palavra='sunshine' 
                 destino='Exercicio' 
                 imagem='sunshine' 
                 palavrasCorretas={['sol', 'raio', 'raio de sol']}  
                 contexto='' 
                 voltar={'Blues3'}/> when she's gone{'\n'}{'\n'}

And this house just ain't no <Botao palavra='home' 
                                destino='Exercicio' 
                                imagem='home' 
                                palavrasCorretas={['lar', 'casa']}  
                                contexto='' 
                                voltar={'Blues3'}/>{'\n'}

Anytime she goes away{'\n'}

Anytime she goes away{'\n'}

Anytime she goes away{'\n'}

Anytime she goes away{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Blues3;