import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Blues5() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'tv0J-H7VoGo'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero5'/>
        <Text style={estilos.titulo}>
        B.B. Bing - Call it stormy monday
        </Text>

        <Text style={estilos.letraMusica}>  
        They call it <Botao palavra='stormy' 
                    destino='Exercicio' 
                    imagem='stormy' 
                    palavrasCorretas={['tempestuoso', 'tempestade']}  
                    contexto='' 
                    voltar={'Blues5'}/> Monday, but <Botao palavra='Tuesday' 
                                                        destino='Exercicio' 
                                                        imagem='Tuesday' 
                                                        palavrasCorretas={['terça-feira']}  
                                                        contexto='' 
                                                        voltar={'Blues5'}/> 's just as bad{'\n'}

They call it <Botao palavra='stormy' 
                    destino='Exercicio' 
                    imagem='stormy' 
                    palavrasCorretas={['tempestuoso', 'tempestade']}  
                    contexto='' 
                    voltar={'Blues5'}/> Monday, but <Botao palavra='Tuesday' 
                                                        destino='Exercicio' 
                                                        imagem='Tuesday' 
                                                        palavrasCorretas={['terça-feira']}  
                                                        contexto='' 
                                                        voltar={'Blues5'}/> 's just as bad{'\n'}

<Botao palavra='Wednesday' 
        destino='Exercicio' 
        imagem='Wednesday' 
        palavrasCorretas={['quarta-feira', 'quarta']}  
        contexto='' 
        voltar={'Blues5'}/> 's worse, and <Botao palavra='Thursday' 
                                               destino='Exercicio' 
                                               imagem='Thursday' 
                                               palavrasCorretas={['quinta-feira', 'quinta']}  
                                               contexto='' 
                                               voltar={'Blues5'}/> 's also sad{'\n'}{'\n'}

Yes the <Botao palavra='eagle' 
                destino='Exercicio' 
                imagem='eagle' 
                palavrasCorretas={['águia']}  
                contexto='' 
                voltar={'Blues5'}/> flies on <Botao palavra='Friday' 
                                                      destino='Exercicio' 
                                                      imagem='Friday' 
                                                      palavrasCorretas={['sexta-feira', 'sexta']}  
                                                      contexto='' 
                                                      voltar={'Blues5'}/>, and <Botao palavra='Saturday' 
                                                                                  destino='Exercicio' 
                                                                                  imagem='Saturday' 
                                                                                  palavrasCorretas={['sábado']}  
                                                                                  contexto='' 
                                                                                  voltar={'Blues5'}/> I go out to play{'\n'}

<Botao palavra='eagle' 
        destino='Exercicio' 
        imagem='eagle' 
        palavrasCorretas={['águia']}  
        contexto='' 
        voltar={'Blues5'}/> flies on <Botao palavra='Friday' 
                                             destino='Exercicio' 
                                             imagem='Friday' 
                                             palavrasCorretas={['sexta-feira', 'sexta']}  
                                             contexto='' 
                                             voltar={'Blues5'}/>, and <Botao palavra='Saturday' 
                                                                             destino='Exercicio' 
                                                                             imagem='Saturday' 
                                                                             palavrasCorretas={['sábado', 'sabado']}  
                                                                             contexto='' 
                                                                             voltar={'Blues5'}/> I go out to play{'\n'}

<Botao palavra='Sunday' 
        destino='Exercicio' 
        imagem='Sunday' 
        palavrasCorretas={['domingo', 'domingo']}  
        contexto='' 
        voltar={'Blues5'}/> I go to church, then I kneel down and pray{'\n'}

Lord have <Botao palavra='mercy' 
                   destino='Exercicio' 
                   imagem='mercy' 
                   palavrasCorretas={['misericórdia']}  
                   contexto='' 
                   voltar={'Blues5'}/> , Lord have <Botao palavra='mercy' 
                                                        destino='Exercicio' 
                                                        imagem='mercy' 
                                                        palavrasCorretas={['misericórdia']}  
                                                        contexto='' 
                                                        voltar={'Blues5'}/> on me{'\n'}

Lord have <Botao palavra='mercy' 
                   destino='Exercicio' 
                   imagem='mercy' 
                   palavrasCorretas={['misericórdia']}  
                   contexto='' 
                   voltar={'Blues5'}/> , my <Botao palavra='heart' 
                                                   destino='Exercicio' 
                                                   imagem='heart' 
                                                   palavrasCorretas={['coração']}  
                                                   contexto='' 
                                                   voltar={'Blues5'}/> 's in <Botao palavra='misery' 
                                                                 destino='Exercicio' 
                                                                 imagem='misery' 
                                                                 palavrasCorretas={['miséria']}  
                                                                 contexto='' 
                                                                 voltar={'Blues5'}/>{'\n'}

Crazy about my baby, yes, send her back to me

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Blues5;