import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Blues2() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'Bcus42ihkTI'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero5'/>
        <Text style={estilos.titulo}>
        Etta james - I'd rather go blind
        </Text>

        <Text style={estilos.letraMusica}>  
        Something told me it was <Botao palavra='over' 
                                destino='Exercicio' 
                                imagem='over' 
                                palavrasCorretas={['acabado', 'terminado']}  
                                contexto='' 
                                voltar={'Blues2'}/>{'\n'}

When I saw you and her <Botao palavra='talkin' 
                                destino='Exercicio' 
                                imagem='talk' 
                                palavrasCorretas={['conversando']}  
                                contexto='' 
                                voltar={'Blues2'}/>{'\n'}

Something deep down in my soul said, '<Botao palavra='cry' 
                                              destino='Exercicio' 
                                              imagem='cry' 
                                              palavrasCorretas={['chorar']}  
                                              contexto='' 
                                              voltar={'Blues2'}/>, girl'{'\n'}

When I saw you and that girl <Botao palavra='walkin' 
                                        destino='Exercicio' 
                                        imagem='walk' 
                                        palavrasCorretas={['andando', 'caminhando']}  
                                        contexto='' 
                                        voltar={'Blues2'}/> around{'\n'}

Whoo, I would rather, I would rather go <Botao palavra='blind' 
                                                destino='Exercicio' 
                                                imagem='blind' 
                                                palavrasCorretas={['cego']}  
                                                contexto='' 
                                                voltar={'Blues2'}/>, boy{'\n'}

Then to see you walk away from me, child, no{'\n'}

Whoo, so you see, I <Botao palavra='love' 
                          destino='Exercicio' 
                          imagem='love' 
                          palavrasCorretas={['amo']}  
                          contexto='' 
                          voltar={'Blues2'}/> you so much{'\n'}

That I don't wanna watch you <Botao palavra='leave' 
                                  destino='Exercicio' 
                                  imagem='leave' 
                                  palavrasCorretas={['deixar', 'partir', 'sair']}  
                                  contexto='' 
                                  voltar={'Blues2'}/>, baby{'\n'}

Most of all, I just don't, I just don't wanna be <Botao palavra='free' 
                                                     destino='Exercicio' 
                                                     imagem='free' 
                                                     palavrasCorretas={['livre']}  
                                                     contexto='' 
                                                     voltar={'Blues2'}/>, no{'\n'}{'\n'}

Whoo, whoo, I was just, I was just, I was just{'\n'}

Sittin here thinkin', of your <Botao palavra='kiss' 
                                      destino='Exercicio' 
                                      imagem='kiss' 
                                      palavrasCorretas={['beijo']}  
                                      contexto='' 
                                      voltar={'Blues2'}/> and your <Botao palavra='warm' 
                                                                       destino='Exercicio' 
                                                                       imagem='warm' 
                                                                       palavrasCorretas={['quente', 'aconchegante']}  
                                                                       contexto='' 
                                                                       voltar={'Blues2'}/> embrace, yeah{'\n'}

When the reflection in the <Botao palavra='glass' 
                                   destino='Exercicio' 
                                   imagem='glass' 
                                   palavrasCorretas={['vidro', 'copo']}  
                                   contexto='' 
                                   voltar={'Blues2'}/> that I held to my lips now, baby{'\n'}

Revealed the <Botao palavra='tears' 
                      destino='Exercicio' 
                      imagem='tears' 
                      palavrasCorretas={['lágrimas', 'lagrimas']}  
                      contexto='' 
                      voltar={'Blues2'}/> that was on my face, yeah{'\n'}

Whoo and baby, baby, I'd rather, I'd rather be <Botao palavra='blind' 
                                                      destino='Exercicio' 
                                                      imagem='blind' 
                                                      palavrasCorretas={['cego']}  
                                                      contexto='' 
                                                      voltar={'Blues2'}/>, boy{'\n'}

Then to see you walk away, see you walk away from me, yeah{'\n'}

Whoo, baby, baby, baby, I'd rather be <Botao palavra='blind' 
                                             destino='Exercicio' 
                                             imagem='blind' 
                                             palavrasCorretas={['cego']}  
                                             contexto='' 
                                             voltar={'Blues2'}/>{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Blues2;