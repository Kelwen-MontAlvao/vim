import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Blues6() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = '416wa6CHs04'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero5'/>
        <Text style={estilos.titulo}>
        Eric Clapton - Before you accuse me
        </Text>

        <Text style={estilos.letraMusica}>  
        Before you <Botao palavra='accuse' 
                   destino='Exercicio' 
                   imagem='accuse' 
                   palavrasCorretas={['acusar']}  
                   contexto='' 
                   voltar={'Blues6'}/> me, take a look at yourself{'\n'}

Before you <Botao palavra='accuse' 
                   destino='Exercicio' 
                   imagem='accuse' 
                   palavrasCorretas={['acusar']}  
                   contexto='' 
                   voltar={'Blues6'}/> me, take a look at yourself{'\n'}

You say I've been <Botao palavra='spendin' 
                           destino='Exercicio' 
                           imagem='spend' 
                           palavrasCorretas={['gastando', 'despendendo']}  
                           contexto='' 
                           voltar={'Blues6'}/> my money on other women{'\n'}

But you've been <Botao palavra='runnin' 
                         destino='Exercicio' 
                         imagem='run' 
                         palavrasCorretas={['correndo', 'saindo']}  
                         contexto='' 
                         voltar={'Blues6'}/> with somebody else{'\n'}{'\n'}

I called your <Botao palavra='mama' 
                       destino='Exercicio' 
                       imagem='mama' 
                       palavrasCorretas={['mãe', 'mamãe']}  
                       contexto='' 
                       voltar={'Blues6'}/> 'bout three or four nights ago{'\n'}

I called your <Botao palavra='mama' 
                       destino='Exercicio' 
                       imagem='mama' 
                       palavrasCorretas={['mãe', 'mamãe']}  
                       contexto='' 
                       voltar={'Blues6'}/> 'bout three or four nights ago{'\n'}

Well your <Botao palavra='mother' 
                   destino='Exercicio' 
                   imagem='mother' 
                   palavrasCorretas={['mãe', 'mamãe']}  
                   contexto='' 
                   voltar={'Blues6'}/> said 'son,{'\n'}

Don't call my <Botao palavra='daughter' 
                      destino='Exercicio' 
                      imagem='daughter' 
                      palavrasCorretas={['filha']}  
                      contexto='' 
                      voltar={'Blues6'}/> no more'{'\n'}

Before you <Botao palavra='accuse' 
                   destino='Exercicio' 
                   imagem='accuse' 
                   palavrasCorretas={['acusar']}  
                   contexto='' 
                   voltar={'Blues6'}/> me, take a look at yourself{'\n'}

Before you <Botao palavra='accuse' 
                   destino='Exercicio' 
                   imagem='accuse' 
                   palavrasCorretas={['acusar']}  
                   contexto='' 
                   voltar={'Blues6'}/> me, take a look at yourself{'\n'}{'\n'}

Well now you say I've been <Botao palavra='runnin' 
                                   destino='Exercicio' 
                                   imagem='runnin' 
                                   palavrasCorretas={['correndo', 'saindo']}  
                                   contexto='' 
                                   voltar={'Blues6'}/> around{'\n'}

But you got <Botao palavra='somebody' 
                    destino='Exercicio' 
                    imagem='somebody' 
                    palavrasCorretas={['alguém']}  
                    contexto='' 
                    voltar={'Blues6'}/> else{'\n'}

Come on back home baby, try my <Botao palavra='love' 
                                         destino='Exercicio' 
                                         imagem='love' 
                                         palavrasCorretas={['amor']}  
                                         contexto='' 
                                         voltar={'Blues6'}/> one more time{'\n'}

Come on back home baby, try my <Botao palavra='love' 
                                         destino='Exercicio' 
                                         imagem='love' 
                                         palavrasCorretas={['amor']}  
                                         contexto='' 
                                         voltar={'Blues6'}/> one more time{'\n'}{'\n'}

Well now you've been gone away so long{'\n'}

I'm gonna lose my mind{'\n'}

Before you <Botao palavra='accuse' 
                   destino='Exercicio' 
                   imagem='accuse' 
                   palavrasCorretas={['acusar']}  
                   contexto='' 
                   voltar={'Blues6'}/> me, take a look at yourself{'\n'}

Before you <Botao palavra='accuse' 
                   destino='Exercicio' 
                   imagem='accuse' 
                   palavrasCorretas={['acusar']}  
                   contexto='' 
                   voltar={'Blues6'}/> me, take a look at yourself{'\n'}{'\n'}

Well now you say I've been <Botao palavra='buyin' 
                                   destino='Exercicio' 
                                   imagem='buy' 
                                   palavrasCorretas={['comprando', 'adquirindo']}  
                                   contexto='' 
                                   voltar={'Blues6'}/> other women clothes{'\n'}

You've been <Botao palavra='taking' 
                      destino='Exercicio' 
                      imagem='take' 
                      palavrasCorretas={['pegando', 'tomando']}  
                      contexto='' 
                      voltar={'Blues6'}/> money from somebody else{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Blues6;