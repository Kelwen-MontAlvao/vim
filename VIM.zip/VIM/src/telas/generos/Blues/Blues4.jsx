import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Blues4() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'ggGzE5KfCio'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero5'/>
        <Text style={estilos.titulo}>
        Ray charles – Georgia on my mind
        </Text>

        <Text style={estilos.letraMusica}>  
        <Botao palavra='sweet' 
        destino='Exercicio' 
        imagem='sweet' 
        palavrasCorretas={['doce']}  
        contexto='' 
        voltar={'Blues4'}/> , <Botao palavra='sweet' 
                                destino='Exercicio' 
                                imagem='sweet' 
                                palavrasCorretas={['doce']}  
                                contexto='' 
                                voltar={'Blues4'}/>{'\n'}

The whole day through (the whole day through){'\n'}

Just an old <Botao palavra='sweet' 
                     destino='Exercicio' 
                     imagem='sweet' 
                     palavrasCorretas={['doce']}  
                     contexto='' 
                     voltar={'Blues4'}/> song{'\n'}

Keeps Georgia on my mind (Georgia on my mind){'\n'}

I said Georgia{'\n'}

Georgia{'\n'}{'\n'}

A <Botao palavra='song' 
          destino='Exercicio' 
          imagem='song' 
          palavrasCorretas={['canção', 'música']}  
          contexto='' 
          voltar={'Blues4'}/> of you (a song of you){'\n'}

Comes as <Botao palavra='sweet' 
                  destino='Exercicio' 
                  imagem='sweet' 
                  palavrasCorretas={['doce']}  
                  contexto='' 
                  voltar={'Blues4'}/> and <Botao palavra='clear' 
                                             destino='Exercicio' 
                                             imagem='clear' 
                                             palavrasCorretas={['claro']}  
                                             contexto='' 
                                             voltar={'Blues4'}/>{'\n'}

As <Botao palavra='moonlight' 
           destino='Exercicio' 
           imagem='moonlight' 
           palavrasCorretas={['luz da lua']}  
           contexto='' 
           voltar={'Blues4'}/> through the pines{'\n'}

Other arms reach out to me{'\n'}

Other eyes <Botao palavra='smile' 
                   destino='Exercicio' 
                   imagem='smile' 
                   palavrasCorretas={['sorrir']}  
                   contexto='' 
                   voltar={'Blues4'}/> tenderly{'\n'}

Still in peaceful dreams I see{'\n'}

The road leads back to you{'\n'}{'\n'}

I said Georgia{'\n'}

Oh Georgia, no <Botao palavra='peace' 
                        destino='Exercicio' 
                        imagem='peace' 
                        palavrasCorretas={['paz']}  
                        contexto='' 
                        voltar={'Blues4'}/> I find (no peace I find){'\n'}

Just an old <Botao palavra='sweet' 
                     destino='Exercicio' 
                     imagem='sweet' 
                     palavrasCorretas={['doce']}  
                     contexto='' 
                     voltar={'Blues4'}/> song{'\n'}

Keeps Georgia on my mind (Georgia on my mind){'\n'}

Other arms reach out to me{'\n'}

Other eyes <Botao palavra='smile' 
                   destino='Exercicio' 
                   imagem='smile' 
                   palavrasCorretas={['sorrir']}  
                   contexto='' 
                   voltar={'Blues4'}/> tenderly{'\n'}

Still in peaceful dreams I see{'\n'}

The road leads back to you{'\n'}

Whoa-whoa, Georgia{'\n'}

Georgia{'\n'}{'\n'}

No <Botao palavra='peace' 
            destino='Exercicio' 
            imagem='peace' 
            palavrasCorretas={['paz']}  
            contexto='' 
            voltar={'Blues4'}/> , no <Botao palavra='peace' 
                                          destino='Exercicio' 
                                          imagem='peace' 
                                          palavrasCorretas={['paz']}  
                                          contexto='' 
                                          voltar={'Blues4'}/> I find{'\n'}

Just an old, <Botao palavra='sweet' 
                     destino='Exercicio' 
                     imagem='sweet' 
                     palavrasCorretas={['doce']}  
                     contexto='' 
                     voltar={'Blues4'}/> song{'\n'}

Keeps Georgia on my mind{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Blues4;