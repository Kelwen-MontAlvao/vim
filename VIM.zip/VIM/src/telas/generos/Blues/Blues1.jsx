import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Blues1() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'oica5jG7FpU'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero5'/>
        <Text style={estilos.titulo}>
        B.B. King - The thrill is gone
        </Text>

        <Text style={estilos.letraMusica}>  
        The <Botao palavra='thrill' 
           destino='Exercicio' 
           imagem='thrill' 
           palavrasCorretas={['emoção', 'entusiasmo', 'excitação']}  
           contexto='' 
           voltar={'Blues1'}/> is gone{'\n'}

The <Botao palavra='thrill' 
           destino='Exercicio' 
           imagem='thrill' 
           palavrasCorretas={['emoção', 'entusiasmo', 'excitação']}  
           contexto='' 
           voltar={'Blues1'}/> is gone away{'\n'}

The <Botao palavra='thrill' 
           destino='Exercicio' 
           imagem='thrill' 
           palavrasCorretas={['emoção', 'entusiasmo', 'excitação']}  
           contexto='' 
           voltar={'Blues1'}/> is gone, baby{'\n'}

The <Botao palavra='thrill' 
           destino='Exercicio' 
           imagem='thrill' 
           palavrasCorretas={['emoção', 'entusiasmo', 'excitação']}  
           contexto='' 
           voltar={'Blues1'}/> is gone away{'\n'}

You know you <Botao palavra='done' 
                  destino='Exercicio' 
                  imagem='done' 
                  palavrasCorretas={['me fez', 'me causou', 'fez', 'causou']}  
                  contexto='' 
                  voltar={'Blues1'}/> me wrong, baby{'\n'}

And you'll be sorry someday{'\n'}{'\n'}

The <Botao palavra='thrill' 
           destino='Exercicio' 
           imagem='thrill' 
           palavrasCorretas={['emoção', 'entusiasmo', 'excitação']}  
           contexto='' 
           voltar={'Blues1'}/> is gone{'\n'}

It's gone away from me{'\n'}

The <Botao palavra='thrill' 
           destino='Exercicio' 
           imagem='thrill' 
           palavrasCorretas={['emoção', 'entusiasmo', 'excitação']}  
           contexto='' 
           voltar={'Blues1'}/> is gone, baby{'\n'}

The <Botao palavra='thrill' 
           destino='Exercicio' 
           imagem='thrill' 
           palavrasCorretas={['emoção', 'entusiasmo', 'excitação']}  
           contexto='' 
           voltar={'Blues1'}/> is gone away from me{'\n'}{'\n'}

Although, I'll still live on{'\n'}
But so <Botao palavra='lonely' 
               destino='Exercicio' 
               imagem='lonely' 
               palavrasCorretas={['sozinho', 'solitário']}  
               contexto='' 
               voltar={'Blues1'}/> I'll be{'\n'}

The <Botao palavra='thrill' 
           destino='Exercicio' 
           imagem='thrill' 
           palavrasCorretas={['emoção', 'entusiasmo', 'excitação']}  
           contexto='' 
           voltar={'Blues1'}/> is gone{'\n'}

It's gone away for good{'\n'}

All the <Botao palavra='thrill' 
              destino='Exercicio' 
              imagem='thrill' 
              palavrasCorretas={['emoção', 'entusiasmo', 'excitação']}  
              contexto='' 
              voltar={'Blues1'}/> is gone{'\n'}

Baby, it's gone away for good{'\n'}

Someday I know I'll be open-armed baby{'\n'}

Just like I know, I know I should{'\n'}{'\n'}

You know, I'm <Botao palavra='free' 
                 destino='Exercicio' 
                 imagem='free' 
                 palavrasCorretas={['livre']}  
                 contexto='' 
                 voltar={'Blues1'}/> now, baby{'\n'}

I'm <Botao palavra='free' 
           destino='Exercicio' 
           imagem='free' 
           palavrasCorretas={['livre']}  
           contexto='' 
           voltar={'Blues1'}/> from your spell{'\n'}

Oh, <Botao palavra='free' 
           destino='Exercicio' 
           imagem='free' 
           palavrasCorretas={['livre']}  
           contexto='' 
           voltar={'Blues1'}/> now, baby{'\n'}

I'm <Botao palavra='free' 
           destino='Exercicio' 
           imagem='free' 
           palavrasCorretas={['livre']}  
           contexto='' 
           voltar={'Blues1'}/> from your spell{'\n'}

And now that it's all over{'\n'}
All that I can do is wish you well{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Blues1;