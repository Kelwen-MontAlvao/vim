import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Blues7() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'QButLzJB5SI'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero5'/>
        <Text style={estilos.titulo}>
        Buddy guy - Feels like rain
        </Text>

        <Text style={estilos.letraMusica}>  
        Down here the <Botao palavra='river' 
                      destino='Exercicio' 
                      imagem='river' 
                      palavrasCorretas={['rio']}  
                      contexto='' 
                      voltar={'Blues7'}/> 
Meets the <Botao palavra='sea' 
                   destino='Exercicio' 
                   imagem='sea' 
                   palavrasCorretas={['mar']}  
                   contexto='' 
                   voltar={'Blues7'}/>{'\n'}

And in the sticky heat, I feel ya{'\n'}
<Botao palavra='Open' 
        destino='Exercicio' 
        imagem='open' 
        palavrasCorretas={['abrir']}  
        contexto='' 
        voltar={'Blues7'}/> up to me{'\n'}

Love comes out of nowhere baby, just like a <Botao palavra='hurricane' 
                                                     destino='Exercicio' 
                                                     imagem='hurricane' 
                                                     palavrasCorretas={['furacão']}  
                                                     contexto='' 
                                                     voltar={'Blues7'}/>{'\n'}

And it <Botao palavra='feels' 
                destino='Exercicio' 
                imagem='feels' 
                palavrasCorretas={['sente']}  
                contexto='' 
                voltar={'Blues7'}/> like rain{'\n'}

And it <Botao palavra='feels' 
                destino='Exercicio' 
                imagem='feels' 
                palavrasCorretas={['sente']}  
                contexto='' 
                voltar={'Blues7'}/> like rain{'\n'}{'\n'}

Lying here{'\n'}
Underneath the <Botao palavra='stars' 
                       destino='Exercicio' 
                       imagem='stars' 
                       palavrasCorretas={['estrelas']}  
                       contexto='' 
                       voltar={'Blues7'}/>{'\n'}

Right next to you{'\n'}
And I'm wondering who you are{'\n'}
And <Botao palavra='how' 
             destino='Exercicio' 
             imagem='how' 
             palavrasCorretas={['como']}  
             contexto='' 
             voltar={'Blues7'}/> do you <Botao palavra='do' 
                                                destino='Exercicio' 
                                                imagem='do' 
                                                palavrasCorretas={['fazer']}  
                                                contexto='' 
                                                voltar={'Blues7'}/> ?{'\n'}

How do you <Botao palavra='do' 
                    destino='Exercicio' 
                    imagem='do' 
                    palavrasCorretas={['fazer']}  
                    contexto='' 
                    voltar={'Blues7'}/> , baby?{'\n'}{'\n'}

The <Botao palavra='clouds' 
            destino='Exercicio' 
            imagem='clouds' 
            palavrasCorretas={['nuvens']}  
            contexto='' 
            voltar={'Blues7'}/> roll in{'\n'}

Across the <Botao palavra='moon' 
                    destino='Exercicio' 
                    imagem='moon' 
                    palavrasCorretas={['lua']}  
                    contexto='' 
                    voltar={'Blues7'}/>{'\n'}

And the <Botao palavra='wind' 
                destino='Exercicio' 
                imagem='wind' 
                palavrasCorretas={['vento']}  
                contexto='' 
                voltar={'Blues7'}/> howls out your name{'\n'}

And it <Botao palavra='feels' 
                destino='Exercicio' 
                imagem='feels' 
                palavrasCorretas={['sente']}  
                contexto='' 
                voltar={'Blues7'}/> like rain{'\n'}

And it <Botao palavra='feels' 
                destino='Exercicio' 
                imagem='feels' 
                palavrasCorretas={['sente']}  
                contexto='' 
                voltar={'Blues7'}/> like rain{'\n'}{'\n'}

We're never{'\n'}
Going to make that <Botao palavra='bridge' 
                           destino='Exercicio' 
                           imagem='bridge' 
                           palavrasCorretas={['ponte']}  
                           contexto='' 
                           voltar={'Blues7'}/> tonight, baby{'\n'}

Across <Botao palavra='lake' 
                destino='Exercicio' 
                imagem='lake' 
                palavrasCorretas={['lago']}  
                contexto='' 
                voltar={'Blues7'}/> Pontchartrain{'\n'}

And it <Botao palavra='feels' 
                destino='Exercicio' 
                imagem='feels' 
                palavrasCorretas={['sente']}  
                contexto='' 
                voltar={'Blues7'}/> like rain{'\n'}

And it <Botao palavra='feels' 
                destino='Exercicio' 
                imagem='feels' 
                palavrasCorretas={['sente']}  
                contexto='' 
                voltar={'Blues7'}/> like rain{'\n'}{'\n'}

So batten down the hatch, baby{'\n'}
And leave your <Botao palavra='heart' 
                      destino='Exercicio' 
                      imagem='heart' 
                      palavrasCorretas={['coração']}  
                      contexto='' 
                      voltar={'Blues7'}/> up your <Botao palavra='sleeve' 
                                                        destino='Exercicio' 
                                                        imagem='sleeve' 
                                                        palavrasCorretas={['manga']}  
                                                        contexto='' 
                                                        voltar={'Blues7'}/>{'\n'}

It looks like we're in for <Botao palavra='stormy' 
                                     destino='Exercicio' 
                                     imagem='stormy' 
                                     palavrasCorretas={['tempestuoso', 'tempestade']}  
                                     contexto='' 
                                     voltar={'Blues7'}/> weather{'\n'}{'\n'}

That ain't no cause for us to leave{'\n'}
Just lie here{'\n'}
In my <Botao palavra='arms' 
               destino='Exercicio' 
               imagem='arms' 
               palavrasCorretas={['braços']}  
               contexto='' 
               voltar={'Blues7'}/>{'\n'}

Let it wash away the <Botao palavra='pain' 
                            destino='Exercicio' 
                            imagem='pain' 
                            palavrasCorretas={['dor']}  
                            contexto='' 
                            voltar={'Blues7'}/>{'\n'}

And it <Botao palavra='feels' 
                destino='Exercicio' 
                imagem='feels' 
                palavrasCorretas={['sente']}  
                contexto='' 
                voltar={'Blues7'}/> like rain{'\n'}

And it <Botao palavra='feels' 
                destino='Exercicio' 
                imagem='feels' 
                palavrasCorretas={['sente']}  
                contexto='' 
                voltar={'Blues7'}/> like rain{'\n'}

<Botao palavra='feels' 
        destino='Exercicio' 
        imagem='feels' 
        palavrasCorretas={['sente']}  
        contexto='' 
        voltar={'Blues7'}/> , <Botao palavra='feels' 
                                    destino='Exercicio' 
                                    imagem='feels' 
                                    palavrasCorretas={['sente']}  
                                    contexto='' 
                                    voltar={'Blues7'}/> like rain{'\n'}

(And it <Botao palavra='feels' 
                destino='Exercicio' 
                imagem='feels' 
                palavrasCorretas={['sente']}  
                contexto='' 
                voltar={'Blues7'}/> like rain) oh yeah, oh yeah <Botao palavra='feels' 
                                                                    destino='Exercicio' 
                                                                    imagem='feels' 
                                                                    palavrasCorretas={['sente']}  
                                                                    contexto='' 
                                                                    voltar={'Blues7'}/> hey{'\n'}

(Rain, rain){'\n'}
(You know it <Botao palavra='feels' 
                      destino='Exercicio' 
                      imagem='feels' 
                      palavrasCorretas={['sente']}  
                      contexto='' 
                      voltar={'Blues7'}/> like rain) oh yeah{'\n'}
(Sometimes, but it <Botao palavra='feels' 
                              destino='Exercicio' 
                              imagem='feels' 
                              palavrasCorretas={['sente']}  
                              contexto='' 
                              voltar={'Blues7'}/> like rain)

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Blues7;