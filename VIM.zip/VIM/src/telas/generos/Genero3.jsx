import React from 'react';
import { View, Text, ScrollView, StyleSheet, ImageBackground, TouchableOpacity, Button } from 'react-native';
import { Cabecalho } from '../../componentes/Cabecalho';
import { useNavigation } from '@react-navigation/native';
import { useMusic } from '../../MusicContext'; 

// Exemplo de dados de músicas com datas de lançamento e imagens
const postsMusicas = [
  { nome: 'See You Again', artista: 'Wiz Khalifa', dataLancamento: '2015-03-10', destino: 'Rap1', imagem: require('../../imgs/rap2.jpg') },
  { nome: 'Lonely', artista: 'Akon', dataLancamento: '2009-11-03', destino: 'Rap2', imagem: require('../../imgs/rap2.jpg') },
  { nome: 'God Is', artista: 'Kanye West', dataLancamento: '2019-09-27', destino: 'Rap3', imagem: require('../../imgs/rap2.jpg') },
  { nome: 'Good Feeling', artista: 'Flo Rida', dataLancamento: '2011-10-17', destino: 'Rap4', imagem: require('../../imgs/rap2.jpg') },
  { nome: 'HUMBLE', artista: 'Kendrick Lamar', dataLancamento: '2017-03-30', destino: 'Rap5', imagem: require('../../imgs/rap2.jpg') },
  { nome: 'Love Yourz', artista: 'J. Cole', dataLancamento: '2014-12-09', destino: 'Rap6', imagem: require('../../imgs/rap2.jpg') },
  { nome: 'The Light', artista: 'Common', dataLancamento: '2000-03-28', destino: 'Rap7', imagem: require('../../imgs/rap2.jpg') },
];


export function Genero3() {
  const navegacao = useNavigation();
  const { saveMusic } = useMusic(); 

  const navegar = (rota) => {
    navegacao.navigate(rota);
  };

  return (
    <>
      <Cabecalho />

      <ImageBackground
        source={require('../../imgs/rap2.jpg')}
        style={estilos.conteinerTitulo}
      >
        <Text style={estilos.titulo}>Gênero: Rap</Text>
      </ImageBackground>

      <ScrollView 
        style={estilos.scrollContent}
        contentContainerStyle={estilos.scrollContainer}
        vertical={true}
      >
        {postsMusicas.map((musica, index) => (
          <TouchableOpacity
            key={index}
            style={estilos.postContainer}
            onPress={() => navegar(musica.destino)}
          > 
            <View>
              <Text style={estilos.postTitulo}>{musica.nome}</Text>
              <Text style={estilos.postArtista}>Artista: {musica.artista}</Text>
              <Text style={estilos.postData}>Lançamento: {musica.dataLancamento}</Text>
              <Button title="Salvar Música" onPress={() => saveMusic(musica)} />
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#2d7de6',
    height: 200, // Altura da imagem de fundo
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center",
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
  },
  scrollContainer: {
    alignItems: 'center',
    paddingBottom: 20, // Espaçamento opcional na parte inferior do ScrollView
  },
  postContainer: {
    backgroundColor: '#e0f7fa', // Fundo azul claro
    width: '80%',
    padding: 20,
    marginVertical: 10,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
  },
  postTitulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  postArtista: {
    fontSize: 16,
    color: '#555',
  },
  postData: {
    fontSize: 14,
    color: '#777',
    marginBottom: 12
  },
});

export default Genero3;
