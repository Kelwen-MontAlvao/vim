import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rock1() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = '1w7OgIMMRc4'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero1'/>
        <Text style={estilos.titulo}>
          Guns'n Roses - Sweet Child'o Mine
        </Text>

        <Text style={estilos.letraMusica}>  
            She's got a <Botao palavra='smile'
                               destino='Exercicio' 
                               imagem='smile' 
                               palavrasCorretas={['sorriso', 'sorrir']}  
                               contexto='  '
                               voltar={'Rock1'}/> that it seems to me {'\n'}

            Reminds me of <Botao palavra='childhood' 
                                 destino='Exercicio' 
                                 imagem='childhood' 
                                 palavrasCorretas={['criança', 'adolescência', 'infancia', 'infância']}  
                                 contexto='  '
                                 voltar={'Rock1'}/> memories{'\n'}

            Where everything was as fresh{'\n'}
            As the <Botao palavra='bright' 
                          destino='Exercicio' 
                          imagem='bright' 
                          palavrasCorretas={['brilho']}  
                          contexto='  '
                          voltar={'Rock1'}/> blue sky{'\n'}{'\n'}

            Now and then when I see her <Botao palavra='face' 
                                               destino='Exercicio' 
                                               imagem='face' 
                                               palavrasCorretas={['cara', 'rosto']}  
                                               contexto='  '
                                               voltar={'Rock1'}/>{'\n'}

            She takes me away to that special <Botao palavra='place' 
                                                     destino='Exercicio' 
                                                     imagem='place' 
                                                     palavrasCorretas={['lugar']}  
                                                     contexto='  '
                                                     voltar={'Rock1'}/>{'\n'}
            And if I stare too long{'\n'}
            I'd probably break down and <Botao palavra='cry' 
                                               destino='Exercicio' 
                                               imagem='cry' 
                                               palavrasCorretas={['chorar', 'choro']}  
                                               contexto=''
                                               voltar={'Rock1'}/>{'\n'}{'\n'}

            Oh, oh, oh, <Botao palavra='sweet' 
                               destino='Exercicio' 
                               imagem='sweet' 
                               palavrasCorretas={['doce']}  
                               contexto='  '
                               voltar={'Rock1'}/> child of mine{'\n'}

            Oh, oh, oh, oh, <Botao palavra='sweet' 
                                   destino='Exercicio' 
                                   imagem='sweet' 
                                   palavrasCorretas={['doce']}  
                                   contexto='  '
                                   voltar={'Rock1'}/> love of mine{'\n'}{'\n'}

            She's got <Botao palavra='eyes' 
                             destino='Exercicio' 
                             imagem='eyes' 
                             palavrasCorretas={['olhos']}  
                             contexto='  '
                             voltar={'Rock1'}/> of the bluest skies{'\n'}

            As if they thought of <Botao palavra='rain' 
                                         destino='Exercicio' 
                                         imagem='rain' 
                                         palavrasCorretas={['chuva']}  
                                         contexto=' '
                                         voltar={'Rock1'}/>{'\n'}

            I hate to look into those <Botao palavra='eyes' 
                                             destino='Exercicio' 
                                             imagem='eyes' 
                                             palavrasCorretas={['olhos']}  
                                             contexto='  '
                                             voltar={'Rock1'}/>{'\n'}
            And see an ounce of pain{'\n'}{'\n'}

            Her hair reminds me of a <Botao palavra='warm' 
                                            destino='Exercicio' 
                                            imagem='warm' 
                                            palavrasCorretas={['esquentar', 'quente']}  
                                            contexto='  '
                                            voltar={'Rock1'}/> safe place{'\n'}
            Where, as a child, I'd hide{'\n'}
            And pray for the thunder and the <Botao palavra='rain' 
                                                    destino='Exercicio' 
                                                    imagem='rain' 
                                                    palavrasCorretas={['chuva']}  
                                                    contexto='  '
                                                    voltar={'Rock1'}/>{'\n'}
            To quietly pass me by{'\n'}{'\n'}

            Oh, oh, oh, <Botao palavra='sweet' 
                               destino='Exercicio' 
                               imagem='sweet' 
                               palavrasCorretas={['doce']}  
                               contexto='  '
                               voltar={'Rock1'}/> child of mine{'\n'}
            Oh, oh, oh, oh, <Botao palavra='sweet' 
                                   destino='Exercicio' 
                                   imagem='sweet' 
                                   palavrasCorretas={['doce']}  
                                   contexto='  '
                                   voltar={'Rock1'}/> love of mine{'\n'}
            Oh, oh, oh, oh, <Botao palavra='sweet' 
                                   destino='Exercicio' 
                                   imagem='sweet' 
                                   palavrasCorretas={['doce']}  
                                   contexto='  '
                                   voltar={'Rock1'}/> child of mine{'\n'}
            Ooh, yeah, yeah{'\n'}
            Ooh! <Botao palavra='sweet' 
                        destino='Exercicio' 
                        imagem='sweet' 
                        palavrasCorretas={['doce']}  
                        contexto='  '
                        voltar={'Rock1'}/> love of mine{'\n'}{'\n'}

            Where do we go?{'\n'}
            Where do we go now?{'\n'}
            Where do we go?{'\n'}{'\n'}

            Where do we go?{'\n'}
            Where do we go now?{'\n'}
            Where do we go now?{'\n'}{'\n'}

            Where do we go?{'\n'}
            Where do we go now?{'\n'}
            Where do we go?{'\n'}
            Where do we go?{'\n'}{'\n'}

            Where do we go now?{'\n'}
            Where do we go?{'\n'}
            Where do we go now?{'\n'}
            Where do we go?{'\n'}{'\n'}

            Where do we go now?{'\n'}
            Where do we go?{'\n'}
            Where do we go now?{'\n'}
            Now, now, now{'\n'}
            Now, now, now, now?{'\n'}{'\n'}

            <Botao palavra='sweet' 
                   destino='Exercicio' 
                   imagem='sweet' 
                   palavrasCorretas={['doce']}  
                   contexto='  '
                   voltar={'Rock1'}/> child{'\n'}

            <Botao palavra='sweet' 
                   destino='Exercicio' 
                   imagem='sweet' 
                   palavrasCorretas={['doce']}  
                   contexto='  '
                   voltar={'Rock1'}/> child of mine{'\n'}{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rock1;


