import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rock3() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = '6hzrDeceEKc'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero1'/>
        <Text style={estilos.titulo}>
          Oasis - Wonderwall
        </Text>

        <Text style={estilos.letraMusica}>  
        <Botao palavra='Today'
               destino='Exercicio' 
               imagem='day' 
               palavrasCorretas={['hoje']}  
               contexto='  '
               voltar={'Rock3'}/>is gonna be the day that they're gonna throw it back to you {'\n'}

          And by now, you should've somehow <Botao palavra='Realised'
                                                   destino='Exercicio' 
                                                   imagem='a young person happy' 
                                                   palavrasCorretas={['percebi', 'notei']}  
                                                   contexto='  '
                                                   voltar={'Rock3'}/>what you gotta do{'\n'}
                                                   
          I don't believe that anybody <Botao palavra='feels'
                                              destino='Exercicio' 
                                              imagem='feels' 
                                              palavrasCorretas={['sente']}  
                                              contexto=' '
                                              voltar={'Rock3'}/> the way I do about you now{'\n'}{'\n'}

          And backbeat, the word is on the <Botao palavra='street'
                                                  destino='Exercicio' 
                                                  imagem='street' 
                                                  palavrasCorretas={['rua', 'estrada']}  
                                                  contexto='  '/> that the fire in your heart is out{'\n'}
                                                  voltar={'Rock3'}

          I'm sure you've heard it all before, but you never really had a <Botao palavra='doubt'
                                                                                 destino='Exercicio' 
                                                                                 imagem='doubt' 
                                                                                 palavrasCorretas={['dúvida', 'duvida']}  
                                                                                 contexto='  '
                                                                                 voltar={'Rock3'}/>{'\n'}
          I don't believe that anybody feels the way I do about you now{'\n'}{'\n'}

          And all the <Botao palavra='roads'
                             destino='Exercicio' 
                             imagem='too much roads' 
                             palavrasCorretas={['ruas', 'estradas']}  
                             contexto='  '
                             voltar={'Rock3'}/> we have to walk are winding{'\n'}

          And all the <Botao palavra='lights'
                             destino='Exercicio' 
                             imagem='lamp' 
                             palavrasCorretas={['luzes']}  
                             contexto='  '
                             voltar={'Rock3'}/> that lead us there are blinding{'\n'}
          There are many things that I would like to say to you, but I don't know how{'\n'}{'\n'}

          Because <Botao palavra='maybe'
                         destino='Exercicio' 
                         imagem='maybe ' 
                         palavrasCorretas={['talvez']}  
                         contexto='  '
                         voltar={'Rock3'}/>{'\n'}
          You're gonna be the one that saves me{'\n'}
          And after all{'\n'}
          You're my wonderwall{'\n'}{'\n'}

          <Botao palavra='today'
                 destino='Exercicio' 
                 imagem='day' 
                 palavrasCorretas={['hoje']}  
                 contexto='  '
                 voltar={'Rock3'}/> was gonna be the day that they're gonna throw it back to you{'\n'}

          And by now, you should've somehow <Botao palavra='realised'
                                                   destino='Exercicio' 
                                                   imagem='realised' 
                                                   palavrasCorretas={['percebi', 'notei']}  
                                                   contexto='  '
                                                   voltar={'Rock3'}/> what you gotta do{'\n'}

          I don't believe that anybody <Botao palavra='feels'
                                              destino='Exercicio' 
                                              imagem='feels' 
                                              palavrasCorretas={['sente']}  
                                              contexto='  '
                                              voltar={'Rock3'}/> the way I do about you now{'\n'}{'\n'}

          And all the roads we have to walk are winding{'\n'}
          And all the lights that lead us there are blinding{'\n'}
          There are many things that I would like to say to you, but I don't know how{'\n'}{'\n'}

          I said <Botao palavra='maybe'
                        destino='Exercicio'  
                        imagem='a person thinking' 
                        palavrasCorretas={['talvez']}  
                        contexto=' '
                        voltar={'Rock3'}/>{'\n'}

          You're gonna be the one that saves me{'\n'}
          And after all{'\n'}
          You're my wonderwall{'\n'}{'\n'}

          I said <Botao palavra='maybe'
                        destino='Exercicio' 
                        imagem='a person thinking' 
                        palavrasCorretas={['talvez']}  
                        contexto='  '
                        voltar={'Rock3'}/> (I said maybe){'\n'}
          You're gonna be the one that saves me{'\n'}
          And after all{'\n'}
          You're my wonderwall{'\n'}{'\n'}

          I said <Botao palavra='maybe'
                        destino='Exercicio' 
                        imagem='a person thinking' 
                        palavrasCorretas={['talvez']}  
                        contexto='  '
                        voltar={'Rock3'}/> (I said maybe){'\n'}
          You're gonna be the one that saves me (saves me){'\n'}
          You're gonna be the one that saves me (saves me){'\n'}
          You're gonna be the one that saves me (saves me){'\n'}{'\n'}


        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rock3;


