import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rock4() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'fgT9zGkiLig'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero1'/>
        <Text style={estilos.titulo}>
          Incubus - Drive
        </Text>

        <Text style={estilos.letraMusica}>  
          Sometimes, I feel the <Botao palavra='fear'
                                       destino='Exercicio' 
                                       imagem='fear' 
                                       palavrasCorretas={['medo']}  
                                       contexto=' '
                                       voltar={'Rock4'}/> of {'\n'}

          <Botao palavra='Uncertainty'
                 destino='Exercicio' 
                 imagem='uncertainty' 
                 palavrasCorretas={['incerteza']}  
                 contexto='  '
                 voltar={'Rock4'}/> stinging clear{'\n'}

          And I, I can't help but ask myself{'\n'}
          How much I'll let the <Botao palavra='fear'
                                       destino='Exercicio' 
                                       imagem='fear' 
                                       palavrasCorretas={['medo']}  
                                       contexto='  '
                                       voltar={'Rock4'}/> take the wheel and steer{'\n'}{'\n'}

          It's driven me <Botao palavra='before'
                                destino='Exercicio' 
                                imagem='before' 
                                palavrasCorretas={['antes']}  
                                contexto='  '
                                voltar={'Rock4'}/>, and it seems to have a vague{'\n'}

          Haunting mass appeal{'\n'}
          But <Botao palavra='lately'
                     destino='Exercicio' 
                     imagem='lately' 
                     palavrasCorretas={['ultimamente']}  
                     contexto='  '
                     voltar={'Rock4'}/>, I'm beginning to find that I{'\n'}
                     
          Should be the one behind the wheel{'\n'}{'\n'}

          Whatever <Botao palavra='tomorrow'
                          destino='Exercicio' 
                          imagem='tomorrow' 
                          palavrasCorretas={['amanhã']}  
                          contexto='  '
                          voltar={'Rock4'}/> brings, I'll be there{'\n'}

          With open arms and open eyes, yeah{'\n'}
          Whatever <Botao palavra='tomorrow'
                          destino='Exercicio' 
                          imagem='tomorrow' 
                          palavrasCorretas={['amanhã']}  
                          contexto='  '
                          voltar={'Rock4'}/> brings, I'll be there{'\n'}

          I'll be there, oh{'\n'}{'\n'}

          So if I decide to waiver my{'\n'}
          Chance to be one of the hive{'\n'}
          Will I choose <Botao palavra='water'
                               destino='Exercicio' 
                               imagem='water' 
                               palavrasCorretas={['agua', 'água']}  
                               contexto='  '
                               voltar={'Rock4'}/> over <Botao palavra='wine'
                                                                       destino='Exercicio' 
                                                                       imagem='wine' 
                                                                       palavrasCorretas={['vinho']}  
                                                                       contexto='  '
                                                                       voltar={'Rock4'}/>{'\n'}
          And hold my own and drive?{'\n'}
          Ah, ah-ah, ooh{'\n'}{'\n'}

          It's driven me <Botao palavra='before'
                                destino='Exercicio' 
                                imagem='before' 
                                palavrasCorretas={['antes']}  
                                contexto='  '
                                voltar={'Rock4'}/>, and it seems to be the way{'\n'}

          That <Botao palavra='everyone'
                      destino='Exercicio' 
                      imagem='peoples acumulated' 
                      palavrasCorretas={['pessoal', 'todo mundo', 'todos']}  
                      contexto='  '
                      voltar={'Rock4'}/> else gets around{'\n'}

          But lately, I'm beginning to find that{'\n'}
          When I drive myself, my light is found{'\n'}{'\n'}

          Whatever <Botao palavra='tomorrow'
                          destino='Exercicio' 
                          imagem='tomorrow' 
                          palavrasCorretas={['amanhã']}  
                          contexto='  '
                          voltar={'Rock4'}/> brings, I'll be there{'\n'}

          With open arms and open eyes, yeah{'\n'}
          Whatever <Botao palavra='tomorrow'
                          destino='Exercicio' 
                          imagem='tomorrow' 
                          palavrasCorretas={['amanhã']}  
                          contexto='  '
                          voltar={'Rock4'}/> brings, I'll be there{'\n'}

          I'll be there, oh{'\n'}
          Would you choose <Botao palavra='water'
                               destino='Exercicio' 
                               imagem='water' 
                               palavrasCorretas={['agua', 'água']}  
                               contexto='  '
                               voltar={'Rock4'}/> over <Botao palavra='wine'
                                                                       destino='Exercicio' 
                                                                       imagem='wine' 
                                                                       palavrasCorretas={['vinho']}  
                                                                       contexto='  '
                                                                       voltar={'Rock4'}/>{'\n'}
          Hold the wheel and drive?{'\n'}{'\n'}

          Whatever <Botao palavra='tomorrow'
                          destino='Exercicio' 
                          imagem='tomorrow' 
                          palavrasCorretas={['amanhã']}  
                          contexto='  '
                          voltar={'Rock4'}/> brings, I'll be there{'\n'}

          With open arms and open eyes, yeah{'\n'}
          Whatever <Botao palavra='tomorrow'
                          destino='Exercicio' 
                          imagem='tomorrow' 
                          palavrasCorretas={['amanhã']}  
                          contexto='  '
                          voltar={'Rock4'}/> brings, I'll be there{'\n'}
          I'll be there, oh{'\n'}{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rock4;


