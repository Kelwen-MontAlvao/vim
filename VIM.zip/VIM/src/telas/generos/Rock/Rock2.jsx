import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rock2() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'hjpF8ukSrvk'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero1'/>
        <Text style={estilos.titulo}>
          Pink Floyd - Wish you were here
        </Text>

        <Text style={estilos.letraMusica}>  
          And disciplinary <Botao palavra='remains'
                                  destino='Exercicio' 
                                  imagem='person staying other person' 
                                  palavrasCorretas={['permanecer', 'permanece', 'continua']}  
                                  contexto='  '
                                  voltar={'Rock2'}/> mercifully {'\n'}
                                  
          Yes and um, I'm with you, Derek, this <Botao palavra='star'
                                                       destino='Exercicio' 
                                                       imagem='stars' 
                                                       palavrasCorretas={['estrelas', 'estrela']}  
                                                       contexto='  '
                                                       voltar={'Rock2'}/> nonsense{'\n'}
          Yes, yes{'\n'}
          Now which is it?{'\n'}
          I am sure of it{'\n'}{'\n'}

          So, so you think you can tell{'\n'}
          <Botao palavra='heaven'
                 destino='Exercicio' 
                 imagem='heaven' 
                 palavrasCorretas={['paraíso', 'paraiso', 'céu']}  
                 contexto='  '
                 voltar={'Rock2'}/> from <Botao palavra='hell'
                                                         destino='Exercicio' 
                                                         imagem='hell' 
                                                         palavrasCorretas={['inferno']}  
                                                         contexto='  '
                                                         voltar={'Rock2'}/>, blue skies from pain?{'\n'}

          Can you tell a green <Botao palavra='field'
                                      destino='Exercicio' 
                                      imagem='green field' 
                                      palavrasCorretas={['campo', 'campos']}  
                                      contexto=' '
                                      voltar={'Rock2'}/> from a cold steel rail{'\n'}

          A <Botao palavra='smile'
                   destino='Exercicio' 
                   imagem='smile' 
                   palavrasCorretas={['sorriso']}  
                   contexto='  '
                   voltar={'Rock2'}/> from a veil? Do you think you can tell?{'\n'}{'\n'}

          Did they get you to trade your <Botao palavra='heroes'
                                                destino='Exercicio' 
                                                imagem='superman' 
                                                palavrasCorretas={['heróis', 'herois']}  
                                                contexto='  '
                                                voltar={'Rock2'}/> for <Botao palavra='ghosts'
                                                                                       destino='Exercicio' 
                                                                                       imagem='a person ghost' 
                                                                                       palavrasCorretas={['fantasmas']}  
                                                                                       contexto=' '
                                                                                       voltar={'Rock2'}/>{'\n'}

          Hot <Botao palavra='ashes'
                     destino='Exercicio' 
                     imagem='ashes' 
                     palavrasCorretas={['cinzas']}  
                     contexto='  '
                     voltar={'Rock2'}/> for <Botao palavra='trees'
                                                  destino='Exercicio' 
                                                  imagem='trees' 
                                                  palavrasCorretas={['árvores', 'arvores']}  
                                                  contexto='  '
                                                  voltar={'Rock2'}/>, hot air for a cool breeze{'\n'}
          Cold comfort for change? Did you exchange{'\n'}
          A walk-on part in the war for a lead role in a cage?{'\n'}{'\n'}

          How I <Botao palavra='wish'
                      destino='Exercicio' 
                      imagem='the genium lamp' 
                      palavrasCorretas={['desejo']}  
                      contexto='  '
                      voltar={'Rock2'}/>, how I <Botao palavra='wish'
                                                                destino='Exercicio' 
                                                                imagem='desire' 
                                                                palavrasCorretas={['desejo']}  
                                                                contexto=' '
                                                                voltar={'Rock2'}/> you were here{'\n'}
          We're just two lost souls swimming in a fishbowl, year after year{'\n'}
          Running over the same old ground, what have we found?{'\n'}
          The same old <Botao palavra='fears'
                              destino='Exercicio' 
                              imagem='fears' 
                              palavrasCorretas={['medos', 'medo']}  
                              contexto='  '
                              voltar={'Rock2'}/>, wish you were here{'\n'}{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rock2;


