import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rock5() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'QkF3oxziUI4'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero1'/>
        <Text style={estilos.titulo}>
          Led Zeppelin - Stairway To Heaven
        </Text>

        <Text style={estilos.letraMusica}>  
        There's a lady who's sure all that glitters is <Botao palavra='gold'
                                                      destino='Exercicio' 
                                                      imagem='gold' 
                                                      palavrasCorretas={['ouro']}  
                                                      contexto='  '
                                                      voltar={'Rock5'}/>{'\n'}
And she's buying a <Botao palavra='stairway'
                          destino='Exercicio' 
                          imagem='stairway' 
                          palavrasCorretas={['escada', 'escadaria']}  
                          contexto='  '
                          voltar={'Rock5'}/> to Heaven {'\n'}

When she gets there she knows, if the <Botao palavra='stores'
                                             destino='Exercicio' 
                                             imagem='stores' 
                                             palavrasCorretas={['lojas']}  
                                             contexto='  '
                                             voltar={'Rock5'}/> are all closed
With a word she can get what she came for{'\n'}{'\n'}

Ooh, ooh, and she's buying a <Botao palavra='stairway'
                                    destino='Exercicio' 
                                    imagem='stairway' 
                                    palavrasCorretas={['escada', 'escadaria']}  
                                    contexto='  '
                                    voltar={'Rock5'}/> to Heaven{'\n'}{'\n'}

There's a sign on the <Botao palavra='wall'
                             destino='Exercicio' 
                             imagem='wall' 
                             palavrasCorretas={['parede']}  
                             contexto='  '
                             voltar={'Rock5'}/>, but she wants to be sure{'\n'}

'Cause you know sometimes words have two meanings{'\n'}{'\n'}
In a <Botao palavra='tree'
            destino='Exercicio' 
            imagem='tree' 
            palavrasCorretas={['árvore', 'arvore']}  
            contexto='  '
            voltar={'Rock5'}/> by the brook, there's a songbird who sings{'\n'}

Sometimes all of our thoughts are misgiven{'\n'}{'\n'}

Ooh, it makes me wonder{'\n'}
Ooh, makes me wonder{'\n'}{'\n'}

There's a feeling I get when I <Botao palavra='look'
                          	      destino='Exercicio' 
                          	      imagem='look' 
                          	      palavrasCorretas={['olhar', 'observar']}  
                          	      contexto='  '
                          	      voltar={'Rock5'}/> to the West{'\n'}

And my spirit is crying for leaving{'\n'}{'\n'}

In my thoughts I have seen <Botao palavra='rings'
                          	  destino='Exercicio' 
                          	  imagem='rings' 
                          	  palavrasCorretas={['anéis', 'aneis']}  
                          	  contexto='  '
                          	  voltar={'Rock5'}/> of <Botao palavra='smoke'
                                    			       destino='Exercicio' 
                          				       imagem='smoke' 
                         				       palavrasCorretas={['fumaça', 'fumaca']}  
                          				       contexto='  '
                          				       voltar={'Rock5'}/> through the trees{'\n'}

And the <Botao palavra='voices'
               destino='Exercicio' 
               imagem='voices' 
               palavrasCorretas={['vozes', 'voz']}  
               contexto='  '
               voltar={'Rock5'}/> of those who stand looking{'\n'}{'\n'}

Ooh, it makes me wonder{'\n'}
Ooh, really makes me wonder{'\n'}{'\n'}

And it's whispered that soon if we all call the tune{'\n'}
Then the piper will lead us to reason{'\n'}{'\n'}
And a new <Botao palavra='day'
                 destino='Exercicio' 
                 imagem='day' 
                 palavrasCorretas={['dia']}  
                 contexto='  '
                 voltar={'Rock5'}/> will dawn for those who stand long{'\n'}

And the forests will echo with laughter{'\n'}{'\n'}

Oh-oh-oh-oh-whoa{'\n'}{'\n'}

If there's a bustle in your hedgerow, don't be alarmed now{'\n'}
It's just a <Botao palavra='spring'
                   destino='Exercicio' 
                   imagem='spring' 
                   palavrasCorretas={['primavera']}  
                   contexto='  '
                   voltar={'Rock5'}/> clean for the May <Botao palavra='queen'
                          				       destino='Exercicio' 
                          				       imagem='queen' 
                         				         palavrasCorretas={['Rainha']}  
                          				       contexto='  '
                          				       voltar={'Rock5'}/>{'\n'}

Yes, there are two <Botao palavra='paths'
                          destino='Exercicio' 
                          imagem='paths' 
                          palavrasCorretas={['caminhos']}  
                          contexto='  '
                          voltar={'Rock5'}/> you can go by, but in the long <Botao palavra='run'
                          							   destino='Exercicio' 
                          						           imagem='run' 
                         					 		   palavrasCorretas={['correr', 'corrida']}  
                          							   contexto='  '
                          						           voltar={'Rock5'}/>
There's still time to change the road you're on{'\n'}{'\n'}

And it makes me wonder{'\n'}
Ohh, whoa{'\n'}{'\n'}

Your head is humming, and it won't go, in case you don't know{'\n'}
The piper's calling you to join him{'\n'}{'\n'}

Dear lady, can you hear the wind blow? And did you know{'\n'}
Your stairway lies on the whispering wind?{'\n'}{'\n'}

And as we wind on down the road{'\n'}
Our <Botao palavra='shadows'
           destino='Exercicio' 
           imagem='shadows' 
           palavrasCorretas={['sombras', 'sombras']}  
           contexto='  '
           voltar={'Rock5'}/>taller than our soul{'\n'}{'\n'}

There walks a lady we all know{'\n'}
Who shines white <Botao palavra='light'
                        destino='Exercicio' 
                        imagem='light' 
                        palavrasCorretas={['luz']}  
                        contexto='  '
                        voltar={'Rock5'}/>
 and wants to show{'\n'}
How everything still turns to <Botao palavra='gold'
                                     destino='Exercicio' 
                                     imagem='gold' 
                                     palavrasCorretas={['ouro']}  
                                     contexto='  '
                                     voltar={'Rock5'}/>{'\n'}

And if you listen very hard{'\n'}
The tune will come to you at last{'\n'}
When all are one, and one is all{'\n'}
To be a rock and not to <Botao palavra='roll'
                               destino='Exercicio' 
                               imagem='roll' 
                               palavrasCorretas={['rolar']}  
                               contexto='  '
                               voltar={'Rock5'}/>{'\n'}


And she's buying a <Botao palavra='stairway'
                          destino='Exercicio' 
                          imagem='stairway' 
                          palavrasCorretas={['escada', 'escadaria']}  
                          contexto='  '
                          voltar={'Rock5'}/> to Heaven{'\n'}
        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rock5;
