import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rock7() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'pAgnJDJN4VA'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero1'/>
        <Text style={estilos.titulo}>
        AC/DC - Back in Black
        </Text>

        <Text style={estilos.letraMusica}>  
        Back in <Botao palavra='black'
               destino='Exercicio' 
               imagem='black' 
               palavrasCorretas={['preto']}  
               contexto='  '
               voltar={'Rock7'}/>
,I hit the sack{'\n'}
I've been too long, I'm <Botao palavra='glad'
                               destino='Exercicio' 
                               imagem='glad' 
                               palavrasCorretas={['alegre', 'satisfeito']}  
                               contexto='  '
                               voltar={'Rock7'}/> to be back{'\n'}

Yes, I'm let loose from the <Botao palavra='noose'
                destino='Exercicio' 
                imagem='noose' 
                palavrasCorretas={['laço', 'laco']}  
                contexto='  '
                voltar={'Rock7'}/>{'\n'}

That's kept me <Botao palavra='hanging'
                      destino='Exercicio' 
                      imagem='hanging' 
                      palavrasCorretas={['pendurado']}  
                      contexto='  '
                      voltar={'Rock7'}/> about{'\n'}{'\n'}

I've been looking at the <Botao palavra='sky'
                                destino='Exercicio' 
                                imagem='sky' 
                                palavrasCorretas={['céu', 'ceu']}  
                                contexto='  '
                                voltar={'Rock7'}/>
'cause it's gettin' me high{'\n'}

Forget the hearse 'cause I never die{'\n'}
I got nine <Botao palavra='lives'
                  destino='Exercicio' 
                  imagem='lives' 
                  palavrasCorretas={['vidas']}  
                  contexto='  '
                  voltar={'Rock7'}/>
<Botao palavra='cat'
       destino='Exercicio' 
       imagem='cat' 
       palavrasCorretas={['gatos', 'gato']}  
       contexto='  '
       voltar={'Rock7'}/>'s eyes{'\n'}
Abusin' every one of them and running wild{'\n'}{'\n'}

'Cause I'm back{'\n'}
Yes, I'm back{'\n'}
Well, I'm <Botao palavra='back'
                 destino='Exercicio' 
                 imagem='back' 
                 palavrasCorretas={['voltar', 'voltei']}  
                 contexto='  '
                 voltar={'Rock7'}/>{'\n'}
Yes, I'm back{'\n'}{'\n'}

Well, I'm back, back{'\n'}
Well, I'm back in black{'\n'}
Yes, I'm back in black{'\n'}{'\n'}

Back in the back of a Cadillac {'\n'}
Number one with a <Botao palavra='bullet'
                         destino='Exercicio' 
                         imagem='bullet' 
                         palavrasCorretas={['balar', 'tiro']}  
                         contexto='  '
                         voltar={'Rock7'}/>, I'm a power pack{'\n'}

Yes, I'm in a bang with a gang{'\n'}
They've got to <Botao palavra='catch'
                      destino='Exercicio' 
                      imagem='catch' 
                      palavrasCorretas={['pegar']}  
                      contexto='  '
                      voltar={'Rock7'}/> me if they want me to hang{'\n'}{'\n'}

'Cause I'm <Botao palavra='back'
                      destino='Exercicio' 
                      imagem='back' 
                      palavrasCorretas={['voltar', 'voltei']}  
                      contexto='  '
                      voltar={'Rock7'}/> on the track
And I'm beatin' the flack {'\n'}
Nobody's gonna get me on another rap{'\n'}
So look at me now
I'm just makin' my <Botao palavra='play'
                          destino='Exercicio' 
                          imagem='play' 
                          palavrasCorretas={['jogar', 'jogada']}  
                          contexto='  '
                          voltar={'Rock7'}/>{'\n'}

Don't try to push your <Botao palavra='luck'
               		      destino='Exercicio' 
                              imagem='luck' 
               		      palavrasCorretas={['sorte']}  
               		      contexto='  '
               		      voltar={'Rock7'}/>, just get out of my <Botao palavra='way'
              								    destino='Exercicio' 
              								    imagem='way' 
               								    palavrasCorretas={['caminho']}  
               								    contexto='  '
               								    voltar={'Rock7'}/>{'\n'}{'\n'}

'Cause I'm back{'\n'}
Yes, I'm I'm <Botao palavra='back'
                    destino='Exercicio' 
                    imagem='back' 
                    palavrasCorretas={['voltar', 'voltei']}  
                    contexto='  '
                    voltar={'Rock7'}/>{'\n'}
Well, I'm back{'\n'}
Yes, I'm back{'\n'}{'\n'}

Well, I'm back, <Botao palavra='black'
                       destino='Exercicio' 
                       imagem='black' 
                       palavrasCorretas={['preto']}  
                       contexto='  '
                       voltar={'Rock7'}/>{'\n'}

Well, I'm back in <Botao palavra='black'
                         destino='Exercicio' 
                         imagem='black' 
               		 palavrasCorretas={['preto']}  
               		 contexto='  '
               		 voltar={'Rock7'}/>{'\n'}

Yes, I'm back in <Botao palavra='black'
               		destino='Exercicio' 
               		imagem='black' 
              		palavrasCorretas={['preto']}  
               		contexto='  '
               		voltar={'Rock7'}/>{'\n'}{'\n'}

Well, I'm back{'\n'}
yes, I'm back{'\n'}
Well, I'm <Botao palavra='back'
                     destino='Exercicio' 
                     imagem='back' 
                     palavrasCorretas={['voltar', 'voltei']}  
                     contexto='  '
                     voltar={'Rock7'}/>{'\n'}
yes, I'm back{'\n'}{'\n'}
...
        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rock7;