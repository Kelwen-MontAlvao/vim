import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rock6() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'hTWKbfoikeg'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero1'/>
        <Text style={estilos.titulo}>
        Nirvana - Smells Like Teen Spirit
        </Text>

        <Text style={estilos.letraMusica}>  
        Load up on <Botao palavra='guns'
                  destino='Exercicio' 
                  imagem='guns' 
                  palavrasCorretas={['armas', 'arma']}  
                  contexto='  '
                  voltar={'Rock6'}/>, bring your <Botao palavra='friends'
                                                        destino='Exercicio' 
                                                        imagem='friends' 
                                                        palavrasCorretas={['amigos']}  
                                                        contexto='  '
                                                        voltar={'Rock6'}/>{'\n'}
It's fun to lose and to pretend{'\n'}
She's over-<Botao palavra='bored'
                  destino='Exercicio' 
                  imagem='bored' 
                  palavrasCorretas={['entediado', 'entediada']}  
                  contexto='  '
                  voltar={'Rock6'}/> and self-assured{'\n'}

Oh no, I know a <Botao palavra='dirty'
                       destino='Exercicio' 
                       imagem='dirty' 
                       palavrasCorretas={['sujo', 'suja']}  
                       contexto='  '
                       voltar={'Rock6'}/> word{'\n'}{'\n'}

Hello, hello, hello, how low{'\n'}
Hello, hello, hello, how low{'\n'}
Hello, hello, hello, how low{'\n'}
Hello, hello, hello{'\n'}{'\n'}

With the lights out, it's less <Botao palavra='dangerous'
                       		      destino='Exercicio' 
                       		      imagem='dangerous' 
                       		      palavrasCorretas={['perigoso', 'perigo']}  
                       		      contexto='  '
                       		      voltar={'Rock6'}/>{'\n'}
Here we are now, <Botao palavra='entertain'
                        destino='Exercicio' 
                        imagem='entertain' 
                        palavrasCorretas={['entreter', 'divertir']}  
                        contexto='  '
                        voltar={'Rock6'}/> us{'\n'}
I feel stupid and contagious{'\n'}
Here we are now, <Botao palavra='entertain'
                        destino='Exercicio' 
                        imagem='entertain' 
                        palavrasCorretas={['entreter', 'divertir']}  
                        contexto='  '
                        voltar={'Rock6'}/> us{'\n'}{'\n'}

A mulatto, an albino{'\n'}
A mosquito, my libido{'\n'}
Yeah{'\n'}
Hey{'\n'}
Yay{'\n'}{'\n'}

I'm worse at what I do best{'\n'}
And for this <Botao palavra='gift'
                    destino='Exercicio' 
                    imagem='gift' 
                    palavrasCorretas={['presente']}  
                    contexto='  '
                    voltar={'Rock6'}/> I feel blessed{'\n'}

Our little <Botao palavra='group'
                  destino='Exercicio' 
                  imagem='group' 
                  palavrasCorretas={['grupo']}  
                  contexto='  '
                  voltar={'Rock6'}/> has always been{'\n'}

And always will until the end{'\n'}{'\n'}

Hello, hello, hello, how low{'\n'}
Hello, hello, hello, how low{'\n'}
Hello, hello, hello, how low{'\n'}
Hello, hello, hello{'\n'}{'\n'}

With the lights out, it's less <Botao palavra='dangerous'
                       		      destino='Exercicio' 
                       		      imagem='dangerous' 
                       		      palavrasCorretas={['perigoso', 'perigo']}  
                       		      contexto='  '
                       		      voltar={'Rock6'}/>{'\n'}
Here we are now, <Botao palavra='entertain'
                        destino='Exercicio' 
                        imagem='entertain' 
                        palavrasCorretas={['entreter', 'divertir']}  
                        contexto='  '
                        voltar={'Rock6'}/> us{'\n'}

I feel stupid and contagious{'\n'}
Here we are now, <Botao palavra='entertain'
                        destino='Exercicio' 
                        imagem='entertain' 
                        palavrasCorretas={['entreter', 'divertir']}  
                        contexto='  '
                        voltar={'Rock6'}/> us{'\n'}{'\n'}

A mulatto, an albino{'\n'}
A mosquito, my libido{'\n'}
Yeah{'\n'}
Hey{'\n'}
Yay{'\n'}{'\n'}

And I forget just why I taste{'\n'}
Oh yeah, I guess it makes me <Botao palavra='smile'
                                    destino='Exercicio' 
                                    imagem='smile' 
                                    palavrasCorretas={['sorriso']}  
                                    contexto='  '
                                    voltar={'Rock6'}/>{'\n'}
I found it <Botao palavra='hard'
                  destino='Exercicio' 
                  imagem='hard' 
                  palavrasCorretas={['dificil', 'difícil']}  
                  contexto='  '
                  voltar={'Rock6'}/>, it's <Botao palavra='hard'
                        			  destino='Exercicio' 
                        			  imagem='hard' 
                        			  palavrasCorretas={['dificil','difícil']}  
                        			  contexto='  '
                        			  voltar={'Rock6'}/> to find{'\n'}
Ooh well, whatever, nevermind{'\n'}{'\n'}

Hello, hello, hello, how low{'\n'}
Hello, hello, hello, how low{'\n'}
Hello, hello, hello, how low{'\n'}
Hello, hello, hello{'\n'}{'\n'}

With the lights out, it's less <Botao palavra='dangerous'
                       		      destino='Exercicio' 
                       		      imagem='dangerous' 
                       		      palavrasCorretas={['perigoso', 'perigo']}  
                       		      contexto='  '
                       		      voltar={'Rock6'}/>{'\n'}
Here we are now, <Botao palavra='entertain'
                        destino='Exercicio' 
                        imagem='entertain' 
                        palavrasCorretas={['entreter', 'divertir']}  
                        contexto='  '
                        voltar={'Rock6'}/> us{'\n'}

I feel stupid and contagious{'\n'}
Here we are now, <Botao palavra='entertain'
                        destino='Exercicio' 
                        imagem='entertain' 
                        palavrasCorretas={['entreter', 'divertir']}  
                        contexto='  '
                        voltar={'Rock6'}/> us{'\n'}

A mulatto, an albino{'\n'}
A mosquito, my libido{'\n'}
A denial{'\n'}{'\n'}
        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rock6;
