import React from 'react';
import { View, Text, ScrollView, StyleSheet, ImageBackground, TouchableOpacity, Button } from 'react-native';
import { Cabecalho } from '../../componentes/Cabecalho';
import { useNavigation } from '@react-navigation/native';
import { useMusic } from '../../MusicContext'; 

// Exemplo de dados de músicas com datas de lançamento e imagens
const postsMusicas = [
  { nome: 'Happy', artista: 'Pharrell Williams', dataLancamento: '2013-11-21', destino: 'Pop1', imagem: require('../../imgs/pop2.jpg') },
  { nome: 'Just the Way You Are', artista: 'Bruno Mars', dataLancamento: '2010-10-05', destino: 'Pop2', imagem: require('../../imgs/pop2.jpg') },
  { nome: 'Shape of You', artista: 'Ed Sheeran', dataLancamento: '2017-01-06', destino: 'Pop3', imagem: require('../../imgs/pop2.jpg') },
  { nome: 'Roar', artista: 'Katy Perry', dataLancamento: '2013-08-10', destino: 'Pop4', imagem: require('../../imgs/pop2.jpg') },
  { nome: 'You Are The Reason', artista: 'Calum Scott', dataLancamento: '2017-03-24', destino: 'Pop5', imagem: require('../../imgs/pop2.jpg') },
  { nome: 'Flowers', artista: 'Miley Cyrus', dataLancamento: '2023-01-12', destino: 'Pop6', imagem: require('../../imgs/pop2.jpg') },
  { nome: 'Back To Me', artista: 'The Rose', dataLancamento: '2022-09-30', destino: 'Pop7', imagem: require('../../imgs/pop2.jpg') },
];


export function Genero2() {
  const navegacao = useNavigation();
  const { saveMusic } = useMusic();

  const navegar = (rota) => {
    navegacao.navigate(rota);
  };

  return (
    <>
      <Cabecalho />

      <ImageBackground
        source={require('../../imgs/pop2.jpg')}
        style={estilos.conteinerTitulo}
      >
        <Text style={estilos.titulo}>Gênero: Pop</Text>
      </ImageBackground>

      <ScrollView 
        style={estilos.scrollContent}
        contentContainerStyle={estilos.scrollContainer}
        vertical={true}
      >
        {postsMusicas.map((musica, index) => (
          <TouchableOpacity
            key={index}
            style={estilos.postContainer}
            onPress={() => navegar(musica.destino)}
          > 
            <View>
              <Text style={estilos.postTitulo}>{musica.nome}</Text>
              <Text style={estilos.postArtista}>Artista: {musica.artista}</Text>
              <Text style={estilos.postData}>Lançamento: {musica.dataLancamento}</Text>
              <Button title="Salvar Música" onPress={() => saveMusic(musica)} />
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#2d7de6',
    height: 200, // Altura da imagem de fundo
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center",
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
  },
  scrollContainer: {
    alignItems: 'center',
    paddingBottom: 20, // Espaçamento opcional na parte inferior do ScrollView
  },
  postContainer: {
    backgroundColor: '#e0f7fa', // Fundo azul claro
    width: '80%',
    padding: 20,
    marginVertical: 10,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
  },
  postTitulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  postArtista: {
    fontSize: 16,
    color: '#555',
  },
  postData: {
    fontSize: 14,
    color: '#777',
    marginBottom: 12
  },
});

export default Genero2;

