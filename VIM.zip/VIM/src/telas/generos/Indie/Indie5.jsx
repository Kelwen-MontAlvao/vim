import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao';
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Indie5() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback((state) => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying((prev) => !prev);
  }, []);

  const bancodedadosId = 'wIuBcb2T55Q'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
        <BotaoVoltar destino="Genero4" />
        <Text style={estilos.titulo}> Mac DeMarco - My Kind Of Woman </Text>
        <Text style={estilos.letraMusica}>
        Oh, baby  {"\n"}
Oh, man {"\n"}
You're making me<Botao palavra='crazy'
						destino='Exercicio'
						imagem='crazy'
						palavrasCorretas={['louca', 'louco', 'maluco', 'maluca']}
						contexto=''
						voltar={'Indie5'}/>  {"\n"}
Really driving me mad {"\n"}{'\n'}

But that's all right with me {"\n"}
It's really no fuss {"\n"}
As long as you're next to me {"\n"}
Just the two of us {"\n"}{'\n'}

You're my, my, my, my kind of woman {"\n"}
My, oh my, what a girl {"\n"}
You're my, my, my, my kind of woman {"\n"}
And I'm down on my <Botao palavra='hands'
						destino='Exercicio'
						imagem='hands'
						palavrasCorretas={['mãos', 'mão']}
						contexto=''
						voltar={'Indie5'}/> and 
<Botao palavra='kness'
						destino='Exercicio'
						imagem='knee'
						palavrasCorretas={['joelhos', 'joelho']}
						contexto='Eu estou rendido por você'
						voltar={'Indie5'}/> {"\n"}
Begging you please, baby {"\n"}
Show me your <Botao palavra='world'
						destino='Exercicio'
						imagem='world'
						palavrasCorretas={['mundo','universo']}
						contexto=''
						voltar={'Indie5'}/> {"\n"}{'\n'}

Oh, brother {"\n"}
				<Botao palavra='Sweetheart'
						destino='Exercicio'
						imagem='sweetheart'
						palavrasCorretas={['querida', 'amor', 'meu bem']}
						contexto=''
						voltar={'Indie5'}/> {"\n"}
I'm feeling so tired {"\n"}
Really falling <Botao palavra='apart'
						destino='Exercicio'
						imagem='broken plate'
						palavrasCorretas={['pedaços', 'pedaço', 'caco']}
						contexto=''
						voltar={'Indie5'}/> {"\n"}{'\n'}

And it just don't make sense to me {"\n"}
I really don't know {"\n"}
Why you stick right<Botao palavra='next to me'
						destino='Exercicio'
						imagem='together'
						palavrasCorretas={['Próximo', 'juntos', 'Ao lado']}
						contexto=''
						voltar={'Indie5'}/>  {"\n"}
Or wherever I go {"\n"}{'\n'}

You're my, my, my, my kind of woman {"\n"}
My, oh my, what a girl {"\n"}
You're my, my, my, my kind of woman {"\n"}
And I'm down on my hands and knees {"\n"}
Begging you please, baby {"\n"}
Show me your world {"\n"}{'\n'}
        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000',
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10,
    marginVertical: 10,
  },
});

export default Indie5;
