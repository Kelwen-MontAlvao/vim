import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Indie1() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'VF-FGf_ZZiI'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero4'/>
        <Text style={estilos.titulo}>
        Steve Lacy - Bad Habit
        </Text>

        <Text style={estilos.letraMusica}>  
          wanted me{'\n'}
          I <Botao palavra='wish'
                   destino='Exercicio' 
                   imagem='a wish' 
                   palavrasCorretas={['desejo']}  
                   contexto='  '
                   voltar={'Indie1'}/> I knew, I wish I knew you wanted me{'\n'}

          I <Botao palavra='wish'
                   destino='Exercicio' 
                   imagem='a wish' 
                   palavrasCorretas={['desejo']}  
                   contexto=' '
                   voltar={'Indie1'}/> I knew, I wish I knew you wanted me {'\n'}{'\n'}

          What you, ooh, uh, what you do?{'\n'}
          Made a <Botao palavra='move'
                        destino='Exercicio' 
                        imagem='move' 
                        palavrasCorretas={['mover', 'movimento']}  
                        contexto=' '
                        voltar={'Indie1'}/>, coulda made a move{'\n'}
          If I knew I'd be with you{'\n'}
          Is it too late to<Botao palavra='pursue'
                                  destino='Exercicio' 
                                  imagem='a person pursue someone' 
                                  palavrasCorretas={['perseguir', 'seguir']}  
                                  contexto=' '
                                  voltar={'Indie1'}/>?{'\n'}{'\n'}

          I bite my<Botao palavra='tongue'
                          destino='Exercicio' 
                          imagem='tongue' 
                          palavrasCorretas={['língua', 'lingua']}  
                          contexto=' '
                          voltar={'Indie1'}/>, it's a bad <Botao palavra='habit'
                                                                         destino='Exercicio' 
                                                                         imagem='habit' 
                                                                         palavrasCorretas={['coelho']}  
                                                                         contexto='  '
                                                                         voltar={'Indie1'}/>{'\n'}

          Kinda mad that I didn't take a <Botao palavra='stab'
                                                destino='Exercicio' 
                                                imagem='a stab' 
                                                palavrasCorretas={['facada', 'esfaquear']}  
                                                contexto=' '
                                                voltar={'Indie1'}/> at it{'\n'}

          Thought you were too good for me, my <Botao palavra='dear'
                                                      destino='Exercicio' 
                                                      imagem='dear' 
                                                      palavrasCorretas={['querido', 'querida']}  
                                                      contexto=' '
                                                      voltar={'Indie1'}/>{'\n'}
          Never gave me time of day, my <Botao palavra='dear'
                                               destino='Exercicio' 
                                               imagem='dear' 
                                               palavrasCorretas={['querido', 'querida']}  
                                               contexto='  '
                                               voltar={'Indie1'}/>{'\n'}
          It's okay, things happen for{'\n'}
          <Botao palavra='Reasons'
                 destino='Exercicio' 
                 imagem='Reasons' 
                 palavrasCorretas={['Razões']}  
                 contexto='  '
                 voltar={'Indie1'}/> that I think are sure, yeah{'\n'}{'\n'}

          I <Botao palavra='wish'
                   destino='Exercicio' 
                   imagem='a wish' 
                   palavrasCorretas={['desejo']}  
                   contexto='  '
                   voltar={'Indie1'}/> I knew, I wish I knew you wanted me{'\n'}

          I <Botao palavra='wish'
                   destino='Exercicio' 
                   imagem='a wish' 
                   palavrasCorretas={['desejo']}  
                   contexto=' '
                   voltar={'Indie1'}/> I knew (oh), I wish I knew you wanted me{'\n'}

          I <Botao palavra='wish'
                   destino='Exercicio' 
                   imagem='a wish' 
                   palavrasCorretas={['desejo']}  
                   contexto=' '
                   voltar={'Indie1'}/> I knew (yeah), I wish I knew you wanted me (oh){'\n'}

          I <Botao palavra='wish'
                   destino='Exercicio' 
                   imagem='a wish' 
                   palavrasCorretas={['desejo']}  
                   contexto='  '
                   voltar={'Indie1'}/> I knew, I wish I knew you wanted me{'\n'}{'\n'}

          Say to me (please just say to me){'\n'}
          If you <Botao palavra='still'
                        destino='Exercicio' 
                        imagem='still' 
                        palavrasCorretas={['ainda', 'continua']}  
                        contexto=' '
                        voltar={'Indie1'}/> want it{'\n'}
          I wish you wouldn't play with me{'\n'}
          I wanna know (oh no){'\n'}{'\n'}

          Uh, can I bite your <Botao palavra='tongue'
                                     destino='Exercicio' 
                                     imagem='tongue' 
                                     palavrasCorretas={['língua', 'lingua']}  
                                     contexto='  '
                                     voltar={'Indie1'}/> like my bad <Botao palavra='habit'
                                                                                    destino='Exercicio' 
                                                                                    imagem='habit' 
                                                                                    palavrasCorretas={['coelho']}  
                                                                                    contexto='  '
                                                                                    voltar={'Indie1'}/>?{'\n'}
          Would you mind if I tried to make a pass at it?{'\n'}
          Were you not too good for me, my <Botao palavra='dear'
                                                  destino='Exercicio' 
                                                  imagem='dear' 
                                                  palavrasCorretas={['querido']}  
                                                  contexto='  '
                                                  voltar={'Indie1'}/>?{'\n'}
          <Botao palavra='Funny'
                 destino='Exercicio' 
                 imagem='Funny' 
                 palavrasCorretas={['engraçado', 'engraçada', 'divertida']}  
                 contexto='  '
                 voltar={'Indie1'}/> you come back to me, my <Botao palavra='dear'
                                                                            destino='Exercicio' 
                                                                            imagem='dear' 
                                                                            palavrasCorretas={['querido', 'querida']}  
                                                                            contexto='  '
                                                                            voltar={'Indie1'}/>{'\n'}
          It's okay, things happen for{'\n'}
          Reasons that I can't ignore, yeah{'\n'}{'\n'}

          I wish I knew, I wish I knew you wanted me{'\n'}
          I wish I knew (wish I knew), I wish I knew you wanted me (oh){'\n'}{'\n'}

          You can't surprise a <Botao palavra='gemini'
                                      destino='Exercicio' 
                                      imagem='gemini' 
                                      palavrasCorretas={['gemeo', 'gêmeo', 'gemea', 'gêmea', 'gemeos', 'gêmeos', 'gemeas', 'gêmeas']}  
                                      contexto=' Signo de maio e junho'
                                      voltar={'Indie1'}/>{'\n'}

          I'm <Botao palavra='everywhere'
                     destino='Exercicio' 
                     imagem='everywhere' 
                     palavrasCorretas={['todo lugar']}  
                     contexto='  '
                     voltar={'Indie1'}/>, I'm cross-eyed, and{'\n'}

          Now that you're back, I can't decide{'\n'}
          If I decide if you're invited{'\n'}
          You always knew the way to wow me{'\n'}
          Fuck around, get tongue-tied, and{'\n'}
          I turn it on, I make it <Botao palavra='rowdy'
                                         destino='Exercicio' 
                                         imagem='rowdy' 
                                         palavrasCorretas={['turbulento']}  
                                         contexto='  '
                                         voltar={'Indie1'}/>{'\n'}
          Then <Botao palavra='Carry on'
                      destino='Exercicio' 
                      imagem='carry on' 
                      palavrasCorretas={['Continue', 'Continuar']}
                      voltar={'Indie1'}/>, but I'm not hidin'{'\n'}

          You grabbin' me hard 'cause you know what you found{'\n'}
          Is biscuits, is gravy, babe, ah-ah{'\n'}{'\n'}

          You can't surprise a <Botao palavra='gemini'
                                      destino='Exercicio' 
                                      imagem='gemini' 
                                      palavrasCorretas={['gemeo', 'gêmeo', 'gemea', 'gêmea', 'gemeos', 'gêmeos', 'gemeas', 'gêmeas']}  
                                      contexto=' Signo de maio e junho'
                                      voltar={'Indie1'}/>{'\n'}
          But you know it's biscuits, is <Botao palavra='gravy'
                                                destino='Exercicio' 
                                                imagem='gravy' 
                                                palavrasCorretas={['molho']}  
                                                contexto='  '
                                                voltar={'Indie1'}/>, babe{'\n'}
          I knew you'd come back around{'\n'}
          'Cause you know it's biscuits, it's gravy, babe{'\n'}
          Let's fuck in the back of the mall, lose control{'\n'}
          Go stupid, go crazy, babe{'\n'}
          I know I'll be in your heart 'til the end{'\n'}
          You'll miss me, don't beg me, babe{'\n'}{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Indie1;