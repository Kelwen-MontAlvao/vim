import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Indie2() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'IqYgNiZdfh4'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero4'/>
        <Text style={estilos.titulo}>
        The Drums - Money
        </Text>

        <Text style={estilos.letraMusica}>  
          Before I die {'\n'}
          I'd like to do <Botao palavra='something'
                                destino='Exercicio' 
                                imagem='something' 
                                palavrasCorretas={['algo', 'alguma coisa']}  
                                contexto='  '
                                voltar={'Indie2'}/> nice{'\n'}

          Take my hand and I'll take you for a <Botao palavra='ride'
                                                      destino='Exercicio' 
                                                      imagem='ride' 
                                                      palavrasCorretas={['passeio']}  
                                                      contexto='Ride pode significar corrida, mas está sendo usado no sentido de dar uma volta com alguém,
                                                       ir em algum lugar'
                                                      voltar={'Indie2'}/>{'\n'}{'\n'}

          You hit me <Botao palavra='yesterday'
                            destino='Exercicio' 
                            imagem='yesterday' 
                            palavrasCorretas={['ontem']}  
                            contexto='  '
                            voltar={'Indie2'}/>{'\n'}

          Because I made you <Botao palavra='cry'
                                    destino='Exercicio' 
                                    imagem='cry' 
                                    palavrasCorretas={['Chorar']}  
                                    contexto='  '
                                    voltar={'Indie2'}/>{'\n'}
          So before we die, I'd like to do something nice{'\n'}{'\n'}

          I want to buy you <Botao palavra='something'
                                   destino='Exercicio' 
                                   imagem='something' 
                                   palavrasCorretas={['algo', 'alguma coisa']}  
                                   contexto=' '
                                   voltar={'Indie2'}/>{'\n'}

          But I don't have any <Botao palavra='money'
                                      destino='Exercicio' 
                                      imagem='money' 
                                      palavrasCorretas={['dinheiro']}  
                                      contexto='  '
                                      voltar={'Indie2'}/>{'\n'}
          No, I don't have any <Botao palavra='money'
                                      destino='Exercicio' 
                                      imagem='money' 
                                      palavrasCorretas={['dinheiro']}  
                                      contexto='  '
                                      voltar={'Indie2'}/>{'\n'}
          I want to buy you something{'\n'}
          But I don't have any <Botao palavra='money'
                                      destino='Exercicio' 
                                      imagem='money' 
                                      palavrasCorretas={['dinheiro']}  
                                      contexto='  '
                                      voltar={'Indie2'}/>{'\n'}
          No, I don't have any <Botao palavra='money'
                                      destino='Exercicio' 
                                      imagem='money' 
                                      palavrasCorretas={['dinheiro']}  
                                      contexto='  '
                                      voltar={'Indie2'}/>{'\n'}{'\n'}

          And if I had a <Botao palavra='car'
                                destino='Exercicio' 
                                imagem='car' 
                                palavrasCorretas={['carro']}  
                                contexto='  '
                                voltar={'Indie2'}/>{'\n'}

          I would <Botao palavra='trade'
                         destino='Exercicio' 
                         imagem='trade ' 
                         palavrasCorretas={['venderia', 'vender', 'negociar', 'negociaria']}  
                         contexto=''
                         voltar={'Indie2'}/> in my <Botao palavra='car'
                                                                  destino='Exercicio' 
                                                                  imagem='car' 
                                                                  palavrasCorretas={['carro']}  
                                                                  contexto=' '
                                                                  voltar={'Indie2'}/>{'\n'}
          If I had a <Botao palavra='gun'
                            destino='Exercicio' 
                            imagem='gun' 
                            palavrasCorretas={['arma']}  
                            contexto='  '
                            voltar={'Indie2'}/>, I would trade in my <Botao palavra='gun'
                                                                                    destino='Exercicio' 
                                                                                    imagem='gun' 
                                                                                    palavrasCorretas={['arma']}  
                                                                                    contexto='  '
                                                                                    voltar={'Indie2'}/>{'\n'}
          <Botao palavra='honey'
                 destino='Exercicio' 
                 imagem='honey' 
                 palavrasCorretas={['mel']}  
                 contexto=' '
                 voltar={'Indie2'}/> we ran from the <Botao palavra='country'
                                                                    destino='Exercicio' 
                                                                    imagem='country regional map' 
                                                                    palavrasCorretas={['país']}  
                                                                    contexto=''
                                                                    voltar={'Indie2'}/>{'\n'}
          When we rushed to the city{'\n'}
          And now there's nothing to be done{'\n'}
          There's nothing to be done{'\n'}
          There's nothing to be done{'\n'}
          There's nothing to be done{'\n'}{'\n'}

          I want to buy you something{'\n'}
          But I don't <Botao palavra='have'
                             destino='Exercicio' 
                             imagem='have' 
                             palavrasCorretas={['tenho', 'ter']}  
                             contexto=' '
                             voltar={'Indie2'}/> any money{'\n'}

          No, I don't <Botao palavra='have'
                             destino='Exercicio' 
                             imagem='tenho' 
                             palavrasCorretas={['ter', 'tenho']}  
                             contexto='  '
                             voltar={'Indie2'}/> any money{'\n'}

          I want to buy you something{'\n'}
          But I don't have any money{'\n'}
          No, I don't have any money{'\n'}{'\n'}

          I want to buy you something{'\n'}
          But I don't have any money{'\n'}
          No, I don't have any money{'\n'}
          I want to buy you something{'\n'}
          But I don't have any money{'\n'}
          No, I don't have any money{'\n'}{'\n'}

          And I wanna buy you something{'\n'}
          But I don't have any money{'\n'}
          No, I don't have any money{'\n'}
          And I want to buy you something{'\n'}
          But I don't have any money{'\n'}
          No, I don't have any money{'\n'}{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Indie2;