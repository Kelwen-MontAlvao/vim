import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Indie3() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'TjPhzgxe3L0'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero4'/>
        <Text style={estilos.titulo}>
        The Smiths - Heaven Knows Im Miserable Now
        </Text>

        <Text style={estilos.letraMusica}>  
          I was happy in the haze of a <Botao palavra='drunken'
                                              destino='Exercicio' 
                                              imagem='drunken hour' 
                                              palavrasCorretas={['bebado', 'bebedeira']}  
                                              contexto='  '
                                              voltar={'Indie3'}/> hour {'\n'}

          But heaven knows I'm <Botao palavra='miserable'
                                      destino='Exercicio' 
                                      imagem='miserable people' 
                                      palavrasCorretas={['miserável']}  
                                      contexto='  '
                                      voltar={'Indie3'}/> now{'\n'}{'\n'}

          I was looking for a job, and then I found a job{'\n'}
          And <Botao palavra='heaven'
                     destino='Exercicio' 
                     imagem='heaven ' 
                     palavrasCorretas={['paraíso', 'céu']}  
                     contexto='  '
                     voltar={'Indie3'}/> knows I'm miserable now{'\n'}{'\n'}

          In my life{'\n'}
          Why do I give<Botao palavra='valuable'
                              destino='Exercicio' 
                              imagem='valuable' 
                              palavrasCorretas={['valioso']}  
                              contexto='  '
                              voltar={'Indie3'}/> time{'\n'}

          To people who don't<Botao palavra='care'
                                    destino='Exercicio' 
                                    imagem='care' 
                                    palavrasCorretas={['importam', 'importa']}  
                                    contexto=' '
                                    voltar={'Indie3'}/> if I live or die?{'\n'}{'\n'}

          Two lovers entwined pass me by{'\n'}
          And heaven knows I'm miserable <Botao palavra='now'
                                                destino='Exercicio' 
                                                imagem='now' 
                                                palavrasCorretas={['agora']}  
                                                contexto=' '
                                                voltar={'Indie3'}/>{'\n'}

          I was looking for a <Botao palavra='job'
                                     destino='Exercicio' 
                                     imagem='job' 
                                     palavrasCorretas={['trabalho', 'profissão']}  
                                     contexto=' O que se faz da vida, não sendo apenas momentâneo'
                                     voltar={'Indie3'}/>, and then I found a job{'\n'}
          And <Botao palavra='heaven'
                     destino='Exercicio' 
                     imagem='heaven ' 
                     palavrasCorretas={['paraíso', 'céu']}  
                     contexto='  '
                     voltar={'Indie3'}/> knows I'm miserable now{'\n'}{'\n'}

          In my life{'\n'}
          Oh, why do I give valuable time{'\n'}
          To people who don't care if I live or die?{'\n'}{'\n'}

          What she asked of me at the end of the day{'\n'}
          Caligula would have<Botao palavra='blushed'
                                    destino='Exercicio' 
                                    imagem='blushed' 
                                    palavrasCorretas={['corar', 'corou', 'coraria']}  
                                    contexto='  '
                                    voltar={'Indie3'}/>{'\n'}{'\n'}

          "Oh, you've been in the<Botao palavra='house'
                                        destino='Exercicio' 
                                        imagem='house' 
                                        palavrasCorretas={['casa']}  
                                        contexto=' '
                                        voltar={'Indie3'}/> too long" she said{'\n'}
          And I naturally fled{'\n'}{'\n'}

          In my life{'\n'}
          Why do I <Botao palavra='smile'
                          destino='Exercicio' 
                          imagem='smile' 
                          palavrasCorretas={['sorriso']}  
                          contexto='  '
                          voltar={'Indie3'}/>{'\n'}
          At people who I'd much rather kick in the eye?{'\n'}{'\n'}

          I was happy in the <Botao palavra='haze'
                                    destino='Exercicio' 
                                    imagem='haze' 
                                    palavrasCorretas={['confusão']}  
                                    contexto='  '
                                    voltar={'Indie3'}/> of a drunken hour{'\n'}
          But heaven knows I'm miserable now{'\n'}{'\n'}

          "Oh, you've been in the house too long" she said{'\n'}
          And I <Botao palavra='naturally'
                       destino='Exercicio' 
                       imagem='naturally' 
                       palavrasCorretas={['naturalmente']}  
                       contexto='  '
                       voltar={'Indie3'}/> fled{'\n'}{'\n'}

          In my life{'\n'}
          Oh, why do I give valuable time{'\n'}
          To people who don't care if I live or die?{'\n'}{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Indie3;