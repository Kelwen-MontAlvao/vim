import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao';
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Indie7() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback((state) => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying((prev) => !prev);
  }, []);

  const bancodedadosId = 'bpOSxM0rNPM'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
        <BotaoVoltar destino="Genero4" />
        <Text style={estilos.titulo}>Arctic Monkeys - Do I Wanna Know?</Text>
        <Text style={estilos.letraMusica}>
        <Botao palavra='cheeks'
    destino='Exercicio'
    imagem='cheek'
    palavrasCorretas={['bochecha', 'bochechas', 'rosto', 'face']}
    contexto=''
    voltar={'Indie7'}/>

Do you ever get that fear that you can't shift {"\n"}
The type that <Botao palavra='sticks'
    destino='Exercicio'
    imagem='stick'
    palavrasCorretas={['grudar', 'colar','cola','gruda']}
    contexto=''
    voltar={'Indie7'}/> {"\n"}

around like summat in your <Botao palavra='teeth'
    destino='Exercicio'
    imagem='teeth'
    palavrasCorretas={['dente', 'dentes']}
    contexto=''
    voltar={'Indie7'}/> {"\n"}

Are there some <Botao palavra='aces'
    destino='Exercicio'
    imagem='ace'
    palavrasCorretas={['ás', 'cartas']}
    contexto=''
    voltar={'Indie7'}/> {"\n"}

up your <Botao palavra='sleeve'
    destino='Exercicio'
    imagem='sleeve'
    palavrasCorretas={['manga', 'mangas', 'blusa']}
    contexto=''
    voltar={'Indie7'}/> {"\n"}

Have you no idea that you're in deep?{"\n"}
I dreamt about you nearly every night this week{"\n"}{'\n'}

How many secrets can you <Botao palavra='keep'
    destino='Exercicio'
    imagem='keep'
    palavrasCorretas={['guardar']}
    contexto=''
    voltar={'Indie7'}/> {"\n"}

'Cause there's this <Botao palavra='tune'
    destino='Exercicio'
    imagem='tune'
    palavrasCorretas={['música', 'musica', 'som', 'tom']}
    contexto=''
    voltar={'Indie7'}/> I found {"\n"}

That makes me think of you somehow{"\n"}
And I play it on repeat{"\n"}
Until I fall asleep{"\n"}

<Botao palavra='Spilling'
    destino='Exercicio'
    imagem='spilling'
    palavrasCorretas={['derramar', 'derramando', 'derrubar', 'derrubando']}
    contexto=''
    voltar={'Indie7'}/>

drinks on my <Botao palavra='sette'
    destino='Exercicio'
    imagem='sofa'
    palavrasCorretas={['sofá', 'sofa']}
    contexto=''
    voltar={'Indie7'}/> {"\n"}{'\n'}

(Do I wanna know){"\n"}
If this feeling flows both ways?{"\n"}
(Sad to see you go){"\n"}
Was sorta hoping that you'd stay{"\n"}
(Baby, we both know){"\n"}
That the nights were mainly made{"\n"}
For saying things that you can't say tomorrow day{"\n"}{'\n'}

<Botao palavra='Crawling'
    destino='Exercicio'
    imagem='craw'
    palavrasCorretas={['arrastar', 'arrastando', 'engatinhar', 'engatinhando']}
    contexto=''
    voltar={'Indie7'}/> back to you{"\n"}

Ever thought of calling when you've had a few?{"\n"}
'Cause I always do{"\n"}
Maybe I'm <Botao palavra='too busy'
    destino='Exercicio'
    imagem='busy'
    palavrasCorretas={['ocupado', 'focado']}
    contexto=''
    voltar={'Indie7'}/> being yours to fall for somebody new{"\n"}
Now, I've thought it through{"\n"}

<Botao palavra='Crawling'
    destino='Exercicio'
    imagem='craw'
    palavrasCorretas={['arrastar', 'arrastando', 'engatinhar', 'engatinhando']}
    contexto=''
    voltar={'Indie7'}/> back to you{"\n"}{'\n'}

So, have you got the <Botao palavra='guts'
    destino='Exercicio'
    imagem='courage'
    palavrasCorretas={['coragem', 'força', 'capaz']}
    contexto=''
    voltar={'Indie7'}/> {"\n"}

Been <Botao palavra='wondering'
    destino='Exercicio'
    imagem='think'
    palavrasCorretas={['pensando', 'refletindo']}
    contexto=''
    voltar={'Indie7'}/> if your heart's still open{"\n"}

And if so, I wanna know what time it shuts{"\n"}
Simmer down and pucker up{"\n"}
I'm sorry to interrupt, it's just I'm constantly on the <Botao palavra='cusp'
    destino='Exercicio'
    imagem='cusp'
    palavrasCorretas={['beira', 'beirada']}
    contexto=''
    voltar={'Indie7'}/> {"\n"}
Of trying to kiss you{"\n"}
I don't know if you feel the same as I do{"\n"}
But we could be together if you wanted to{"\n"}{'\n'}

(Do I wanna know){"\n"}
If this feeling flows both ways?{"\n"}
(Sad to see you go){"\n"}
Was sorta hoping that you'd stay{"\n"}
(Baby, we both know){"\n"}
That the nights were mainly made{"\n"}
For saying things that you can't say tomorrow day{"\n"}{'\n'}

Crawling back to you (crawling back to you){"\n"}
Ever thought of calling when you've had a few? (You've had a few?){"\n"}
'Cause I always do ('cause I always do){"\n"}
Maybe I'm too (maybe I'm too busy){"\n"}
Busy being yours (being yours){"\n"}
To fall for somebody new{"\n"}
Now, I've thought it through{"\n"}
Crawling back to you{"\n"}{'\n'}

(Do I wanna know){"\n"}
If this feeling flows both ways?{"\n"}
(Sad to see you go){"\n"}
Was sorta hoping that you'd stay{"\n"}
(Baby, we both know){"\n"}
That the nights were mainly made{"\n"}
For saying things that you can't say tomorrow day{"\n"}{'\n'}

(Do I wanna know?){"\n"}
Too busy being yours to fall{"\n"}
(Sad to see you go){"\n"}
Ever thought of <Botao palavra='calling'
    destino='Exercicio'
    imagem='calling'
    palavrasCorretas={['chamando', 'ligando']}
    contexto=''
    voltar={'Indie7'}/>, darling? {"\n"}{'\n'}

(Do I wanna know?){"\n"}
Do you want me crawling back to you?{"\n"}{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000',
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10,
    marginVertical: 10,
  },
});

export default Indie7;
