import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao';
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Indie6() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback((state) => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying((prev) => !prev);
  }, []);

  const bancodedadosId = 'rVeMiVU77wo'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
        <BotaoVoltar destino="Genero4" />
        <Text style={estilos.titulo}>Alt-J - Breezeblocks</Text>
        <Text style={estilos.letraMusica}>
          She may contain{"\n"}
          The urge to{" "}
          <Botao
            palavra="run away"
            destino="Exercicio"
            imagem="run"
            palavrasCorretas={['fugir', 'fuga', 'fugindo']}
            contexto=""
            voltar={'Indie6'}
          />{" "}
          {"\n"}
          But hold her down with{" "}
          <Botao
            palavra="soggy"
            destino="Exercicio"
            imagem="soggy"
            palavrasCorretas={['molhado', 'encharcado', 'encharcada', 'molhada']}
            contexto=""
            voltar={'Indie6'}
          />{" "}
          clothes and{" "}
          <Botao
            palavra="breezeblocks"
            destino="Exercicio"
            imagem="breezeblocks"
            palavrasCorretas={['tijolo de concreto', 'bloco de concreto', 'blocos de concreto', 'concreto', 'tijolo', 'parede']}
            contexto=""
            voltar={'Indie6'}
          />{"\n"}
          Cetirizine your{" "}
          <Botao
            palavra="fever's"
            destino="Exercicio"
            imagem="fever"
            palavrasCorretas={['febre']}
            contexto=""
            voltar={'Indie6'}
          />
          {" "}
          <Botao
            palavra="gripped"
            destino="Exercicio"
            imagem="attack"
            palavrasCorretas={['atacou']}
            contexto=""
            voltar={'Indie6'}
          />{"\n"}
          Never kisses{"\n"}
          All you ever send are{" "}{'\n'}
          <Botao
            palavra="full-stops"
            destino="Exercicio"
            imagem="game over"
            palavrasCorretas={['acaba', 'acabado', 'ponto final']}
            contexto=""
            voltar={'Indie6'}
          />{"\n"}{'\n'}

          Do you know{"\n"}
          Where the wild things go{"\n"}
          They go along to take your honey{"\n"}{'\n'}

          <Botao
            palavra="Break down"
            destino="Exercicio"
            imagem="break"
            palavrasCorretas={['caia', 'desmorone', 'quebre']}
            contexto=""
            voltar={'Indie6'}
          />{" "}
          now weep, build up breakfast, now let's eat{"\n"}
          My love, my love, love, love{"\n"}{'\n'}

          Muscle to muscle and{" "}
          <Botao
            palavra="toe"
            destino="Exercicio"
            imagem="toe"
            palavrasCorretas={['dedo', 'dedos']}
            contexto=""
            voltar={'Indie6'}
          />{" "}
          to toe{"\n"}
          The{" "}
          <Botao
            palavra="fear"
            destino="Exercicio"
            imagem="fear"
            palavrasCorretas={['horror', 'medo']}
            contexto=""
            voltar={'Indie6'}
          />{" "}
          has gripped me but here I go{"\n"}
          My heart{" "}
          <Botao
            palavra="sink"
            destino="Exercicio"
            imagem="sink"
            palavrasCorretas={['afundando', 'afundar', 'afunda']}
            contexto=""
            voltar={'Indie6'}
          />{" "}
          as I jump up{"\n"}
          Your hand{" "}
          <Botao
            palavra="grips"
            destino="Exercicio"
            imagem="grip"
            palavrasCorretas={['agarrar', 'agarrando', 'segurar', 'segurando']}
            contexto=""
            voltar={'Indie6'}
          />{" "}
          hand as my eyes{" "}
          <Botao
            palavra="shut"
            destino="Exercicio"
            imagem="closed"
            palavrasCorretas={['fechar', 'fechando']}
            contexto=""
            voltar={'Indie6'}
          />{"\n"}{'\n'}

          Do you know{"\n"}
          Where the{" "}
          <Botao
            palavra="wild"
            destino="Exercicio"
            imagem="wild"
            palavrasCorretas={['selvagem', 'perigosos', 'selvagens']}
            contexto=""
            voltar={'Indie6'}
          />{" "}
          things go{"\n"}
          They go along to take your{" "}
          <Botao
            palavra="honey"
            destino="Exercicio"
            imagem="honey"
            palavrasCorretas={['mel', 'querida']}
            contexto="A tradução literal da palavra é 'querida', mas na música, refere-se ao mel"
            voltar={'Indie6'}
          />{"\n"}
          Break down, let's sleep{"\n"}
          Build up breakfast, now let's eat{"\n"}
          My love, my love, love, love{"\n"}{'\n'}

          She bruises{" "}
          <Botao
            palavra="coughs"
            destino="Exercicio"
            imagem="cough"
            palavrasCorretas={['tossir', 'tosse', 'tossindo']}
            contexto=""
            voltar={'Indie6'}
          />{" "}
          coughs{"\n"}
          She splutters pistol shots{"\n"}
          But hold her down with{" "}
          <Botao
            palavra="soggy"
            destino="Exercicio"
            imagem="roupa molhada"
            palavrasCorretas={['molhado', 'encharcado', 'encharcada', 'molhada']}
            contexto=""
            voltar={'Indie6'}
          />{" "}
          clothes and{" "}
          <Botao
            palavra="breezeblocks"
            destino="Exercicio"
            imagem="breezeblock"
            palavrasCorretas={['tijolo de concreto', 'bloco de concreto', 'blocos de concreto', 'concreto', 'tijolo', 'parede']}
            contexto=""
            voltar={'Indie6'}
          />{"\n"}
          She's morphine{"\n"}
          Queen of my vaccine{"\n"}
          My love, my love, love, love{"\n"}{'\n'}

          Muscle to muscle and{" "}
          <Botao
            palavra="toe"
            destino="Exercicio"
            imagem="toe"
            palavrasCorretas={['dedo', 'dedos']}
            contexto=""
            voltar={'Indie6'}
          />{"\n"}
          The{" "}
          <Botao
            palavra="fear"
            destino="Exercicio"
            imagem="fear"
            palavrasCorretas={['horror', 'medo']}
            contexto=""
            voltar={'Indie6'}
          />{" "}
          has gripped me but here I go{"\n"}
          My heart{" "}
          <Botao
            palavra="sink"
            destino="Exercicio"
            imagem="sink"
            palavrasCorretas={['afundando', 'afundar']}
            contexto=""
            voltar={'Indie6'}
          />{" "}
          as I jump up{"\n"}
          Your hand{" "}
          <Botao
            palavra="grips"
            destino="Exercicio"
            imagem="grips"
            palavrasCorretas={['agarrar', 'agarrando', 'segurar', 'segurando']}
            contexto=""
            voltar={'Indie6'}
          />{" "}
          hand as my eyes{" "}
          <Botao
            palavra="shut"
            destino="Exercicio"
            imagem="shut"
            palavrasCorretas={['fechar', 'fechando', 'fecham', 'fecha']}
            contexto=""
            voltar={'Indie6'}
          />{"\n"}
          Please don't go, I love you so, I love you so{'\n'}{'\n'}
        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000',
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10,
    marginVertical: 10,
  },
});

export default Indie6;
