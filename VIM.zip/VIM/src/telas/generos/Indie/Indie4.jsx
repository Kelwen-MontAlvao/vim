import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Indie4() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'Co7t6NxsW-4'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero4'/>
        <Text style={estilos.titulo}>
        Notion - The Rare Ocasions 
        </Text>

        <Text style={estilos.letraMusica}>  
          Sure, it's a calming <Botao palavra='notion'
                                      destino='Exercicio' 
                                      imagem='notion' 
                                      palavrasCorretas={['noção']}  
                                      contexto='  '
                                      voltar={'Indie4'}/>, perpetual in <Botao palavra='motion'
                                                                                       destino='Exercicio' 
                                                                                       imagem='motion' 
                                                                                       palavrasCorretas={['movimento']}  
                                                                                       contexto=' '
                                                                                       voltar={'Indie4'}/> {'\n'}
          But I don't need the <Botao palavra='comfort'
                                      destino='Exercicio' 
                                      imagem='comfort' 
                                      palavrasCorretas={['conforto']}  
                                      contexto='  '
                                      voltar={'Indie4'}/> of any lies{'\n'}

          For I have seen the <Botao palavra='ending'
                                     destino='Exercicio' 
                                     imagem='ending' 
                                     palavrasCorretas={['final', 'fim']}  
                                     contexto=' '
                                     voltar={'Indie4'}/> and there is no ascending{'\n'}
          Rise{'\n'}{'\n'}

          Oh, back when I was younger, was told by other <Botao palavra='youngsters'
                                                                destino='Exercicio' 
                                                                imagem='youngsters' 
                                                                palavrasCorretas={['jovens', 'mais jovens', 'mais novos']}  
                                                                contexto='  '
                                                                voltar={'Indie4'}/>{'\n'}
          That my end will be torture beneath the <Botao palavra='earth'
                                                         destino='Exercicio' 
                                                         imagem='earth' 
                                                         palavrasCorretas={['Terra']}  
                                                         contexto='  '
                                                         voltar={'Indie4'}/>{'\n'}

          'Cause I don't see what they see, when <Botao palavra='death'
                                                        destino='Exercicio' 
                                                        imagem='death' 
                                                        palavrasCorretas={['morte']}  
                                                        contexto='  '
                                                        voltar={'Indie4'}/>is staring at me{'\n'}

          I see a window, a limit, to live it, or not at all{'\n'}{'\n'}

          If you could pull the lever to carry on forever{'\n'}
          Would your life even matter anymore?{'\n'}
          Sure it's a <Botao palavra='calming'
                             destino='Exercicio' 
                             imagem='calming' 
                             palavrasCorretas={['calmo', 'acalmante']}  
                             contexto=' '
                             voltar={'Indie4'}/> notion, <Botao palavra='perpetual'
                                                                        destino='Exercicio' 
                                                                        imagem='perpetual' 
                                                                        palavrasCorretas={['perpétuo', 'perpetuante']}  
                                                                        contexto='  '
                                                                        voltar={'Indie4'}/> in motion{'\n'}

          But it's not what you signed up for{'\n'}{'\n'}

          I'm sure there won't always be <Botao palavra='sunshine'
                                                destino='Exercicio' 
                                                imagem='sunshine' 
                                                palavrasCorretas={['luz do sol']}  
                                                contexto=' Uma coisa bela, tal como natural '
                                                voltar={'Indie4'}/>{'\n'}

          But there's this momentary beam of <Botao palavra='light'
                                                    destino='Exercicio' 
                                                    imagem='light' 
                                                    palavrasCorretas={['luz', 'iluminação', 'clareza']}  
                                                    contexto='Sendo utilizada para expressar um momento'
                                                    voltar={'Indie4'}/>{'\n'}

          You don't have to wait those salty decades{'\n'}
          To get through the gate, it's all in front of your face{'\n'}{'\n'}

          I'm sure there won't always be <Botao palavra='sunshine'
                                                destino='Exercicio' 
                                                imagem='sunshine' 
                                                palavrasCorretas={['luz do sol']}  
                                                contexto=' Uma coisa bela, tal como natural'
                                                voltar={'Indie4'}/>{'\n'}

          I'm sure there won't always be <Botao palavra='sunshine'
                                                destino='Exercicio' 
                                                imagem='sunshine' 
                                                palavrasCorretas={['luz do sol']}  
                                                contexto=' Uma coisa bela, tal como natural '
                                                voltar={'Indie4'}/>{'\n'}

          But there's this momentary <Botao palavra='beam'
                                            destino='Exercicio' 
                                            imagem='beam of light' 
                                            palavrasCorretas={['feixe']}  
                                            contexto='  '
                                            voltar={'Indie4'}/>of light{'\n'}{'\n'}

          I could cross the <Botao palavra='ocean'
                                   destino='Exercicio' 
                                   imagem='ocean' 
                                   palavrasCorretas={['oceano']}  
                                   contexto='  '
                                   voltar={'Indie4'}/> in a fit of <Botao palavra='devotion'
                                                                                  destino='Exercicio' 
                                                                                  imagem='devotion' 
                                                                                  palavrasCorretas={['devoção']}  
                                                                                  contexto='  '
                                                                                  voltar={'Indie4'}/>{'\n'}
          For every shining second, this <Botao palavra='fragile'
                                                destino='Exercicio' 
                                                imagem='fragile' 
                                                palavrasCorretas={['frágil']}  
                                                contexto='  '
                                                voltar={'Indie4'}/> body beckons{'\n'}
          You think you're owed it better believing ancient <Botao palavra='letters'
                                                                   destino='Exercicio' 
                                                                   imagem='letters' 
                                                                   palavrasCorretas={['cartas']}  
                                                                   contexto=' '
                                                                   voltar={'Indie4'}/>{'\n'}

          Sure, it's a calming notion, but it's a <Botao palavra='lie'
                                                         destino='Exercicio' 
                                                         imagem='lie' 
                                                         palavrasCorretas={['mentira']}  
                                                         contexto='  '
                                                         voltar={'Indie4'}/>{'\n'}{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Indie4;