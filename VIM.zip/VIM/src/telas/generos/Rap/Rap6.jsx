import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rap6() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = '6tjlU4w4fSo'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero3'/>
        <Text style={estilos.titulo}>
        J. Cole - Love Yourz
        </Text>

        <Text style={estilos.letraMusica}>  
        <Botao palavra='Love'
       destino='Exercicio' 
       imagem='Love' 
       palavrasCorretas={['Amor']}  
       contexto='  '
       voltar={'Rap6'}/> Yours{'\n'}

<Botao palavra='Love'
       destino='Exercicio' 
       imagem='Love' 
       palavrasCorretas={['Amor']}  
       contexto='  '
       voltar={'Rap6'}/> Yours{'\n'}{'\n'}

No such thing as a life that's better than yours{'\n'}
No such thing as a life that's better than yours{'\n'}
No such thing as a life that's better than yours{'\n'}
No such thing, no such thing{'\n'}{'\n'}

<Botao palavra='heart'
       destino='Exercicio' 
       imagem='heart' 
       palavrasCorretas={['coração', 'coracao']}  
       contexto='  '
       voltar={'Rap6'}/> beatin' fast, let a nigga know that he <Botao palavra='alive'
                                                                        destino='Exercicio' 
                                                                        imagem='alive' 
                                                                        palavrasCorretas={['Vivo']}  
                                                                        contexto='  '
                                                                        voltar={'Rap6'}/>{'\n'}

Fake niggas mad, <Botao palavra='snakes'
                        destino='Exercicio' 
                        imagem='snakes' 
                        palavrasCorretas={['cobras']}  
                        contexto='  '
                        voltar={'Rap6'}/>{'\n'}
                        
<Botao palavra='Snakes'
                destino='Exercicio' 
                imagem='snakes' 
                palavrasCorretas={['cobras']}  
                contexto='  '
                voltar={'Rap6'}/> in the <Botao palavra='grass'
                                                destino='Exercicio' 
                                                imagem='grass' 
                                                palavrasCorretas={['grama', 'mato']}  
                                                contexto='  '
                                                voltar={'Rap6'}/> let a nigga know that he arrive{'\n'}

Don't be sleepin' on your level cause its <Botao palavra='beauty'
                                                destino='Exercicio' 
                                                imagem='beauty' 
                                                palavrasCorretas={['beleza']}  
                                                contexto='  '
                                                voltar={'Rap6'}/> in the struggle nigga{'\n'}
Goes for all y'all{'\n'}
It's beauty in the struggle nigga{'\n'}
(Let me explain){'\n'}
It's beauty in the struggle, ugliness in the success{'\n'}{'\n'}

Hear my <Botao palavra='words'
                destino='Exercicio' 
                imagem='words' 
                palavrasCorretas={['palavras']}  
                contexto='  '
                voltar={'Rap6'}/> or listen to my signal of distress{'\n'}

I grew up in the <Botao palavra='city'
                        destino='Exercicio' 
                        imagem='city' 
                        palavrasCorretas={['cidade']}  
                        contexto='  '
                        voltar={'Rap6'}/> and though some times we had less{'\n'}{'\n'}

Compared to some of my niggas down the block man we were blessed{'\n'}
And life can't be no fairytale, no once upon a <Botao palavra='time'
                                                    destino='Exercicio' 
                                                    imagem='time' 
                                                    palavrasCorretas={['tempo']}  
                                                    contexto='  '
                                                    voltar={'Rap6'}/>{'\n'}
But I be God damned if a nigga don't be tryin'{'\n'}
So tell me mama please why you be <Botao palavra='drinking'
                                        destino='Exercicio' 
                                        imagem='drinking' 
                                        palavrasCorretas={['bebendo']}  
                                        contexto='  '
                                        voltar={'Rap6'}/> all the time?{'\n'}{'\n'}

Does all the <Botao palavra='pain'
                    destino='Exercicio' 
                    imagem='pain' 
                    palavrasCorretas={['dor', 'dores']}  
                    contexto='  '
                    voltar={'Rap6'}/> he brought you still linger in your mind?{'\n'}

Cause <Botao palavra='pain'
            destino='Exercicio' 
            imagem='pain' 
            palavrasCorretas={['dor', 'dores']}  
            contexto='  '
            voltar={'Rap6'}/> still lingers on mine{'\n'}
On the road to riches listen this is what you'll find{'\n'}
The good news is nigga you came a long way{'\n'}
The bad news is nigga you went the wrong way{'\n'}{'\n'}

Think being <Botao palavra='broke'
                    destino='Exercicio' 
                    imagem='broke' 
                    palavrasCorretas={['quebrou']}  
                    contexto='  '
                    voltar={'Rap6'}/> was better{'\n'}

For what's money without <Botao palavra='happiness'
                                destino='Exercicio' 
                                imagem='happiness' 
                                palavrasCorretas={['felicidade']}  
                                contexto='  '
                                voltar={'Rap6'}/>?{'\n'}

Or hard times without the <Botao palavra='people'
                                destino='Exercicio' 
                                imagem='people' 
                                palavrasCorretas={['pessoas']}  
                                contexto='  '
                                voltar={'Rap6'}/> you love{'\n'}
Though I'm not sure what's 'bout to happen next{'\n'}
I <Botao palavra='asked'
        destino='Exercicio' 
        imagem='asked' 
        palavrasCorretas={['perguntou', 'pergunta']}  
        contexto='  '
        voltar={'Rap6'}/> for strength from the lord up above{'\n'}
Cause I've been strong so far{'\n'}
But I can feel my grip loosening{'\n'}
Quick, do something before you <Botao palavra='lose'
                                    destino='Exercicio' 
                                    imagem='lose' 
                                    palavrasCorretas={['perder']}  
                                    contexto='  '
                                    voltar={'Rap6'}/> it for good{'\n'}
Get it back and use it for good{'\n'}
And <Botao palavra='touch'
            destino='Exercicio' 
            imagem='touch' 
            palavrasCorretas={['tocar', 'toque']}  
            contexto='  '
            voltar={'Rap6'}/> the people how you did like before{'\n'}{'\n'}

I'm tired of living with demons cause they always inviting more{'\n'}
Think being <Botao palavra='broke'
                    destino='Exercicio' 
                    imagem='broke' 
                    palavrasCorretas={['quebrou']}  
                    contexto='  '
                    voltar={'Rap6'}/> was better{'\n'}
Now I don't mean that phrase with no disrespect{'\n'}
To all my niggas out there living in debt{'\n'}
Cashing minimal checks{'\n'}
Turn on the tv see a nigga rolex{'\n'}
And fantasize about a life with no stress{'\n'}
I mean this shit sincerely{'\n'}
And that's a nigga who was once in your shoes{'\n'}
Living with nothin' to lose{'\n'}
I hope one day you hear me{'\n'}{'\n'}

Always gon' be a bigger <Botao palavra='house'
                                destino='Exercicio' 
                                imagem='house' 
                                palavrasCorretas={['casa']}  
                                contexto='  '
                                voltar={'Rap6'}/> somewhere, but nigga feel me{'\n'}

Long as the people in that motherfucker <Botao palavra='Love'
                                                destino='Exercicio' 
                                                imagem='Love' 
                                                palavrasCorretas={['Amor']}  
                                                contexto='  '
                                                voltar={'Rap6'}/> you dearly{'\n'}{'\n'}
                                                
Always gon' be a whip that's better than the the one you got{'\n'}
Always gon' be some <Botao palavra='clothes'
                            destino='Exercicio' 
                            imagem='clothes' 
                            palavrasCorretas={['roupas', 'roupa']}  
                            contexto='  '
                            voltar={'Rap6'}/> that's fresher than the ones you rock{'\n'}
Always gon' be a bitch that's badder out there on the tours{'\n'}{'\n'}

But you ain't never gon' be <Botao palavra='happy'
                                    destino='Exercicio' 
                                    imagem='happy' 
                                    palavrasCorretas={['feliz']}  
                                    contexto='  '
                                    voltar={'Rap6'}/> till you <Botao palavra='Love'
                                                                        destino='Exercicio' 
                                                                        imagem='Love' 
                                                                        palavrasCorretas={['Amor']}  
                                                                        contexto='  '
                                                                        voltar={'Rap6'}/> yours{'\n'}
Heart beatin' fast, let a nigga know that he alive{'\n'}
Fake niggas mad, snakes{'\n'}
Snakes in the grass let a nigga know that he arrive{'\n'}{'\n'}
        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rap6;