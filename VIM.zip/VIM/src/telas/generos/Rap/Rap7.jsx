import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rap7() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'OjHX7jf-znA'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero3'/>
        <Text style={estilos.titulo}>
        Common - The Light
        </Text>

        <Text style={estilos.letraMusica}>  
        Yeah{'\n'}
Doo-doo-doo, mmm-mmm-mmm-mmm-mmm.{'\n'}
Doo-doo-d-doo, diggy-doo YO{'\n'}{'\n'}

I never knew a luh, luh-luh, a <Botao palavra='love'
                                        destino='Exercicio' 
                                        imagem='love' 
                                        palavrasCorretas={['amor', 'amar']}  
                                        contexto='  '
                                        voltar={'Rap7'}/> like this{'\n'}
Gotta be somethin for me to <Botao palavra='write'
                                    destino='Exercicio' 
                                    imagem='write' 
                                    palavrasCorretas={['escrever']}  
                                    contexto='  '
                                    voltar={'Rap7'}/> this{'\n'}
Queen, I ain't seen you in a minute{'\n'}
Wrote this <Botao palavra='letter'
                destino='Exercicio' 
                imagem='letter' 
                palavrasCorretas={['carta']}  
                contexto='  '
                voltar={'Rap7'}/>, and finally decide to send it{'\n'}{'\n'}

Signed sealed delivered for us to grow together{'\n'}
<Botao palavra='Love'
        destino='Exercicio' 
        imagem='love' 
        palavrasCorretas={['amor', 'amar']}  
        contexto='  '
        voltar={'Rap7'}/> has no limit, let's spend it <Botao palavra='slow'
                                                                destino='Exercicio' 
                                                                imagem='slow' 
                                                                palavrasCorretas={['devagar', 'lento']}  
                                                                contexto='  '
                                                                voltar={'Rap7'}/> forever{'\n'}
I know your heart is weathered by what <Botao palavra='studs'
                                                destino='Exercicio' 
                                                imagem='studs' 
                                                palavrasCorretas={['prego', 'pregos']}  
                                                contexto='  '
                                                voltar={'Rap7'}/> did to you{'\n'}
I ain't gon' assault em cause I probably did it too{'\n'}{'\n'}

Because of you, feelings I handle with care{'\n'}
Some niggaz recognize the <Botao palavra='light'
                                destino='Exercicio' 
                                imagem='light' 
                                palavrasCorretas={['luz']}  
                                contexto='  '
                                voltar={'Rap7'}/> but they can't handle the glare{'\n'}
You know I ain't the type to <Botao palavra='walk'
                                    destino='Exercicio' 
                                    imagem='walk' 
                                    palavrasCorretas={['andar']}  
                                    contexto='  '
                                    voltar={'Rap7'}/> around with matchin <Botao palavra='shirts'
                                                                                destino='Exercicio' 
                                                                                imagem='shirts' 
                                                                                palavrasCorretas={['camisas', 'camisa']}  
                                                                                contexto='  '
                                                                                voltar={'Rap7'}/>{'\n'}
If relationship is effort I will match your work{'\n'}{'\n'}

I wanna be the one to make you happiest, it hurts you the most{'\n'}
They <Botao palavra='say'
            destino='Exercicio' 
            imagem='say' 
            palavrasCorretas={['dizer']}  
            contexto='  '
            voltar={'Rap7'}/> the end is near, it's important that we close.{'\n'}
To the most, high{'\n'}
Regardless of what happen on him let's rely{'\n'}{'\n'}

There are times. when you'll need someone.{'\n'}
I will be by your side.{'\n'}
There is a <Botao palavra='light'
                    destino='Exercicio' 
                    imagem='light' 
                    palavrasCorretas={['luz']}  
                    contexto='  '
                    voltar={'Rap7'}/>, that shines,{'\n'}
Special for you, and me.{'\n'}{'\n'}

Yo, yo, check it{'\n'}
It's important, we communicate{'\n'}
And tune the fate of this union, to the right pitch{'\n'}
I never call you my bitch or even my boo{'\n'}
There's so much in a name and so much more in you{'\n'}{'\n'}

Few understand the union of woman and man{'\n'}
And sex and a tingle is where they assume that it land{'\n'}
But that's fly by night for you and the <Botao palavra='sky'
                                                destino='Exercicio' 
                                                imagem='sky' 
                                                palavrasCorretas={['céu', 'ceu']}  
                                                contexto='  '
                                                voltar={'Rap7'}/> I write{'\n'}
For in these cold Chi night's <Botao palavra='moon'
                                    destino='Exercicio' 
                                    imagem='moon' 
                                    palavrasCorretas={['lua']}  
                                    contexto='  '
                                    voltar={'Rap7'}/>, you my <Botao palavra='light'
                                                                    destino='Exercicio' 
                                                                    imagem='light' 
                                                                    palavrasCorretas={['luz']}  
                                                                    contexto='  '
                                                                    voltar={'Rap7'}/>{'\n'}{'\n'}

If heaven had a height, you would be that tall{'\n'}
Ghetto to <Botao palavra='coffee'
                destino='Exercicio' 
                imagem='coffee' 
                palavrasCorretas={['café', 'cafe']}  
                contexto='  '
                voltar={'Rap7'}/> shop, through you I see that all{'\n'}
Let's stick to understandin' and we won't <Botao palavra='fall'
                                                destino='Exercicio' 
                                                imagem='fall' 
                                                palavrasCorretas={['cair']}  
                                                contexto='  '
                                                voltar={'Rap7'}/>{'\n'}
For better or worse times, I hope to me you <Botao palavra='call'
                                    destino='Exercicio' 
                                    imagem='call' 
                                    palavrasCorretas={['ligar', 'contar', 'falar']}  
                                    contexto='  '
                                    voltar={'Rap7'}/>{'\n'}{'\n'}

So I <Botao palavra='pray'
            destino='Exercicio' 
            imagem='pray' 
            palavrasCorretas={['rezar', 'orar', 'oração']}  
            contexto='  '
            voltar={'Rap7'}/> everyday more than anything{'\n'}
<Botao palavra='Friends'
        destino='Exercicio' 
        imagem='friends' 
        palavrasCorretas={['amigos']}  
        contexto='  '
        voltar={'Rap7'}/> will stay as we begin to lay{'\n'}
This foundation for a family - <Botao palavra='love'
                                        destino='Exercicio' 
                                        imagem='love' 
                                        palavrasCorretas={['amor', 'amar']}  
                                        contexto='  '
                                        voltar={'Rap5'}/> ain't simple{'\n'}
Why can't it be anything worth having you work at annually?{'\n'}
Granted we known each other for some time{'\n'}
It don't take a whole day to recognize sunshine{'\n'}{'\n'}

There are times. when you'll need someone.{'\n'}
I will be by your side, oh darling{'\n'}
There is a <Botao palavra='light'
                destino='Exercicio' 
                imagem='light' 
                palavrasCorretas={['luz']}  
                contexto='  '
                voltar={'Rap7'}/>, that <Botao palavra='shines'
                                                destino='Exercicio' 
                                                imagem='shines' 
                                                palavrasCorretas={['brilha', 'brilho']}  
                                                contexto='  '
                                                voltar={'Rap7'}/>,{'\n'}
Special for you, and me.{'\n'}{'\n'}

Yeah. yo, yo, check it{'\n'}
It's kinda fresh you <Botao palavra='listen'
                            destino='Exercicio' 
                            imagem='listen' 
                            palavrasCorretas={['ouvir', 'escutar']}  
                            contexto='  '
                            voltar={'Rap7'}/> to more than hip-hop{'\n'}{'\n'}

And I can catch you in the mix from beauty to thrift shop{'\n'}
Plus you ship hop when it's time to, thinkin you fresh{'\n'}{'\n'}

Suggestin' beats I should rhyme to{'\n'}
At times when I'm lost I try to find you{'\n'}
You know to give me <Botao palavra='space'
                            destino='Exercicio' 
                            imagem='space' 
                            palavrasCorretas={['espaço', 'space']}  
                            contexto='  '
                            voltar={'Rap7'}/>when it's time to{'\n'}
My heart's dictionary defines you, it's <Botao palavra='love'
                                                destino='Exercicio' 
                                                imagem='love' 
                                                palavrasCorretas={['amor', 'amar']}  
                                                contexto='  '
                                                voltar={'Rap5'}/> and happiness{'\n'}{'\n'}

Truthfully it's hard tryin' to practice abstinence{'\n'}
The time we committed <Botao palavra='love'
                                        destino='Exercicio' 
                                        imagem='love' 
                                        palavrasCorretas={['amor', 'amar']}  
                                        contexto='  '
                                        voltar={'Rap5'}/> it was real good{'\n'}
Had to be for me to arrive and it still feel good{'\n'}
I know the --- ain't gon' keep you, but as my equal{'\n'}{'\n'}

It's how I must treat you{'\n'}
As my reflection in <Botao palavra='light'
                            destino='Exercicio' 
                            imagem='light' 
                            palavrasCorretas={['luz']}  
                            contexto='  '
                            voltar={'Rap7'}/> I'ma lead you{'\n'}
And whatever's right, I'ma feed you{'\n'}
Digga-da, digga-da, digga-da, digga-digga-da-da{'\n'}
Yo' I tell you the rest when I see you, peace{'\n'}{'\n'}

There are times. when you'll need someone.{'\n'}
I will be by your side.{'\n'}
There is a <Botao palavra='light'
                            destino='Exercicio' 
                            imagem='light' 
                            palavrasCorretas={['luz']}  
                            contexto='  '
                            voltar={'Rap7'}/>, that shines{'\n'}
Special for you, and me.{'\n'}{'\n'}

take my chances, b,b, b, before they pass{'\n'}
Pass me by, oh darling{'\n'}
You need to look at the other side{'\n'}
You'll agree{'\n'}{'\n'}
        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rap7;