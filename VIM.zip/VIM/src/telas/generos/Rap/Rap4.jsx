import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rap4() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = '3OnnDqH6Wj8'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero3'/>
        <Text style={estilos.titulo}>
        Flo Rida - Good Feeling
        </Text>

        <Text style={estilos.letraMusica}>  
          Oh, oh, oh, oh, oh, sometimes I get a good <Botao palavra='feeling'
                                                            destino='Exercicio' 
                                                            imagem='feeling' 
                                                            palavrasCorretas={['sentimento']}  
                                                            contexto='  '
                                                            voltar={'Rap4'}/>, yeah{'\n'}
          I get a <Botao palavra='feeling'
                         destino='Exercicio' 
                         imagem='feeling' 
                         palavrasCorretas={['sentimento']}  
                         contexto='  '
                         voltar={'Rap4'}/> that I never never never never had before, no no{'\n'}
          I get a good <Botao palavra='feeling'
                              destino='Exercicio' 
                              imagem='feeling' 
                              palavrasCorretas={['sentimento']}  
                              contexto='  '
                              voltar={'Rap4'}/>, yeah{'\n'}
          Oh oh, sometimes I get a good <Botao palavra='feeling'
                                               destino='Exercicio' 
                                               imagem='feeling' 
                                               palavrasCorretas={['sentimento']}  
                                               contexto='  '
                                               voltar={'Rap4'}/>, yeah{'\n'}
          I get a feeling that I never never never never had before, no no{'\n'}
          I get a good feeling, yeah{'\n'}{'\n'}

          Yes I can, doubt better leave, I'm running with this plan{'\n'}
          Pull me, grab me, <Botao palavra='crabs'
                                   destino='Exercicio' 
                                   imagem='crabs' 
                                   palavrasCorretas={['carangueijos']}  
                                   contexto='  '
                                   voltar={'Rap4'}/> in the <Botao palavra='bucket'
                                                                             destino='Exercicio' 
                                                                             imagem='bucket' 
                                                                             palavrasCorretas={['balde']}  
                                                                             contexto='  '
                                                                             voltar={'Rap4'}/> can't have me{'\n'}
          I'll be the president one day{'\n'}
          <Botao palavra='january'
                 destino='Exercicio' 
                 imagem='january' 
                 palavrasCorretas={['janeiro']}  
                 contexto=' '
                 voltar={'Rap4'}/> first, oh, you like that gossip{'\n'}
          Like you the one drinking what God sip dot com{'\n'}
          Now I gotta work with your <Botao palavra='tongue'
                                            destino='Exercicio' 
                                            imagem='tongue' 
                                            palavrasCorretas={['língua', 'lingua']}  
                                            contexto=' '
                                            voltar={'Rap4'}/>{'\n'}
          How many rolling stones you want{'\n'}
          Yeah I got a brand new <Botao palavra='spirit'
                                        destino='Exercicio' 
                                        imagem='spirit' 
                                        palavrasCorretas={['espírito']}  
                                        contexto='  '
                                        voltar={'Rap4'}/>,{'\n'}
          <Botao palavra='speak'
                 destino='Exercicio' 
                 imagem='someone speaking' 
                 palavrasCorretas={['fale', 'falar']}  
                 contexto='  '
                 voltar={'Rap4'}/> it and it's done{'\n'}{'\n'}

          Rolled up on the side of the bed like I won{'\n'}
          Talk like a winner, my chest to that sun{'\n'}
          G5 dealer, US to Taiwan{'\n'}
          Now who can say that I wanna play back{'\n'}
          Mama knew I was a needle in a hay stack{'\n'}
          A Bugatti boy, plus Maybach{'\n'}
          I got a feeling it's a wrap, ASAP{'\n'}{'\n'}

          Oh, oh, oh, oh, oh, sometimes I get a good <Botao palavra='feeling'
                                                            destino='Exercicio' 
                                                            imagem='feeling' 
                                                            palavrasCorretas={['sentimento']}  
                                                            contexto='  '
                                                            voltar={'Rap4'}/>, yeah{'\n'}
          I get a<Botao palavra='feeling'
                        destino='Exercicio' 
                        imagem='feeling' 
                        palavrasCorretas={['sentimento']}  
                        contexto='  '
                        voltar={'Rap4'}/> that I never never never never had before, no no{'\n'}

          I get a good <Botao palavra='feeling'
                              destino='Exercicio' 
                              imagem='feeling' 
                              palavrasCorretas={['sentimento']}  
                              contexto='  '
                              voltar={'Rap4'}/>, yeah{'\n'}

          Oh oh, sometimes I get a good <Botao palavra='feeling'
                                               destino='Exercicio' 
                                               imagem='feeling' 
                                               palavrasCorretas={['sentimento']}  
                                               contexto='  '
                                               voltar={'Rap4'}/>, yeah{'\n'}

          I get a feeling that I never never never never had before, no no{'\n'}
          I get a good feeling, yeah{'\n'}{'\n'}

          The mountain top, walk on water{'\n'}
          I got power, feel so <Botao palavra='royal'
                                      destino='Exercicio' 
                                      imagem='royal' 
                                      palavrasCorretas={['real', 'da realeza', 'realeza']}  
                                      contexto=' Sentido de pertencer a família de reis'
                                      voltar={'Rap4'}/>{'\n'}
          One second, I'mma strike oil{'\n'}
          Diamond, platinum, no more for you{'\n'}
          Gotta  <Botao palavra='drill'
                        destino='Exercicio' 
                        imagem='drill' 
                        palavrasCorretas={['furar', 'perfurar']}  
                        contexto=' '
                        voltar={'Rap4'}/> it in, never giving in{'\n'}
          Giving ups not an option, gotta get it in{'\n'}
          Witness I got the heart of <Botao palavra='twenty'
                                            destino='Exercicio' 
                                            imagem='twenty' 
                                            palavrasCorretas={['20', 'vinte']}  
                                            contexto='  '
                                            voltar={'Rap4'}/> men{'\n'}

          No fear, go to sleep in the <Botao palavra='lion'
                                             destino='Exercicio' 
                                             imagem='lion' 
                                             palavrasCorretas={['leão']}  
                                             contexto='  '
                                             voltar={'Rap4'}/>'s den{'\n'}
          That <Botao palavra='flow'
                      destino='Exercicio' 
                      imagem='flow of a river' 
                      palavrasCorretas={['fluxo']}  
                      contexto='  '
                      voltar={'Rap4'}/>, that <Botao palavra='spark'
                                                               destino='Exercicio' 
                                                               imagem='spark' 
                                                               palavrasCorretas={['fagulha']}  
                                                               contexto='  '
                                                               voltar={'Rap4'}/>, that <Botao palavra='crown'
                                                                                                        destino='Exercicio' 
                                                                                                        imagem='crown' 
                                                                                                        palavrasCorretas={['coroa']}  
                                                                                                        contexto='  '
                                                                                                        voltar={'Rap4'}/>{'\n'}
          You looking at the king of the <Botao palavra='jungle'
                                                destino='Exercicio' 
                                                imagem='jungle' 
                                                palavrasCorretas={['floresta']}  
                                                contexto='  '
                                                voltar={'Rap4'}/> now{'\n'}
          Stronger than ever can't hold me down{'\n'}
          A hundred miles feelin' from the picture smile{'\n'}
          Straight game <Botao palavra='face' 
                               destino='Exercicio' 
                               imagem='face' 
                               palavrasCorretas={['cara', 'rosto']}  
                               contexto='  '
                               voltar={'Rap4'}/>, it's game day{'\n'}

          See me running <Botao palavra='through'
                                destino='Exercicio' 
                                imagem='through all' 
                                palavrasCorretas={['através']}  
                                contexto='  '
                                voltar={'Rap4'}/> the <Botao palavra='crowd'
                                                                       destino='Exercicio' 
                                                                       imagem='crowd' 
                                                                       palavrasCorretas={['coroa']}  
                                                                       contexto=' '
                                                                       voltar={'Rap4'}/> full of melee{'\n'}
          No trick plays, I'm Bill Gates,{'\n'}
          Take a genius to <Botao palavra='understand'
                                  destino='Exercicio' 
                                  imagem='understanding a class' 
                                  palavrasCorretas={['entender', 'entendendo', 'compreender']}  
                                  contexto=' '
                                  voltar={'Rap4'}/> me{'\n'}{'\n'}

          Oh, oh, oh, oh, oh, sometimes I get a good feeling, yeah{'\n'}
          I get a feeling that I never never never never had before, no no{'\n'}
          I get a good feeling, yeah{'\n'}
          Oh oh, sometimes I get a good feeling, yeah{'\n'}
          I get a feeling that I never never never never had before, no no{'\n'}
          I get a good feeling, yeah{'\n'}{'\n'}

          Good feelin', good feelin'{'\n'}
          I know you got the good feelin'{'\n'}
          Let's get it, let's get it{'\n'}
          Gotta love the life that we livin'{'\n'}
          Let's get it, let's get it{'\n'}
          I know you got the good feelin'{'\n'}
          Let's get it, let's get it{'\n'}
          Gotta love the life that we livin'{'\n'}{'\n'}

          Oh, oh, oh, oh, oh, sometimes I get a good <Botao palavra='feeling'
                                                            destino='Exercicio' 
                                                            imagem='feeling' 
                                                            palavrasCorretas={['sentimento']}  
                                                            contexto='  '
                                                            voltar={'Rap4'}/>, yeah{'\n'}
          I get a <Botao palavra='feeling'
                         destino='Exercicio' 
                         imagem='feeling' 
                         palavrasCorretas={['sentimento']}  
                         contexto='  '
                         voltar={'Rap4'}/> that I never never never never had before, no no{'\n'}
          I get a good <Botao palavra='feeling'
                              destino='Exercicio' 
                              imagem='feeling' 
                              palavrasCorretas={['sentimento']}  
                              contexto='  '
                              voltar={'Rap4'}/>, yeah{'\n'}
          Oh oh, sometimes I get a good <Botao palavra='feeling'
                                               destino='Exercicio' 
                                               imagem='feeling' 
                                               palavrasCorretas={['sentimento']}  
                                               contexto='  '
                                               voltar={'Rap4'}/>, yeah{'\n'}
          I get a feeling that I never never never never had before, no no{'\n'}
          I get a good feeling, yeah{'\n'}
          Sometimes I get a good feeling{'\n'}{'\n'}


        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rap4;