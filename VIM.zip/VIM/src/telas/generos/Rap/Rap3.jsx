import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rap3() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'G8u3P7Xqlvo'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero3'/>
        <Text style={estilos.titulo}>
        Kanye West - God is
        </Text>

        <Text style={estilos.letraMusica}>  
          God is {'\n'}
          My light in <Botao palavra='darkness'
                             destino='Exercicio' 
                             imagem='darkness room' 
                             palavrasCorretas={['escuridão']}  
                             contexto='  '
                             voltar={'Rap3'}/>, oh{'\n'}
          God, God is{'\n'}
          He, He is my all and all (and I'll never turn back){'\n'}
          God is{'\n'}{'\n'}

          Everything that hath <Botao palavra='breath'
                                      destino='Exercicio' 
                                      imagem='breath' 
                                      palavrasCorretas={['respirar', 'respiração']}  
                                      contexto='  '
                                      voltar={'Rap3'}/>, <Botao palavra='praise'
                                                                          destino='Exercicio' 
                                                                          imagem='saint praying' 
                                                                          palavrasCorretas={['louve', 'louvar']}  
                                                                          contexto='  '
                                                                          voltar={'Rap3'}/> the Lord{'\n'}
          Worship Christ with the best of your portions{'\n'}
          I know I won't forget all He's done{'\n'}
          He's the <Botao palavra='strength'
                          destino='Exercicio' 
                          imagem='double biceps pose' 
                          palavrasCorretas={['força']}  
                          contexto='  '
                          voltar={'Rap3'}/> in this <Botao palavra='race'
                                                                     destino='Exercicio' 
                                                                     imagem='race' 
                                                                     palavrasCorretas={['corrida']}  
                                                                     contexto='  '
                                                                     voltar={'Rap3'}/> that I run{'\n'}

          Every time I look up, I see God's faithfulness{'\n'}
          And it shows just how much He is <Botao palavra='miraculous'
                                                  destino='Exercicio' 
                                                  imagem='miracle ' 
                                                  palavrasCorretas={['milagroso']}  
                                                  contexto='  '
                                                  voltar={'Rap3'}/>{'\n'}
          I can't keep it to myself, I can't sit here and be {'\n'}
          Everybody, I will tell to the whole world, it's Him{'\n'}
          King of Kings, Lord of Lords{'\n'}{'\n'}

          All the things He has in store{'\n'}
          From the <Botao palavra='rich'
                          destino='Exercicio' 
                          imagem='rich' 
                          palavrasCorretas={['rico', 'riqueza']}  
                          contexto=' '
                          voltar={'Rap3'}/> to the <Botao palavra='poor'
                                                                    destino='Exercicio' 
                                                                    imagem='poor' 
                                                                    palavrasCorretas={['pobreza', 'pobre']}  
                                                                    contexto='  '
                                                                    voltar={'Rap3'}/>{'\n'}
          All are welcome through the door{'\n'}
          You won't ever be the same{'\n'}
          When you call on Jesus' name{'\n'}
          <Botao palavra='listen'
                 destino='Exercicio' 
                 imagem='listen' 
                 palavrasCorretas={['escute', 'ouça']}  
                 contexto='  '
                 voltar={'Rap3'}/> to the words I'm saying{'\n'}
          Jesus saved me, now I'm saying{'\n'}
          And I know, I know God is the force that picked me up{'\n'}
          I know Christ is the fountain that <Botao palavra='filled'
                                                    destino='Exercicio' 
                                                    imagem='filled' 
                                                    palavrasCorretas={['preencheu','encheu', 'completou']}  
                                                    contexto='  '
                                                    voltar={'Rap3'}/> my cup{'\n'}
          I know God is alive, yeah{'\n'}
          He has opened up my <Botao palavra='vision'
                                     destino='Exercicio' 
                                     imagem='vision' 
                                     palavrasCorretas={['visão']}  
                                     contexto='  '
                                     voltar={'Rap3'}/>{'\n'}
          Giving me a <Botao palavra='revelation'
                             destino='Exercicio' 
                             imagem='revelation' 
                             palavrasCorretas={['revelação']}  
                             contexto='  '
                             voltar={'Rap3'}/>{'\n'}
          This ain't 'bout a dead religion{'\n'}
          Jesus brought a revolution{'\n'}
          All the captives are forgiven{'\n'}
          Time to break down all the <Botao palavra='prisons'
                                            destino='Exercicio' 
                                            imagem='prisons' 
                                            palavrasCorretas={['prisões', 'prisão']}  
                                            contexto='  '
                                            voltar={'Rap3'}/>{'\n'}
          Every man, every woman{'\n'}
          There is <Botao palavra='freedom'
                          destino='Exercicio' 
                          imagem='freedom' 
                          palavrasCorretas={['liberdade']}  
                          contexto='  '
                          voltar={'Rap3'}/> from addiction{'\n'}
          Jesus, You have my soul{'\n'}
          Sunday Service on a roll{'\n'}
          All my idols, let 'em go{'\n'}
          All the demons, let 'em know{'\n'}
          This a mission, not a show{'\n'}
          This is my eternal <Botao palavra='soul'
                                    destino='Exercicio' 
                                    imagem='soul' 
                                    palavrasCorretas={['alma']}  
                                    contexto='  '
                                    voltar={'Rap3'}/>{'\n'}
          This my kids, this the <Botao palavra='crib'
                                        destino='Exercicio' 
                                        imagem='the crib' 
                                        palavrasCorretas={['berço']}  
                                        contexto='  '
                                        voltar={'Rap3'}/>{'\n'}
          This my wife, this my life{'\n'}
          This my God-given right{'\n'}
          Thank you, Jesus, won the fight{'\n'}{'\n'}

          That's what God is{'\n'}
          That's what God is{'\n'}
          That's what God is{'\n'}{'\n'}


        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rap3;