import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rap2() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = '6EEW-9NDM5k'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero3'/>
        <Text style={estilos.titulo}>
        Akon - Lonely
        </Text>

        <Text style={estilos.letraMusica}>  
          Lonely, I'm Mr. Lonely{'\n'}
          I have <Botao palavra='nobody'
                        destino='Exercicio' 
                        imagem='nobody' 
                        palavrasCorretas={['ninguém', 'ninguem']}  
                        contexto='  '
                        voltar={'Rap2'}/> for my own{'\n'}
          I'm so lonely, I'm Mr. Lonely{'\n'}
          I have nobody for my own{'\n'}
          I am so lonely{'\n'}{'\n'}
          
          Yo, this one here goes out to all my players out there, man{'\n'}
          Ya know, that got that one good girl, Lord{'\n'}
          That's <Botao palavra='always'
                        destino='Exercicio' 
                        imagem='always' 
                        palavrasCorretas={['sempre']}  
                        contexto=' . '
                        voltar={'Rap2'}/> been there, man{'\n'}
          Like, took all the bullshit{'\n'}
          But then one day, she can't take it no more and decide to leave{'\n'}{'\n'}

          Yeah, I woke up in the <Botao palavra='middle'
                                        destino='Exercicio' 
                                        imagem='middle' 
                                        palavrasCorretas={['meio']}  
                                        contexto='  '
                                        voltar={'Rap2'}/> of the night{'\n'}

          And I noticed my girl wasn't by my <Botao palavra='side'
                                                    destino='Exercicio' 
                                                    imagem='the side of the wall' 
                                                    palavrasCorretas={['lado']}  
                                                    contexto='  '
                                                    voltar={'Rap2'}/>{'\n'}
          Coulda sworn I was dreamin' for her{'\n'}
          I was feenin' so I had to take a little <Botao palavra='ride'
                                                         destino='Exercicio' 
                                                         imagem='ride' 
                                                         palavrasCorretas={['passeio']}  
                                                         contexto=' Sentido de dar uma volta '/>{'\n'}
          Backtracking over these<Botao palavra='few'
                                        destino='Exercicio' 
                                        imagem='few' 
                                        palavrasCorretas={['alguns', 'poucos']}  
                                        contexto='  '
                                        voltar={'Rap2'}/>years{'\n'}
          Tryin' to<Botao palavra='figure'
                          destino='Exercicio' 
                          imagem='trying to figure' 
                          palavrasCorretas={['descobrir']}  
                          contexto='  '
                          voltar={'Rap2'}/>out what I do to make it go bad{'\n'}
          'Cause ever since my girl left me{'\n'}
          My <Botao palavra='whole'
                    destino='Exercicio' 
                    imagem='whole life' 
                    palavrasCorretas={['toda', 'todo', 'inteira', 'inteiro']}  
                    contexto='  '
                    voltar={'Rap2'}/> life came crashing and I'm so{'\n'}{'\n'}

          Lonely (so lonely){'\n'}
          I'm Mr. Lonely (Mr. Lonely){'\n'}
          I have nobody (I have nobody){'\n'}
          For my own (to call my own girl){'\n'}
          I'm so lonely (so lonely){'\n'}
          I'm Mr. Lonely (Mr. Lonely){'\n'}
          I have nobody (I have nobody){'\n'}
          For my own (to call my own girl){'\n'}
          I am so lonely{'\n'}{'\n'}

          Can't believe I had a girl like you{'\n'}
          And I just let you walk right outta my life{'\n'}
          After all I put you <Botao palavra='through'
                                     destino='Exercicio' 
                                     imagem='through all' 
                                     palavrasCorretas={['através']}  
                                     contexto='  '
                                     voltar={'Rap2'}/>{'\n'}

          You still stuck around and stayed by my side{'\n'}
          What really hurt me is I <Botao palavra='broke'
                                          destino='Exercicio' 
                                          imagem='broke' 
                                          palavrasCorretas={['quebrei', 'quebrado']}  
                                          contexto=' '
                                          voltar={'Rap2'}/> your heart{'\n'}
          Baby, you're a good girl and I had no right{'\n'}
          I really wanna make things right{'\n'}
          'Cause without you in my life girl, I'm so{'\n'}{'\n'}

          Lonely (so lonely){'\n'}
          I'm Mr. Lonely (Mr. Lonely){'\n'}
          I have <Botao palavra='nobody'
                        destino='Exercicio' 
                        imagem='nobody' 
                        palavrasCorretas={['ninguém', 'ninguem']}  
                        contexto=' '
                        voltar={'Rap2'}/> (I have nobody){'\n'}
          For my own (to call my own girl){'\n'}
          I'm so lonely (so lonely){'\n'}
          I'm Mr. Lonely (Mr. Lonely){'\n'}
          I have nobody (I have nobody){'\n'}
          For my own (to call my own girl){'\n'}
          I am so lonely{'\n'}{'\n'}

          Been all about the world, ain't never met a girl{'\n'}
          That can take the things that you been <Botao palavra='trough'
                                                        destino='Exercicio' 
                                                        imagem='trough all' 
                                                        palavrasCorretas={['através']}  
                                                        contexto='  '
                                                        voltar={'Rap2'}/>{'\n'}
          Never thought the day would come where you'd get up and run{'\n'}
          And I would be out chasing you{'\n'}
          'Cause ain't nowhere in the<Botao palavra='globe'
                                            destino='Exercicio' 
                                            imagem='globe' 
                                            palavrasCorretas={['globo']}  
                                            contexto=' '
                                            voltar={'Rap2'}/>I'd rather be{'\n'}

          Ain't no one in the<Botao palavra='globe'
                                    destino='Exercicio' 
                                    imagem='globe' 
                                    palavrasCorretas={['globo']}  
                                    contexto='  '
                                    voltar={'Rap2'}/> I'd rather see{'\n'}

          Than the girl of my <Botao palavra='dreams'
                                     destino='Exercicio' 
                                     imagem='dreams' 
                                     palavrasCorretas={['sonhos', 'sonho']}  
                                     contexto='  '
                                     voltar={'Rap2'}
                                     /> that made me be{'\n'}
                                     
          So happy but now so lonely{'\n'}{'\n'}

          Lonely (so lonely){'\n'}
          I'm Mr. Lonely (Mr. Lonely){'\n'}
          I have nobody (I have nobody){'\n'}
          For my own (to call my own girl){'\n'}
          I'm so lonely (so lonely){'\n'}
          I'm Mr. Lonely (Mr. Lonely){'\n'}
          I have nobody (I have nobody){'\n'}
          For my own (to call my own girl){'\n'}
          I am so lonely{'\n'}{'\n'}

          Never thought that I'd be alone{'\n'}
          I didn't think you'd be gone this long{'\n'}
          I just want you to call my phone{'\n'}
          So stop playing girl and come on home{'\n'}
          Baby girl, I didn't mean to shout{'\n'}
          I want me and you to work it out{'\n'}
          I never wished to ever hurt my baby{'\n'}
          And it's drivin' me crazy 'cause I'm so{'\n'}{'\n'}

          Lonely (so lonely){'\n'}
          I'm Mr. Lonely (Mr. Lonely){'\n'}
          I have nobody (I have nobody){'\n'}
          For my own (to call my own girl){'\n'}
          I'm so lonely (so lonely){'\n'}
          I'm Mr. Lonely (Mr. Lonely){'\n'}
          I have nobody (I have nobody){'\n'}
          For my own (to call my own girl){'\n'}
          I am so lonely{'\n'}{'\n'}
          
          So lonely (lonely){'\n'}
          So lonely (so lonely){'\n'}
          Mr. Lonely (lonely){'\n'}
          So lonely (so lonely){'\n'}
          So lonely (lonely){'\n'}
          So lonely (so lonely){'\n'}
          So lonely{'\n'}
          Mr. Lonely{'\n'}{'\n'}



        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rap2;