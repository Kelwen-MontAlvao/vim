import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rap1() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'RgKAFK5djSk'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero3'/>
        <Text style={estilos.titulo}>
        Wiz Khalifa - See you again
        </Text>

        <Text style={estilos.letraMusica}>  
          It's been a long day without you, my friend {'\n'}
          And I'll <Botao palavra='tell'
                          destino='Exercicio' 
                          imagem='tell' 
                          palavrasCorretas={['falar', 'contar']}  
                          contexto='  '
                          voltar={'Rap1'}/> you all about it when I see you <Botao palavra='again'
                                                                                             destino='Exercicio' 
                                                                                             imagem='someone talking about doing something again' 
                                                                                             palavrasCorretas={['de novo', 'novamente']}  
                                                                                             contexto='  '
                                                                                             voltar={'Rap1'}/>{'\n'}
          We've come a long way from where we began{'\n'}
          Oh, I'll tell you all about it when I see you <Botao palavra='again'
                                                               destino='Exercicio' 
                                                               imagem='again' 
                                                               palavrasCorretas={['de novo', 'novamente']}  
                                                               contexto=' '
                                                               voltar={'Rap1'}/>{'\n'}
          When I see you <Botao palavra='again'
                                destino='Exercicio' 
                                imagem='again' 
                                palavrasCorretas={['de novo', 'novamente']}  
                                contexto='  '
                                voltar={'Rap1'}/>{'\n'}{'\n'}

          Damn, who knew?{'\n'}
          All the planes we flew, good things we been through{'\n'}
          That I'd be standing right here talking to you{'\n'}
          'Bout another <Botao palavra='path'
                               destino='Exercicio' 
                               imagem='path' 
                               palavrasCorretas={['caminho']}  
                               contexto='  '
                               voltar={'Rap1'}/>, I know we loved to hit the <Botao palavra='road'
                                                                                              destino='Exercicio' 
                                                                                              imagem='road' 
                                                                                              palavrasCorretas={['rua', 'estrada']}  
                                                                                              contexto='  '
                                                                                              voltar={'Rap1'}/> and laugh{'\n'}

          But something told me that it wouldn't last{'\n'}
          Had to switch up, look at things different, see the bigger <Botao palavra='picture'
                                                                            destino='Exercicio' 
                                                                            imagem='someone taking a photo' 
                                                                            palavrasCorretas={['foto', 'imagem', 'figura', 'quadro']}  
                                                                            contexto='  '
                                                                            voltar={'Rap1'}/>{'\n'}
          Those were the days, hard work forever pays{'\n'}
          Now I see you in a better place (see you in a better place){'\n'}
          Uh{'\n'}

          How can we not talk about family when family's all that we got?{'\n'}
          <Botao palavra='everything'
                 destino='Exercicio' 
                 imagem='the world' 
                 palavrasCorretas={['tudo']}  
                 contexto='  '
                 voltar={'Rap1'}/> I went through, you were standing there by my side{'\n'}
          And now you gon' be with me for the last <Botao palavra='ride'
                                                          destino='Exercicio' 
                                                          imagem='ride' 
                                                          palavrasCorretas={['passeio']}  
                                                          contexto=' Sentido de dar uma volta. '
                                                          voltar={'Rap1'}/>{'\n'}{'\n'}

          It's been a long day without you, my friend{'\n'}
          And I'll tell you all about it when I see you <Botao palavra='again'
                                                               destino='Exercicio' 
                                                               imagem='again' 
                                                               palavrasCorretas={['de novo', 'novamente']}  
                                                               contexto='  '
                                                               voltar={'Rap1'}/>{'\n'}
          We've come a long way (yeah, we came a long way){'\n'}
          From where we began (you know we started){'\n'}
          Oh, I'll tell you all about it when I see you<Botao palavra='again'
                                                              destino='Exercicio' 
                                                              imagem='again' 
                                                              palavrasCorretas={['de novo', 'novamente']}  
                                                              contexto='  '
                                                              voltar={'Rap1'}/>{'\n'}
          When I see you <Botao palavra='again'
                                destino='Exercicio' 
                                imagem='again' 
                                palavrasCorretas={['de novo', 'novamente']}  
                                contexto='  '
                                voltar={'Rap1'}/>{'\n'}{'\n'}

          First, you both go out your way and the vibe is feeling <Botao palavra='strong'
                                                                         destino='Exercicio' 
                                                                         imagem='double biceps pose' 
                                                                         palavrasCorretas={['forte']}  
                                                                         contexto='  '
                                                                         voltar={'Rap1'}/>{'\n'}
          And what's small turned to a friendship, a friendship turned to a <Botao palavra='bond'
                                                                                   destino='Exercicio' 
                                                                                   imagem='a bond' 
                                                                                   palavrasCorretas={['vínculo']}  
                                                                                   contexto='  '
                                                                                   voltar={'Rap1'}/>{'\n'}
          And that <Botao palavra='bond'
                          destino='Exercicio' 
                          imagem='a bond' 
                          palavrasCorretas={['vínculo']}  
                          contexto='  '
                          voltar={'Rap1'}/> will never be broken, the love will never get lost{'\n'}
          (The love will never get lost){'\n'}{'\n'}

          And when brotherhood come first, then the line will never be crossed{'\n'}
          Established it on our own when that line had to be drawn{'\n'}
          And that line is what we reached, so remember me when I'm gone{'\n'}
          (Remember me when I'm gone){'\n'}{'\n'}

          How can we not talk about family when family's all that we got?{'\n'}
          Everything I went through you were standing there by my <Botao palavra='side'
                                                                         destino='Exercicio' 
                                                                         imagem='the side of the wall' 
                                                                         palavrasCorretas={['lado']}  
                                                                         contexto='  '
                                                                         voltar={'Rap1'}/>{'\n'}
          And now you gon' be with me for the last <Botao palavra='ride'
                                                          destino='Exercicio' 
                                                          imagem='ride' 
                                                          palavrasCorretas={['passeio']}  
                                                          contexto=' Sentido de dar uma volta '
                                                          voltar={'Rap1'}/>{'\n'}{'\n'}

          So let the light guide your way, yeah{'\n'}
          Hold every memory as you go{'\n'}
          And every <Botao palavra='road'
                           destino='Exercicio' 
                           imagem='road' 
                           palavrasCorretas={['rua', 'estrada']}  
                           contexto='  '
                           voltar={'Rap1'}/> you take{'\n'}

          Will always lead you home, home{'\n'}{'\n'}

          It's been a long day without you, my friend{'\n'}
          And I'll tell you all about it when I see you<Botao palavra='again'
                                                              destino='Exercicio' 
                                                              imagem='again' 
                                                              palavrasCorretas={['de novo', 'novamente']}  
                                                              contexto='  '
                                                              voltar={'Rap1'}/>{'\n'}
          We've come a long way from where we began{'\n'}
          Oh, I'll tell you all about it when I see you again{'\n'}
          When I see you <Botao palavra='again'
                                destino='Exercicio' 
                                imagem='again' 
                                palavrasCorretas={['de novo', 'novamente']}  
                                contexto='  '
                                voltar={'Rap1'}/>{'\n'}{'\n'}

          When I see you again (yeah, uh){'\n'}
          See you again (yeah, yeah, yeah){'\n'}
          When I see you <Botao palavra='again'
                                destino='Exercicio' 
                                imagem='again' 
                                palavrasCorretas={['de novo', 'novamente']}  
                                contexto='  '
                                voltar={'Rap1'}/>{'\n'}{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rap1;