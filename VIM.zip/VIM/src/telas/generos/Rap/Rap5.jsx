import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Rap5() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'tvTRZJ-4EyI'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero3'/>
        <Text style={estilos.titulo}>
        Kendrick Lamar - HUMBLE
        </Text>
        <Text style={estilos.letraMusica}>  
        Nobody <Botao palavra='pray'
              destino='Exercicio' 
              imagem='pray' 
              palavrasCorretas={['reze', 'rezar', 'orar']}  
              contexto='  '
              voltar={'Rap5'}/> for me{'\n'}

It been that <Botao palavra='day'
               	    destino='Exercicio' 
               	    imagem='day' 
               	    palavrasCorretas={['dia']}  
                    contexto='  '
                    voltar={'Rap5'}/> for me{'\n'}
Way{'\n'}
Yeah, yeah!{'\n'}{'\n'}

Ayy, I remember syrup <Botao palavra='sandwiches'
               		     	 destino='Exercicio' 
                             imagem='sandwiches' 
                             palavrasCorretas={['sanduíches', 'sanduiches']}  
                             contexto='  '
                             voltar={'Rap5'}/> and crime allowances{'\n'}

Finesse on 'em with some counterfeits, but now I'm countin' this{'\n'}
Parmesan where my accountant <Botao palavra='lives'
               		     	    destino='Exercicio' 
                                    imagem='lives' 
                                    palavrasCorretas={['vidas']}  
                                    contexto='  '
                                    voltar={'Rap5'}/>, in fact, I'm downin' this{'\n'}

D'USSÉ with my boo bae tastes like Kool-Aid for the analysts{'\n'}{'\n'}

<Botao palavra='Girl'
       destino='Exercicio' 
       imagem='Girl' 
       palavrasCorretas={['mulher', 'menina', 'moça', 'moca']}  
       contexto='  '
       voltar={'Rap5'}/>, I can buy yo' ass the <Botao palavra='world'
               		     			       destino='Exercicio' 
                             			       imagem='world' 
                            			       palavrasCorretas={['mundo']}  
                             			       contexto='  '
                             			       voltar={'Rap5'}/> with my paystub{'\n'}
I know that it's <Botao palavra='good'
               		destino='Exercicio' 
                        imagem='good' 
                        palavrasCorretas={['bom']}  
                        contexto='  '
                        voltar={'Rap5'}/>, won't you sit it on my taste bluds?{'\n'}

I get <Botao palavra='way'
             destino='Exercicio' 
             imagem='way' 
             palavrasCorretas={['caminho']}  
             contexto='  '
             voltar={'Rap5'}/> too petty once you let me do the extras{'\n'}
Pull up on your <Botao palavra='block'
               	       destino='Exercicio' 
                       imagem='block' 
                       palavrasCorretas={['bloco', 'blocos']}  
                       contexto='  '
                       voltar={'Rap5'}/>, then break it down, we <Botao palavra='playin'
               		                                                destino='Exercicio' 
                             						imagem='playing' 
                             						palavrasCorretas={['jogando', 'jogar']}  
                             						contexto='  '
                            						voltar={'Rap5'}/>' Tetris{'\n'}{'\n'}

A.m. to the p.m., p.m. to the a.m., funk{'\n'}
Eat up your per diem, you just gotta <Botao palavra='hate'
               		     		    destino='Exercicio' 
                             		    imagem='hate' 
                             		    palavrasCorretas={['odiar', 'odeia']}  
                             		    contexto='  '
                            		    voltar={'Rap5'}/> 'em, funk{'\n'}
If I <Botao palavra='quit'
            destino='Exercicio' 
	    imagem='quit' 
            palavrasCorretas={['sair', 'saindo', 'desistir']}  
            contexto='  '
            voltar={'Rap5'}/> your BM, I still ride Mercedes, funk{'\n'}

If I <Botao palavra='quit'
            destino='Exercicio' 
	    imagem='quit' 
            palavrasCorretas={['sair', 'saindo', 'desistir']}  
            contexto='  '
            voltar={'Rap5'}/> this season, I still be the greatest, funk{'\n'}{'\n'}

My left stroke just went viral{'\n'}
Right stroke put lil' <Botao palavra='baby'
            		     destino='Exercicio' 
	    		     imagem='baby' 
           		     palavrasCorretas={['bebe', 'bêbê']}  
            		     contexto='  '
            		     voltar={'Rap5'}/> in a <Botao palavra='spiral'
                 				           destino='Exercicio' 
	    					   	   imagem='spiral' 
            						   palavrasCorretas={['espiral']}  
            					      	   contexto='  '
            						   voltar={'Rap5'}/>{'\n'}

Soprano C, we like to keep it on a high note{'\n'}
It's levels to it, you and I know{'\n'}{'\n'}

Tell 'em, be humble (hol' up){'\n'}
Sit down (hol' up, hol' up, lil', hol' up){'\n'}
Be humble (hol' up){'\n'}
Sit down (hol' up, sit down, lil', sit down, lil'){'\n'}
Be humble (hol' up, hol' up){'\n'}
Sit down (hol' up, hol' up, lil', hol' up){'\n'}
Be humble (hol' up){'\n'}
Sit down (hol' up, hol' up, hol' up){'\n'}{'\n'}

Be humble (hol' up, hol' up){'\n'}
Sit down (hol' up, hol' up, lil', hol' up, lil'){'\n'}
Be humble (hol' up){'\n'}
Sit down (hol' up, sit down, lil', sit down, lil'){'\n'}
Be humble (hol' up, hol' up){'\n'}
Sit down (hol' up, hol' up, lil', hol' up){'\n'}
Be humble (hol' up){'\n'}
Sit down (hol' up, hol' up, hol' up, hol' up){'\n'}{'\n'}

Who dat -a thinkin' that he frontin' on Man-Man? (Man-Man){'\n'}
Get the f- off my stage, I'm the Sandman (Sandman){'\n'}
Get the f- off my (ayy), that ain't right{'\n'}
I make a play <Botao palavra='blowing'
            	     destino='Exercicio' 
	     	     imagem='blow up' 
            	     palavrasCorretas={['explodir', 'estourar']}  
            	     contexto='  '
            	     voltar={'Rap5'}/> up your whole <Botao palavra='life'
            						    destino='Exercicio' 
	    						    imagem='life' 
            						    palavrasCorretas={['vida']}  
           						    contexto='  '
            						    voltar={'Rap5'}/>{'\n'}{'\n'}

I'm so, so sick and <Botao palavra='tired'
            		   destino='Exercicio' 
	    		   imagem='tired' 
            		   palavrasCorretas={['cansado']}  
            		   contexto='  '
            		   voltar={'Rap5'}/> of the Photoshop{'\n'}
Show me somethin' natural like afro on Richard Pryor{'\n'}
Show me somethin' natural, I wanna feel some stretch <Botao palavra='marks'
            						    destino='Exercicio' 
	    						    imagem='marks' 
            						    palavrasCorretas={['marcas', 'rastros']}  
           				 	  	    contexto='  '
             	 	 	  	 		    voltar={'Rap5'}/>
Still I take you down right on your mama couch in Polo <Botao palavra='socks'
            						      destino='Exercicio' 
	    						      imagem='socks' 
            						      palavrasCorretas={['meias']}  
           				 	  	      contexto='  '
             	 	 	  	 		      voltar={'Rap5'}/>{'\n'}{'\n'}

Ayy, this shit way too crazy, ayy, you do not amaze me, ayy{'\n'}
I blew cool from AC, ayy, Obama just paged me, ayy{'\n'}
I don't fabricate it, ayy, most of y'all be fakin', ayy{'\n'}
I stay modest 'bout it, ayy, she elaborate it, ayy{'\n'}{'\n'}

This that Grey Poupon, that Evian, that TED Talk, ayy{'\n'}
Watch my soul speak, you let the meds talk, ayy{'\n'}
If I kill a, uhm, it won't be the alcohol, ayy{'\n'}
I'm the realest, uhm, after all{'\n'}{'\n'}

Tell 'em, be humble (hol' up){'\n'}
Sit down (hol' up, hol' up, lil'){'\n'}
Be humble (hol' up){'\n'}
<Botao palavra='Sit'
       destino='Exercicio' 
       imagem='marks' 
       palavrasCorretas={['sentar']}  
       contexto='  '
       voltar={'Rap5'}/> down (hol' up, sit down, lil', sit down, lil'){'\n'}{'\n'}

Tell 'em sit down (hol' up, hol' up, lil' hol' up){'\n'}
Be humble (hol' up){'\n'}
Sit down (hol' up, hol' up, hol' up, hol' up){'\n'}

Be humble (hol' up, hol' up){'\n'}
<Botao palavra='Sit'
       destino='Exercicio' 
       imagem='marks' 
       palavrasCorretas={['sentar']}  
       contexto='  '
       voltar={'Rap5'}/> down (hol' up, hol' up, lil' hol' up, lil'){'\n'}

Be humble (hol' up){'\n'}
Sit down (hol' up, sit down, lil', sit down, lil'){'\n'}
Be humble (hol' up, hol' up){'\n'}
<Botao palavra='Sit'
       destino='Exercicio' 
       imagem='marks' 
       palavrasCorretas={['sentar']}  
       contexto='  '
       voltar={'Rap5'}/> down (hol' up, hol' up, lil' hol' up){'\n'}{'\n'}

Be humble (hol' up, hol' up){'\n'}
Sit down (hol' up, hol' up, hol' up){'\n'}{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Rap5;