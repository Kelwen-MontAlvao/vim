import React from 'react';
import { View, Text, ScrollView, StyleSheet, ImageBackground, TouchableOpacity, Button } from 'react-native';
import { Cabecalho } from '../../componentes/Cabecalho';
import { useNavigation } from '@react-navigation/native';
import { useMusic } from '../../MusicContext';

const postsMusicas = [
    { nome: 'The Thrill Is Gone', artista: 'B.B. King', dataLancamento: '1970-10-15', destino: 'Blues1', imagem: require('../../imgs/blues.jpg') },
    { nome: "I'd Rather Go Blind", artista: 'Etta James', dataLancamento: '1968-11-18', destino: 'Blues2', imagem: require('../../imgs/blues.jpg') },
    { nome: 'Ain t No Sunshine', artista: 'Bill Withers', dataLancamento: '1971-01-01', destino: 'Blues3', imagem: require('../../imgs/blues.jpg') },
    { nome: 'Georgia on My Mind', artista: 'Ray Charles', dataLancamento: '1960-09-01', destino: 'Blues4', imagem: require('../../imgs/blues.jpg') },
    { nome: 'Call It Stormy Monday', artista: 'B.B. King', dataLancamento: '1969-02-15', destino: 'Blues5', imagem: require('../../imgs/blues.jpg') },
    { nome: 'Before You Accuse Me', artista: 'Eric Clapton', dataLancamento: '1989-03-01', destino: 'Blues6', imagem: require('../../imgs/blues.jpg') },
    { nome: 'Feels Like Rain', artista: 'Buddy Guy', dataLancamento: '1993-03-01', destino: 'Blues7', imagem: require('../../imgs/blues.jpg') },
  ];
  


export function Genero5() {
  const navegacao = useNavigation();
  const { saveMusic } = useMusic();

  const navegar = (rota) => {
    navegacao.navigate(rota);
  };

  return (
    <>
      <Cabecalho />

      <ImageBackground
        source={require('../../imgs/blues.jpg')}
        style={estilos.conteinerTitulo}
      >
        <Text style={estilos.titulo}>Gênero: Blues</Text>
      </ImageBackground>

      <ScrollView
        style={estilos.scrollContent}
        contentContainerStyle={estilos.scrollContainer}
        vertical={true}
      >
        {postsMusicas.map((musica, index) => (
          <TouchableOpacity
            key={index}
            style={estilos.postContainer}
            onPress={() => navegar(musica.destino)}
          >
            <View>
              <Text style={estilos.postTitulo}>{musica.nome}</Text>
              <Text style={estilos.postArtista}>Artista: {musica.artista}</Text>
              <Text style={estilos.postData}>Lançamento: {musica.dataLancamento}</Text>
              <Button title="Salvar Música" onPress={() => saveMusic(musica)} />
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#2d7de6',
    height: 200,
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center",
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
  },
  scrollContainer: {
    alignItems: 'center',
    paddingBottom: 20,
  },
  postContainer: {
    backgroundColor: '#e0f7fa',
    width: '80%',
    padding: 20,
    marginVertical: 10,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 2,
    elevation: 5,
  },
  postTitulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  postArtista: {
    fontSize: 16,
    color: '#555',
  },
  postData: {
    fontSize: 14,
    color: '#777',
    marginBottom: 12
  },
});
