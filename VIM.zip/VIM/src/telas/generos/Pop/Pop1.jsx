import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Pop1() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'ZbZSe6N_BXs'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>
      
      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero2'/>
        <Text style={estilos.titulo}>
        Pharrell Williams - Happy
        </Text>

        <Text style={estilos.letraMusica}>  
            It might seem <Botao palavra='crazy'
                                 destino='Exercicio' 
                                 imagem='something crazy' 
                                 palavrasCorretas={['louco', 'maluco']}  
                                 contexto=' '
                                 voltar={'Pop1'}/> what I'm about to say {'\n'}
                                 

            Sunshine she's here, you can take a break{'\n'}
                I'm a hot air <Botao palavra='balloon'
                                 destino='Exercicio' 
                                 imagem='air balloon' 
                                 palavrasCorretas={['balão']}  
                                 contexto=' '
                                 voltar={'Pop1'}/> that could go to space{'\n'}

            With the air, like I don't care baby by the way{'\n'}{'\n'}

            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you feel like a room without a roof{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you feel like happiness is the truth{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto=' '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you know what happiness is to you{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you feel like that's what you wanna do{'\n'}{'\n'}

            Here come <Botao palavra='bad'
                             destino='Exercicio' 
                             imagem='bad' 
                             palavrasCorretas={['mal', 'má', 'más']}  
                             contexto='  '
                             voltar={'Pop1'}/> news talking this and that{'\n'}

            Yeah, well, gimme all you got and don't hold back{'\n'}
            Yeah, well I should probably <Botao palavra='warn'
                                                destino='Exercicio' 
                                                imagem='warn' 
                                                palavrasCorretas={['avisar', 'aviso']}  
                                                contexto=' '
                                                voltar={'Pop1'}/> you I'll be just fine{'\n'}

            Yeah, no offense to you don't <Botao palavra='waste'
                                                 destino='Exercicio' 
                                                 imagem='waste' 
                                                 palavrasCorretas={['desperdício', 'perder']}  
                                                 contexto=' '
                                                 voltar={'Pop1'}/> your time{'\n'}
            Here's why{'\n'}{'\n'}

            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto=' '
                               voltar={'Pop1'}/>{'\n'}
                               
            Clap along if you feel like a room without a roof{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you feel like happiness is the truth{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto=' '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you know what happiness is to you{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you feel like that's what you wanna do{'\n'}{'\n'}

            bring me down{'\n'}
            Can't <Botao palavra='nothing'
                         destino='Exercicio' 
                         imagem='nothing' 
                         palavrasCorretas={['nada']}  
                         contexto=' '
                         voltar={'Pop1'}/> <Botao palavra='(happy)'
                                                            destino='Exercicio' 
                                                            imagem='happy face' 
                                                            palavrasCorretas={['feliz']}  
                                                            contexto=' '
                                                            voltar={'Pop1'}/> bring me down{'\n'}

            My level's too high <Botao palavra='(happy)'
                                       destino='Exercicio' 
                                       imagem='happy face' 
                                       palavrasCorretas={['feliz']}  
                                       contexto='  '
                                       voltar={'Pop1'}/> to bring me down{'\n'}

            Can't nothing <Botao palavra='(happy)'
                                 destino='Exercicio' 
                                 imagem='happy face' 
                                 palavrasCorretas={['feliz']}  
                                 contexto='  '
                                 voltar={'Pop1'}/> bring me down{'\n'}
            I said{'\n'}
            (Happy, happy, happy) bring me down{'\n'}
            Can't <Botao palavra='nothing'
                         destino='Exercicio' 
                         imagem='nothing' 
                         palavrasCorretas={['nada']}  
                         contexto='  '
                         voltar={'Pop1'}/> bring me down{'\n'}

            My level's too high <Botao palavra='(happy)'
                                       destino='Exercicio' 
                                       imagem='happy face' 
                                       palavrasCorretas={['feliz']}  
                                       contexto=' '
                                       voltar={'Pop1'}/> to bring me down{'\n'}

            Can't <Botao palavra='nothing'
                         destino='Exercicio' 
                         imagem='nothing' 
                         palavrasCorretas={['nada']}  
                         contexto='  '
                         voltar={'Pop1'}/> bring me down{'\n'}
            I said{'\n'}{'\n'}

            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you feel like a room without a roof{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you feel like happiness is the truth{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you know what happiness is to you{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}
            Clap along if you feel like that's what you wanna do{'\n'}{'\n'}

            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/> feel like a room without a roof{'\n'}

            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto=' '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you feel like happiness is the truth{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you know what happiness is to you{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you feel like that's what you wanna do{'\n'}{'\n'}

            bring me down{'\n'}
            Can't <Botao palavra='nothing'
                         destino='Exercicio' 
                         imagem='nothing' 
                         palavrasCorretas={['nada']}  
                         contexto='  '
                         voltar={'Pop1'}/> (happy) bring me down{'\n'}
                         
            My level's too high (happy) to bring me down{'\n'}
            Can't nothing (happy) bring me down{'\n'}
            I said{'\n'}{'\n'}

            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you feel like a room without a roof{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you feel like happiness is the truth{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto=''
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you know what happiness is to you{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}
            Clap along if you feel like that's what you wanna do{'\n'}{'\n'}

            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you feel like a room without a roof{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you feel like happiness is the truth{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto=' '
                               voltar={'Pop1'}/>{'\n'}

            Clap along if you know what happiness is to you{'\n'}
            Because I'm <Botao palavra='happy'
                               destino='Exercicio' 
                               imagem='happy face' 
                               palavrasCorretas={['feliz']}  
                               contexto='  '
                               voltar={'Pop1'}/>{'\n'}
            Clap along if you feel like that's what you wanna do{'\n'}{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Pop1;