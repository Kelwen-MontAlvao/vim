import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Pop3() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'JGwWNGJdvx8'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero2'/>
        <Text style={estilos.titulo}>
          Ed Sheeran - Shape of You
        </Text>
        <Text style={estilos.letraMusica}>  
          The <Botao palavra='club'
                     destino='Exercicio' 
                     imagem='club' 
                     palavrasCorretas={['clube']}  
                     contexto='  '
                     voltar={'Pop3'}/> isn't the best place to find a lover {'\n'}

          So the bar is where I go{'\n'}
          Me and my friends at the <Botao palavra='table'
                                          destino='Exercicio' 
                                          imagem='table' 
                                          palavrasCorretas={['mesa']}  
                                          contexto='  '
                                          voltar={'Pop3'}/> doing shots{'\n'}
          Drinking <Botao palavra='fast'
                          destino='Exercicio' 
                          imagem='fast' 
                          palavrasCorretas={['rápido', 'veloz', 'rapido']}  
                          contexto='  '
                          voltar={'Pop3'}/> and then we talk <Botao palavra='slow'
                                                                              destino='Exercicio' 
                                                                              imagem='turtle on sand' 
                                                                              palavrasCorretas={['Devagar', 'lento']}  
                                                                              contexto='  '
                                                                              voltar={'Pop3'}/>{'\n'}

          Come over and start up a conversation with just me{'\n'}
          And <Botao palavra='trust'
                     destino='Exercicio' 
                     imagem='trust' 
                     palavrasCorretas={['confiar', 'confie']}  
                     contexto=' '
                     voltar={'Pop3'}/> me I'll give it a chance now{'\n'}

          Take my <Botao palavra='hand'
                         destino='Exercicio' 
                         imagem='hand' 
                         palavrasCorretas={['mão', 'mao']}  
                         contexto='  '
                         voltar={'Pop3'}/>, stop, put Van the Man on the jukebox{'\n'}

          And then we start to <Botao palavra='dance'
                                      destino='Exercicio' 
                                      imagem='dancing' 
                                      palavrasCorretas={['dançar', 'dança']}  
                                      contexto='  '
                                      voltar={'Pop3'}/>, and now I'm <Botao palavra='singing'
                                                                                      destino='Exercicio' 
                                                                                      imagem='singing' 
                                                                                      palavrasCorretas={['cantando', 'cantar']}  
                                                                                      contexto=' '
                                                                                      voltar={'Pop3'}/> like{'\n'}{'\n'}

          Girl, you know I want your love{'\n'}
          Your love was <Botao palavra='handmade'
                               destino='Exercicio' 
                               imagem='handmade' 
                               palavrasCorretas={['feito á mão', 'artesanal']}  
                               contexto='  '
                               voltar={'Pop3'}/> for somebody like me{'\n'}

          Come on now, follow my lead{'\n'}
          I may be <Botao palavra='crazy'
                          destino='Exercicio' 
                          imagem='crazy' 
                          palavrasCorretas={['louco', 'maluco']}  
                          contexto='  '
                          voltar={'Pop3'}/>, don't mind me{'\n'}

          Say, boy, let's not talk too much{'\n'}
          Grab on my <Botao palavra='waist'
                            destino='Exercicio' 
                            imagem='waist' 
                            palavrasCorretas={['cintura']}  
                            contexto='  '
                            voltar={'Pop3'}/> and put that <Botao palavra='body'
                                                                            destino='Exercicio' 
                                                                            imagem='body' 
                                                                            palavrasCorretas={['corpo']}  
                                                                            contexto='  '
                                                                            voltar={'Pop3'}/> on me{'\n'}

          Come on now, follow my <Botao palavra='lead'
                                        destino='Exercicio' 
                                        imagem='lead' 
                                        palavrasCorretas={['liderança', 'lidere']}  
                                        contexto=' '
                                        voltar={'Pop3'}/>{'\n'}

          Come, come on now, follow my <Botao palavra='lead'
                                              destino='Exercicio' 
                                              imagem='lead' 
                                              palavrasCorretas={['liderança', 'lidere']}  
                                              contexto=' '
                                              voltar={'Pop3'}/>{'\n'}{'\n'}

          I'm in love with the shape of you{'\n'}
          We push and pull like a magnet do{'\n'}
          Although my <Botao palavra='heart'
                             destino='Exercicio' 
                             imagem='heart' 
                             palavrasCorretas={['coração', 'coracao']}  
                             contexto='  '
                             voltar={'Pop3'}/> is falling too{'\n'}{'\n'}

          I'm in love with your <Botao palavra='body'
                                       destino='Exercicio' 
                                       imagem='body' 
                                       palavrasCorretas={['corpo']}  
                                       contexto='  '
                                       voltar={'Pop3'}/>{'\n'}
          And last night you were in my room{'\n'}
          And now my bedsheets smell like you{'\n'}
          Every day discovering something brand new{'\n'}
          I'm in love with your <Botao palavra='body'
                                       destino='Exercicio' 
                                       imagem='body' 
                                       palavrasCorretas={['corpo']}  
                                       contexto='  '
                                       voltar={'Pop3'}/>{'\n'}
          (Oh-I-oh-I-oh-I-oh-I){'\n'}
          I'm in love with your <Botao palavra='body'
                                       destino='Exercicio' 
                                       imagem='body' 
                                       palavrasCorretas={['corpo']}  
                                       contexto=' '
                                       voltar={'Pop3'}/>{'\n'}
          (Oh-I-oh-I-oh-I-oh-I){'\n'}
          I'm in love with your <Botao palavra='body'
                                       destino='Exercicio' 
                                       imagem='body' 
                                       palavrasCorretas={['corpo']}  
                                       contexto=' '
                                       voltar={'Pop3'}/>{'\n'}
          (Oh-I-oh-I-oh-I-oh-I){'\n'}
          I'm in love with your <Botao palavra='body'
                                       destino='Exercicio' 
                                       imagem='body' 
                                       palavrasCorretas={['corpo']}  
                                       contexto=' '
                                       voltar={'Pop3'}/>{'\n'}
          Every day discovering something brand new{'\n'}
          I'm in love with the shape of you{'\n'}

          One <Botao palavra='week'
                     destino='Exercicio' 
                     imagem='calendary' 
                     palavrasCorretas={['semana']}  
                     contexto='  '
                     voltar={'Pop3'}/> in we let the story begin{'\n'}

          We're going out on our first <Botao palavra='date'
                                              destino='Exercicio' 
                                              imagem='date' 
                                              palavrasCorretas={['encontro']}  
                                              contexto='Junção de pessoas de forma romântica'
                                              voltar={'Pop3'}/>{'\n'}

          You and me are thrifty, so go all you can eat{'\n'}
          Fill up your <Botao palavra='bag'
                              destino='Exercicio' 
                              imagem='bag' 
                              palavrasCorretas={['mochila', 'bag']}  
                              contexto='  '
                              voltar={'Pop3'}/> and I fill up a plate{'\n'}
          We talk for hours and hours about the <Botao palavra='sweet'
                                                       destino='Exercicio' 
                                                       imagem='sweet' 
                                                       palavrasCorretas={['doce']}  
                                                       contexto='  '
                                                       voltar={'Pop3'}/> and the sour{'\n'}
          And how your family is doing okay{'\n'}
          And leave and get in a taxi, then <Botao palavra='kiss'
                                                   destino='Exercicio' 
                                                   imagem='kiss' 
                                                   palavrasCorretas={['beijo', 'beijamos']}  
                                                   contexto='  '
                                                   voltar={'Pop3'}/> in the backseat{'\n'}

          Tell the driver make the radio play, and I'm singing like{'\n'}{'\n'}

          Girl, you know I want your love{'\n'}
          Your love was <Botao palavra='handmade'
                               destino='Exercicio' 
                               imagem='handmade' 
                               palavrasCorretas={['feito á mão', 'artesanal']}  
                               contexto=' '
                               voltar={'Pop3'}/> for somebody like me{'\n'}

          Come on now, follow my <Botao palavra='lead'
                                        destino='Exercicio' 
                                        imagem='lead' 
                                        palavrasCorretas={['liderança']}  
                                        contexto='  '
                                        voltar={'Pop3'}/>{'\n'}

          I may be <Botao palavra='crazy'
                          destino='Exercicio' 
                          imagem='crazy' 
                          palavrasCorretas={['louco', 'maluco']}  
                          contexto=' '
                          voltar={'Pop3'}/>, don't mind me{'\n'}

          Say, boy, let's not talk too much{'\n'}
          Grab on my <Botao palavra='waist'
                            destino='Exercicio' 
                            imagem='waist' 
                            palavrasCorretas={['cintura']}  
                            contexto='  '
                            voltar={'Pop3'}/>and put that<Botao palavra='body'
                                                                            destino='Exercicio' 
                                                                            imagem='body' 
                                                                            palavrasCorretas={['corpo']}  
                                                                            contexto='  '
                                                                            voltar={'Pop3'}/>on me{'\n'}
          Come on now, follow my <Botao palavra='lead'
                                        destino='Exercicio' 
                                        imagem='lead' 
                                        palavrasCorretas={['liderança']}  
                                        contexto='  '
                                        voltar={'Pop3'}/>{'\n'}

          Come, come on now, follow my <Botao palavra='lead'
                                              destino='Exercicio' 
                                              imagem='lead' 
                                              palavrasCorretas={['liderança']}  
                                              contexto='  '
                                              voltar={'Pop3'}/>{'\n'}{'\n'}

          I'm in love with the shape of you{'\n'}
          We push and pull like a magnet do{'\n'}
          Although my <Botao palavra='heart'
                             destino='Exercicio' 
                             imagem='heart' 
                             palavrasCorretas={['coração', 'coracao']}  
                             contexto='  '
                             voltar={'Pop3'}/> is falling too{'\n'}

          I'm in love with your <Botao palavra='body'
                                       destino='Exercicio' 
                                       imagem='body' 
                                       palavrasCorretas={['corpo']}  
                                       contexto='  '
                                       voltar={'Pop3'}/>{'\n'}

          And last night you were in my room{'\n'}
          And now my <Botao palavra='bedsheets'
                            destino='Exercicio' 
                            imagem='bedsheets' 
                            palavrasCorretas={['lençois', 'lençol']}  
                            contexto='  '
                            voltar={'Pop3'}/> smell like you{'\n'}
          Every day discovering something brand new{'\n'}{'\n'}

          I'm in love with your <Botao palavra='body'
                                       destino='Exercicio' 
                                       imagem='body' 
                                       palavrasCorretas={['corpo']}  
                                       contexto='  '
                                       voltar={'Pop3'}/>{'\n'}
          (Oh-I-oh-I-oh-I-oh-I){'\n'}
          I'm in love with your <Botao palavra='body'
                                       destino='Exercicio' 
                                       imagem='body' 
                                       palavrasCorretas={['corpo']}  
                                       contexto='  '
                                       voltar={'Pop3'}/>{'\n'}
          (Oh-I-oh-I-oh-I-oh-I){'\n'}
          I'm in love with your <Botao palavra='body'
                                       destino='Exercicio' 
                                       imagem='body' 
                                       palavrasCorretas={['corpo']}  
                                       contexto='  '
                                       voltar={'Pop3'}/>{'\n'}
          (Oh-I-oh-I-oh-I-oh-I){'\n'}
          I'm in love with your <Botao palavra='body'
                                       destino='Exercicio' 
                                       imagem='body' 
                                       palavrasCorretas={['corpo']}  
                                       contexto='  '
                                       voltar={'Pop3'}/>{'\n'}
          Every day discovering something brand new{'\n'}
          I'm in love with the shape of you{'\n'}{'\n'}

          Come on, be my baby, come on{'\n'}
          Come on, be my baby, come on{'\n'}
          Come on, be my baby, come on{'\n'}
          Come on, be my baby, come on{'\n'}
          Come on, be my baby, come on{'\n'}
          Come on, be my baby, come on{'\n'}
          Come on, be my baby, come on{'\n'}
          Come on, be my baby, come on{'\n'}{'\n'}

          I'm in love with the shape of you{'\n'}
          We push and pull like a magnet do{'\n'}
          Although my <Botao palavra='heart'
                             destino='Exercicio' 
                             imagem='heart' 
                             palavrasCorretas={['coração', 'coracao']}  
                             contexto='  '
                             voltar={'Pop3'}/> is falling too{'\n'}
          I'm in love with your body{'\n'}
          And last night you were in my room{'\n'}
          And now my bedsheets smell like you{'\n'}
          Every day discovering something brand new{'\n'}
          I'm in love with your  {'\n'}
          Come on, be my baby, come on{'\n'}
          Come on (I'm in love with your <Botao palavra='body'
                                                destino='Exercicio' 
                                                imagem='body' 
                                                palavrasCorretas={['corpo']}  
                                                contexto='  '
                                                voltar={'Pop3'}/>), be my baby, come on{'\n'}
          Come on, be my baby, come on{'\n'}
          Come on (I'm in love with your <Botao palavra='body'
                                                destino='Exercicio' 
                                                imagem='body' 
                                                palavrasCorretas={['corpo']}  
                                                contexto='  '
                                                voltar={'Pop3'}/>), be my baby, come on{'\n'}
          Come on, be my baby, come on{'\n'}
          Come on (I'm in love with your <Botao palavra='body'
                                                destino='Exercicio' 
                                                imagem='body' 
                                                palavrasCorretas={['corpo']}  
                                                contexto='  '
                                                voltar={'Pop3'}/>), be my baby, come on{'\n'}
          Every day discovering something brand new{'\n'}
          I'm in love with the shape of you{'\n'}

        
          
        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Pop3;