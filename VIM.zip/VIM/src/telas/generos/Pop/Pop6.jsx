import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Pop6() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'G7KNmW9a75Y'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero2'/>
        <Text style={estilos.titulo}>
        Miley Cyrus - Flowers
        </Text>

        <Text style={estilos.letraMusica}>  
        We were good, we were <Botao palavra='gold'
						destino='Exercicio'
						imagem='gold'
						palavrasCorretas={['ouro']}
						contexto=''
						voltar={'Pop6'}/>{"\n"}

Kind of dream that can't be <Botao palavra='sold'
						destino='Exercicio'
						imagem='sold'
						palavrasCorretas={['vender']}
						contexto=''
						voltar={'Pop6'}/>{"\n"}{'\n'}

We were right 'til we weren't{"\n"}
Built a home and watched it <Botao palavra='burn'
						destino='Exercicio'
						imagem='burn'
						palavrasCorretas={['queimar']}
						contexto=''
						voltar={'Pop6'}/>{"\n"}

Hum, I didn't wanna leave you{"\n"}
I didn't wanna lie{"\n"}
Started to <Botao palavra='cry'
						destino='Exercicio'
						imagem='cry'
						palavrasCorretas={['chorar']}
						contexto=''
						voltar={'Pop6'}/>, but then remembered I{"\n"}{'\n'}

I can buy myself <Botao palavra='flowers'
						destino='Exercicio'
						imagem='flowers'
						palavrasCorretas={['flores', 'flor']}
						contexto=''
						voltar={'Pop6'}/>{"\n"}

<Botao palavra='Write'
						destino='Exercicio'
						imagem='write'
						palavrasCorretas={['escrever', 'escrevendo']}
						contexto=''
						voltar={'Pop6'}/>my name in the sand{"\n"}
Talk to myself for hours{"\n"}
Say things you don't understand{"\n"}
I can take myself dancing{"\n"}
And I can hold my own hand{"\n"}
Yeah, I can love me better than you can{"\n"}{'\n'}

Can love me better{"\n"}
I can love me better, baby{"\n"}
Can love me better{"\n"}
I can love me better, baby{"\n"}{'\n'}

Paint my <Botao palavra='nails'
						destino='Exercicio'
						imagem='nails'
						palavrasCorretas={['unha','unhas']}
						contexto=''
						voltar={'Pop6'}/> cherry-red{"\n"}

Match the roses that you left{"\n"}
No remorse, no regret{"\n"}
I forgive every word you said{"\n"}{'\n'}

Ooh, I didn't wanna leave, baby{"\n"}
I didn't wanna fight{"\n"}
Started to <Botao palavra='cry'
						destino='Exercicio'
						imagem='cry'
						palavrasCorretas={['chorar']}
						contexto=''
						voltar={'Pop6'}/>, but then remembered I{"\n"}

I can buy myself <Botao palavra='flowers'
						destino='Exercicio'
						imagem='flowers'
						palavrasCorretas={['flores', 'flor']}
						contexto=''
						voltar={'Pop6'}/>{"\n"}

<Botao palavra='Write'
						destino='Exercicio'
						imagem='write'
						palavrasCorretas={['escrever', 'escrevendo']}
						contexto=''
						voltar={'Pop6'}/>my name in the sand{"\n"}
Talk to myself for hours, yeah{"\n"}
Say things you don't understand{"\n"}
I can take myself dancing, yeah{"\n"}
I can hold my own hand{"\n"}
Yeah, I can love me better than you can{"\n"}{'\n'}

Can love me better{"\n"}
I can love me better, baby{"\n"}
Can love me better{"\n"}
I can love me better, baby{"\n"}
Can love me better{"\n"}
I can love me better, baby{"\n"}
Can love me better, ooh, I{"\n"}{'\n'}

I didn't wanna leave you{"\n"}
I didn't wanna fight{"\n"}
Started to <Botao palavra='cry'
						destino='Exercicio'
						imagem='cry'
						palavrasCorretas={['chorar']}
						contexto=''
						voltar={'Pop6'}/>, but then remembered I{"\n"}

<Botao palavra='flowers'
						destino='Exercicio'
						imagem='flowers'
						palavrasCorretas={['flores', 'flor']}
						contexto=''
						voltar={'Pop6'}/>(uuh uuh){"\n"}

<Botao palavra='Write'
						destino='Exercicio'
						imagem='write'
						palavrasCorretas={['escrever', 'escrevendo']}
						contexto=''
						voltar={'Pop6'}/>my name in the sand{"\n"}{'\n'}

Talk to myself for hours (yeah){"\n"}
Say things you don't understand (better than you){"\n"}
I can take myself dancing (yeah){"\n"}
I can hold my own hand{"\n"}
Yeah, I can love me better than{"\n"}
Yeah, I can love me better than you can{"\n"}{'\n'}

Can love me better{"\n"}
I can love me better, baby (oh){"\n"}
Can love me better{"\n"}
I can love me better, baby (than you can){"\n"}
Can love me better{"\n"}
I can love me better, baby{"\n"}
Can love me better, I{"\n"}{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Pop6;