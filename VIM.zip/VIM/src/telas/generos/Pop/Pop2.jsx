import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Pop2() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'LjhCEhWiKXk'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero2'/>
        <Text style={estilos.titulo}>
          Bruno Mars - Just The Way You Are
        </Text>

        <Text style={estilos.letraMusica}>  
          Oh, her eyes, her eyes  {'\n'}
          Make the <Botao palavra='stars'
                          destino='Exercicio' 
                          imagem='stars' 
                          palavrasCorretas={['estrelas']}  
                          contexto='  '
                          voltar={'Pop2'}/> look like they're not shinin'{'\n'}

          Her <Botao palavra='hair'
                     destino='Exercicio' 
                     imagem='hair' 
                     palavrasCorretas={['cabelo']}  
                     contexto='  '
                     voltar={'Pop2'}/>, her <Botao palavra='hair'
                                                             destino='Exercicio' 
                                                             imagem='hair' 
                                                             palavrasCorretas={['cabelo']}  
                                                             contexto='  '
                                                             voltar={'Pop2'}/>{'\n'}

          Falls perfectly without her tryin'{'\n'}
          She's so <Botao palavra='beautiful'
                          destino='Exercicio' 
                          imagem='beautiful' 
                          palavrasCorretas={['lindo', 'bonito', 'linda', 'bonita']}  
                          contexto='  '
                          voltar={'Pop2'}/> and I tell her everyday{'\n'}

          Yeah, I know, I know{'\n'}
          When I <Botao palavra='compliment'
                        destino='Exercicio' 
                        imagem='compliment' 
                        palavrasCorretas={['elogio']}  
                        contexto='  '
                        voltar={'Pop2'}/> her, she won't believe me{'\n'}

          And it's so, it's so{'\n'}
          Sad to think that she don't see what I see{'\n'}
          But every time she asks me, "Do I look okay?"{'\n'}
          I say {'\n'}{'\n'}

          When I see your <Botao palavra='face'
                                 destino='Exercicio' 
                                 imagem='face' 
                                 palavrasCorretas={['rosto']}  
                                 contexto='  '
                                 voltar={'Pop2'}/>{'\n'}

          There's not a thing that I would change{'\n'}
          'Cause you're <Botao palavra='amazing'
                               destino='Exercicio' 
                               imagem='amazing' 
                               palavrasCorretas={['incrível', 'incrivel']}  
                               contexto='  '
                               voltar={'Pop2'}/>{'\n'}

          Just the way you are{'\n'}
          And when you <Botao palavra='smile'
                              destino='Exercicio' 
                              imagem='smile' 
                              palavrasCorretas={['sorriso']}  
                              contexto='  '
                              voltar={'Pop2'}/>{'\n'}

          The whole world stops and <Botao palavra='stares'
                                           destino='Exercicio' 
                                           imagem='stares' 
                                           palavrasCorretas={['olhar fixo', 'olhar fixamente', 'encarar']}  
                                           contexto='  '
                                           voltar={'Pop2'}/> for a while{'\n'}

          'Cause girl, you're amazing{'\n'}
          Just the way you are{'\n'}
          Yeah{'\n'}{'\n'}

          Her <Botao palavra='lips'
                     destino='Exercicio' 
                     imagem='lips' 
                     palavrasCorretas={['lábios', 'labios']}  
                     contexto='  '
                     voltar={'Pop2'}/>, her <Botao palavra='lips'
                                                             destino='Exercicio' 
                                                             imagem='lips' 
                                                             palavrasCorretas={['lábios', 'labios']}  
                                                             contexto='  '
                                                             voltar={'Pop2'}/>{'\n'}

          I could <Botao palavra='kiss'
                         destino='Exercicio' 
                         imagem='kiss' 
                         palavrasCorretas={['beijo', 'beijar']}  
                         contexto='  '
                         voltar={'Pop2'}/> them all day if she'd let me{'\n'}

          Her <Botao palavra='laugh'
                     destino='Exercicio' 
                     imagem='someone laughing' 
                     palavrasCorretas={['rir', 'rindo', 'risada', 'riso']}  
                     contexto='  '
                     voltar={'Pop2'}/>, her <Botao palavra='laugh'
                                                             destino='Exercicio' 
                                                             imagem='someone laughing' 
                                                             palavrasCorretas={['rir', 'rindo', 'risada', 'riso']}  
                                                             contexto=' '
                                                             voltar={'Pop2'}/>{'\n'}

          She <Botao palavra='hates'
                     destino='Exercicio' 
                     imagem='hates' 
                     palavrasCorretas={['odeio', 'odeia', 'odiar']}  
                     contexto='  '
                     voltar={'Pop2'}/>, but I think it's so sexy{'\n'}

          She's so <Botao palavra='beautiful'
                          destino='Exercicio' 
                          imagem='beautiful' 
                          palavrasCorretas={['lindo', 'bonito']}  
                          contexto='  '
                          voltar={'Pop2'}/> and I tell her everyday{'\n'}

          Oh, you know, you know{'\n'}
          You know I'd never ask you to change{'\n'}
          If perfect's what you're searchin' for, then just stay the same{'\n'}
          So don't even <Botao palavra='bother'
                               destino='Exercicio' 
                               imagem='bothers' 
                               palavrasCorretas={['incomode', 'importe', 'se importe', 'importa', 'incomoda']}  
                               contexto=' '
                               voltar={'Pop2'}/> askin' if you look okay{'\n'}
          You know I'll say{'\n'}{'\n'}

          When I see your <Botao palavra='face'
                                 destino='Exercicio' 
                                 imagem='face' 
                                 palavrasCorretas={['rosto', 'face']}  
                                 contexto='  '
                                 voltar={'Pop2'}/>{'\n'}

          There's not a thing that I would change{'\n'}
          'Cause you're <Botao palavra='amazing'
                               destino='Exercicio' 
                               imagem='amazing' 
                               palavrasCorretas={['incrível', 'incrivel']}  
                               contexto='  '
                               voltar={'Pop2'}/>{'\n'}

          Just the way you are{'\n'}
          And when you <Botao palavra='smile'
                              destino='Exercicio' 
                              imagem='smile' 
                              palavrasCorretas={['sorriso']}  
                              contexto=' '
                              voltar={'Pop2'}/>{'\n'}

          The whole world stops and <Botao palavra='stares'
                                           destino='Exercicio' 
                                           imagem='stares' 
                                           palavrasCorretas={['olhar fixo', 'olhar fixamente', 'encara']}  
                                           contexto='  '
                                           voltar={'Pop2'}/> for a while{'\n'}

          'Cause girl, you're <Botao palavra='amazing'
                                     destino='Exercicio' 
                                     imagem='amazing' 
                                     palavrasCorretas={['incrível', 'incrivel']}  
                                     contexto='  '
                                     voltar={'Pop2'}/>{'\n'}
                                     

          Just the way you are{'\n'}{'\n'}

          The way you are{'\n'}
          The way you are{'\n'}
          Girl, you're amazing{'\n'}
          Just the way you are{'\n'}{'\n'}

          When I see your <Botao palavra='face'
                                 destino='Exercicio' 
                                 imagem='face' 
                                 palavrasCorretas={['rosto', 'face']}  
                                 contexto=' '
                                 voltar={'Pop2'}/>{'\n'}

          There's not a thing that I would change{'\n'}
          'Cause you're <Botao palavra='amazing'
                               destino='Exercicio' 
                               imagem='amazing' 
                               palavrasCorretas={['incrível', 'incrivel']}  
                               contexto='  '
                               voltar={'Pop2'}/>{'\n'}

          Just the way you are{'\n'}
          And when you <Botao palavra='smile'
                              destino='Exercicio' 
                              imagem='smile' 
                              palavrasCorretas={['sorriso']}  
                              contexto='  '
                              voltar={'Pop2'}/>{'\n'}

          The whole world stops and stares for a while{'\n'}
          'Cause girl, you're <Botao palavra='amazing'
                                     destino='Exercicio' 
                                     imagem='amazing' 
                                     palavrasCorretas={['incrível', 'incrivel']}  
                                     contexto='  '
                                     voltar={'Pop2'}/>{'\n'}
          Just the way you are{'\n'}
          Yeah{'\n'}{'\n'}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Pop2;