import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Pop7() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'a_adA7PDs1E'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero2'/>
        <Text style={estilos.titulo}>
        The Rose - Back To Me
        </Text>

        <Text style={estilos.letraMusica}>  
        I can make you <Botao palavra='mad'
						destino='Exercicio'
						imagem='mad'
						palavrasCorretas={['louca', 'maluca', 'louco', 'maluco']}
						contexto=''
						voltar={'Pop7'}/>{'\n'} I can make you

				 <Botao palavra='scream'
						destino='Exercicio'
						imagem='scream'
						palavrasCorretas={['gritar', 'gritando']}
						contexto=''
						voltar={'Pop7'}/>{"\n"}

I can make you <Botao palavra='cry'
						destino='Exercicio'
						imagem='cry'
						palavrasCorretas={[ 'chorar', 'chorando']}
						contexto=''
						voltar={'Pop7'}/>,{"\n"}
 I can make you leave{"\n"}
I can make you hate me for everything{"\n"}
But I can't make you come back to me{"\n"}{'\n'}

But I can't make you come back to me{"\n"}{'\n'}

Called me all day {'\n'}but I never <Botao palavra='pick up'
						destino='Exercicio'
						imagem='calling'
						palavrasCorretas={['atendendo','atender', 'atendo']}
						contexto=''
						voltar={'Pop7'}/> {"\n"}

Instead of pulling my weight{"\n"}
Always pushing my luck{"\n"}{'\n'}

You gave me all that I could take{"\n"}
Yeah, I took it all for granted{"\n"}

				<Botao palavra='Head'
						destino='Exercicio'
						imagem='head'
						palavrasCorretas={['cabeça']}
						contexto=''
						voltar={'Pop7'}/> up in the 

				<Botao palavra='cloud'
						destino='Exercicio'
						imagem='cloud'
						palavrasCorretas={['nuvens', 'nuvem']}
						contexto=''
						voltar={'Pop7'}/>{"\n"}

Yeah, I never understand it{"\n"}{'\n'}

I remember thinking, I don't need you{"\n"}
But then time passed by and it's so untrue{"\n"}
Now, I'm thе		 <Botao palavra='rain'
						destino='Exercicio'
						imagem='rain'
						palavrasCorretas={['chuva']}
						contexto=''
						voltar={'Pop7'}/> over your

			<Botao palavra='parade'
						destino='Exercicio'
						imagem='parede'
						palavrasCorretas={[ 'desfile']}
						contexto=''
						voltar={'Pop7'}/> {"\n"}

Reason you'rе over me{"\n"}
Yeah, I always keep making the same mistakes{"\n"}
Maybe I never deserved you anyways{"\n"}{'\n'}

I can make you <Botao palavra='mad'
						destino='Exercicio'
						imagem='mad'
						palavrasCorretas={['louca', 'maluca', 'louco', 'maluco']}
						contexto=''
						voltar={'Pop7'}/> {'\n'}I can make you

				 <Botao palavra='scream'
						destino='Exercicio'
						imagem='scream'
						palavrasCorretas={['gritar', 'gritando']}
						contexto=''
						voltar={'Pop7'}/>{"\n"}

I can make you <Botao palavra='cry'
						destino='Exercicio'
						imagem='cry'
						palavrasCorretas={[ 'chorar', 'chorando']}
						contexto=''
						voltar={'Pop7'}/>,
						{'\n'} I can make you leave{"\n"}

 
I can make you hate me for everything{"\n"}
But I can't make you come back to me{"\n"}{'\n'}

I can make a world out of broken <Botao palavra='dreams'
						destino='Exercicio'
						imagem='dreams'
						palavrasCorretas={[ 'sonho', 'sonhos']}
						contexto=''
						voltar={'Pop7'}/>{"\n"}
			
I can make you say things you don't mean{"\n"}
I can unmake all we were made to be{"\n"}
But I can't make you come back to me{"\n"}{'\n'}

But I can’t make you come back to me{"\n"}{'\n'}

Calling all day, {'\n'}tryna make things right{"\n"}
Just to fuck it all up {'\n'}when I see you 
					<Botao palavra='tonight'
						destino='Exercicio'
						imagem='night'
						palavrasCorretas={['hoje', 'noite', 'hoje a noite']}
						contexto=''
						voltar={'Pop7'}/> {"\n"}{'\n'}

				
Since you told me, hit the road{"\n"}
I've been I can make you <Botao palavra='running on'
						destino='Exercicio'
						imagem='running'
						palavrasCorretas={['correr' ,'correndo', 'corrida']}
						contexto=''
						voltar={'Pop7'}/> 

				    <Botao palavra='empty'
						destino='Exercicio'
						imagem='vazio'
						palavrasCorretas={['vazio', 'vazia', 'nada']}
						contexto=''
						voltar={'Pop7'}/>

If anything I know, it's how to ruin a happy ending{"\n"}{'\n'}

And I remember when you still needed me{"\n"}
Don't know how I let it go so easily{"\n"}
Now, I'm the cloud to your    <Botao palavra='sunny days'
						destino='Exercicio'
						imagem='sunny days'
						palavrasCorretas={['dia ensolarado', 'ensolarado', 'verão', 'verões', 'dias de sol']}
						contexto=''
						voltar={'Pop7'}/>{"\n"}
Reason you run away{"\n"}
Don’t know how I keep making the same mistakes{"\n"}
Maybe I never deserved you anyway{"\n"}{'\n'}

I can make you <Botao palavra='mad'
						destino='Exercicio'
						imagem='mad'
						palavrasCorretas={['louca', 'maluca', 'louco', 'maluco']}
						contexto=''
						voltar={'Pop7'}/> {'\n'}I can make you

				 <Botao palavra='scream'
						destino='Exercicio'
						imagem='scream'
						palavrasCorretas={['gritar', 'gritando']}
						contexto=''
						voltar={'Pop7'}/>{"\n"}


I can make you  <Botao palavra='cry'
						destino='Exercicio'
						imagem='cry'
						palavrasCorretas={[ 'chorar', 'chorando']}
						contexto=''
						voltar={'Pop7'}/>,{'\n'} I can make you leave{"\n"}

I can make you hate me for everything{"\n"}
But I can't make you come back to me{"\n"}{'\n'}

I can make a world out of broken <Botao palavra='dreams'
						destino='Exercicio'
						imagem='dreams'
						palavrasCorretas={[ 'sonho', 'sonhos']}
						contexto=''
						voltar={'Pop7'}/>{"\n"}
 
I can make you say things you don't mean{"\n"}
I can unmake all we were made to be{"\n"}{'\n'}
But I can't make you come back to me{"\n"}{'\n'}

But I can't make you come back to me{"\n"}{'\n'}

I can unmake all we were made to be{"\n"}
But I can't make you come back to me{"\n"}{'\n'}

I can make you <Botao palavra='mad'
						destino='Exercicio'
						imagem='mad'
						palavrasCorretas={['louca', 'maluca', 'louco', 'maluco']}
						contexto=''
						voltar={'Pop7'}/> {'\n'}I can make you

				 <Botao palavra='scream'
						destino='Exercicio'
						imagem='scream'
						palavrasCorretas={['gritar', 'gritando']}
						contexto=''
						voltar={'Pop7'}/>{"\n"}

I can make you  <Botao palavra='cry'
						destino='Exercicio'
						imagem='cry'
						palavrasCorretas={[ 'chorar', 'chorando']}
						contexto=''
						voltar={'Pop7'}/>,{'\n'} I can make you leave{"\n"}
I can make you hate me for everything{"\n"}
But I can't make you come back to me{"\n"}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Pop7;