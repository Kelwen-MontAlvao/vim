import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Pop5() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'ShZ978fBl6Y'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero2'/>
        <Text style={estilos.titulo}>
        Calum Scott - You Are The Reason
        </Text>

        <Text style={estilos.letraMusica}>  
        There goes my heart beating{"\n"}
'Cause you are the reason{"\n"}
I'm losing my sleep{"\n"}
Please, come back now{"\n"}{'\n'}

And there goes my mind  <Botao palavra='racing'
						destino='Exercicio'
						imagem='racing'
						palavrasCorretas={['voando', 'voar']}
						contexto=''
						voltar={'Pop5'}/>{"\n"}
And you are the reason{"\n"}
That I'm still			 <Botao palavra='breathing'
						destino='Exercicio'
						imagem='breath'
						palavrasCorretas={['respirar', 'respirando', 'respiro']}
						contexto=''
						voltar={'Pop5'}/>{"\n"}
I'm hopeless now{"\n"}{'\n'}

I'd 					<Botao palavra='climb'
						destino='Exercicio'
						imagem='climb'
						palavrasCorretas={['escalada', 'escalo', 'escalando', 'subo']}
						contexto=''
						voltar={'Pop5'}/> every mountain{"\n"}

And 				 <Botao palavra='swim'
						destino='Exercicio'
						imagem='swim'
						palavrasCorretas={['mergulho', 'nado', 'nadar', 'nadando']}
						contexto=''
						voltar={'Pop5'}/> every

				 <Botao palavra='ocean'
						destino='Exercicio'
						imagem='ocean'
						palavrasCorretas={['mar', 'oceano']}
						contexto=''
						voltar={'Pop5'}/>{"\n"}
Just to be with you{"\n"}
And fix what I've broken{"\n"}
Oh, 'cause I need you to see{"\n"}
That you are the reason{"\n"}{'\n'}

There goes my hands shaking{"\n"}
And you are the reason{"\n"}
My heart keeps 			<Botao palavra='bleeding'
						destino='Exercicio'
						imagem='bleed'
						palavrasCorretas={['sangrar', 'sangrando']}
						contexto=''
						voltar={'Pop5'}/> 

I need you now{"\n"}{'\n'}

If I could turn back the <Botao palavra='clock'
						destino='Exercicio'
						imagem='clock'
						palavrasCorretas={[ 'tempo']}
						contexto=''
						voltar={'Pop5'}/>{"\n"}

I'd make sure the light defeated the dark{"\n"}
I'd spend every hour of every day{"\n"}
Keeping you safe{"\n"}{'\n'}

I'd 					<Botao palavra='climb'
						destino='Exercicio'
						imagem='climb'
						palavrasCorretas={['escalada', 'escalo', 'escalando', 'subo']}
						contexto=''
						voltar={'Pop5'}/> every mountain{"\n"}

And 				 <Botao palavra='swim'
						destino='Exercicio'
						imagem='swim'
						palavrasCorretas={['mergulho', 'nado', 'nadar', 'nadando']}
						contexto=''
						voltar={'Pop5'}/> every

				 <Botao palavra='ocean'
						destino='Exercicio'
						imagem='ocean'
						palavrasCorretas={['mar', 'oceano']}
						contexto=''
						voltar={'Pop5'}/>{"\n"}
Just to be with you{"\n"}
And fix what I've broken{"\n"}
Oh, 'cause I need you to see{"\n"}
That you are the reason{"\n"}{'\n'}

(I don't wanna fight no more){"\n"}
(I don't wanna hide no more){"\n"}
(I don't wanna cry no more){"\n"}
(Come back I need you to hold me) you are the reason{"\n"}
(A little closer now){"\n"}
(Just a little closer now){"\n"}
(Come a little closer now){"\n"}
I need you to hold me tonight{"\n"}{'\n'}

I'd 					<Botao palavra='climb'
						destino='Exercicio'
						imagem='climb'
						palavrasCorretas={['escalada', 'escalo', 'escalando', 'subo']}
						contexto=''
						voltar={'Pop5'}/> every mountain{"\n"}

And 				 <Botao palavra='swim'
						destino='Exercicio'
						imagem='swim'
						palavrasCorretas={['mergulho', 'nado', 'nadar', 'nadando']}
						contexto=''
						voltar={'Pop5'}/> every

				 <Botao palavra='ocean'
						destino='Exercicio'
						imagem='ocean'
						palavrasCorretas={['mar', 'oceano']}
						contexto=''
						voltar={'Pop5'}/>{"\n"}
Just to be with you{"\n"}
And 					<Botao palavra='fix'
						destino='Exercicio'
						imagem='fix'
						palavrasCorretas={['concertar']}
						contexto=''
						voltar={'Pop5'}/> what I've broken{"\n"}
Oh, 'cause I need you to see{"\n"}
That you are the reason{"\n"}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Pop5;