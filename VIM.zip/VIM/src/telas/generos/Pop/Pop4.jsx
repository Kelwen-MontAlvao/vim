import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../../componentes/Cabecalho';
import { Botao } from '../../../componentes/Botao'
import { BotaoVoltar } from '../../../componentes/Voltar';

export function Pop4() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'CevxZvSJLk8'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='Genero2'/>
        <Text style={estilos.titulo}>
          Katy Perry - Roar
        </Text>

        <Text style={estilos.letraMusica}>  
          I used to bite my <Botao palavra='tongue'
                                   destino='Exercicio' 
                                   imagem='tongue' 
                                   palavrasCorretas={['língua', 'lingua']}  
                                   contexto='  '
                                   voltar={'Pop4'}/> and hold my <Botao palavra='breath'
                                                                                  destino='Exercicio' 
                                                                                  imagem='breath' 
                                                                                  palavrasCorretas={['respiração', 'respiração']}  
                                                                                  contexto='  '
                                                                                  voltar={'Pop4'}/> {'\n'}

          Scared to rock the boat and make a mess{'\n'}
          So I sat <Botao palavra='quietly'
                          destino='Exercicio' 
                          imagem='quietly' 
                          palavrasCorretas={['silenciosamente', 'quietamente']}  
                          contexto=' '
                          voltar={'Pop4'}/>, agreed <Botao palavra='politely'
                                                                     destino='Exercicio' 
                                                                     imagem='politely' 
                                                                     palavrasCorretas={['educadamente', 'educado']}  
                                                                     contexto='  '
                                                                     voltar={'Pop4'}/>{'\n'}

          I guess that I forgot I had a choice{'\n'}
          I let you <Botao palavra='push'
                           destino='Exercicio' 
                           imagem='push' 
                           palavrasCorretas={['empurrar']}  
                           contexto='  '
                           voltar={'Pop4'}/> me past the breaking point{'\n'}
          I stood for nothing, so I fell for everything{'\n'}{'\n'}

          You held me down, but I got up (hey){'\n'}
          Already brushing off the <Botao palavra='dust'
                                          destino='Exercicio' 
                                          imagem='dust' 
                                          palavrasCorretas={['pó', 'poeira']}  
                                          contexto='  '
                                          voltar={'Pop4'}/>{'\n'}

          You hear my <Botao palavra='voice'
                             destino='Exercicio' 
                             imagem='voice' 
                             palavrasCorretas={['voz']}  
                             contexto=' '
                             voltar={'Pop4'}/>, you hear that sound{'\n'}

          Like <Botao palavra='thunder'
                      destino='Exercicio' 
                      imagem='thunder' 
                      palavrasCorretas={['trovão']}  
                      contexto='  '
                      voltar={'Pop4'}/>, gonna shake the ground{'\n'}

          You held me down, but I got up (hey){'\n'}
          Get ready 'cause I've had <Botao palavra='enough'
                                           destino='Exercicio' 
                                           imagem='enough' 
                                           palavrasCorretas={['suficiente']}  
                                           contexto='  '
                                           voltar={'Pop4'}/>{'\n'}

          I see it all, I see it now{'\n'}{'\n'}

          I got the eye of the <Botao palavra='tiger'
                                      destino='Exercicio' 
                                      imagem='tiger' 
                                      palavrasCorretas={['tigre']}  
                                      contexto='  '
                                      voltar={'Pop4'}/>, a <Botao palavra='fighter'
                                                                            destino='Exercicio' 
                                                                            imagem='fighter' 
                                                                            palavrasCorretas={['lutador']}  
                                                                            contexto='  '
                                                                            voltar={'Pop4'}/>{'\n'}
          Dancing through the fire{'\n'}
          'Cause I am a champion, and you're gonna hear me <Botao palavra='roar'
                                                                  destino='Exercicio' 
                                                                  imagem='roar' 
                                                                  palavrasCorretas={['rugir', 'rugida']}  
                                                                  contexto='  '
                                                                  voltar={'Pop4'}/>{'\n'}
          Louder, louder than a <Botao palavra='lion'
                                       destino='Exercicio' 
                                       imagem='lion' 
                                       palavrasCorretas={['leão']}  
                                       contexto='  '
                                       voltar={'Pop4'}/>{'\n'}
          'Cause I am a champion, and you're gonna hear me <Botao palavra='roar'
                                                                  destino='Exercicio' 
                                                                  imagem='roar' 
                                                                  palavrasCorretas={['rugir', 'rugida']}  
                                                                  contexto=' '
                                                                  voltar={'Pop4'}/>{'\n'}{'\n'}

          Oh-oh-oh-oh-oh{'\n'}
          Oh-oh-oh-oh-oh{'\n'}
          Oh-oh-oh-oh-oh{'\n'}
          You're gonna hear me <Botao palavra='roar'
                                      destino='Exercicio' 
                                      imagem='roar' 
                                      palavrasCorretas={['rugir', 'rugida']}  
                                      contexto='  '
                                      voltar={'Pop4'}/>{'\n'}{'\n'}

          Now I'm floatin' like a <Botao palavra='butterfly'
                                         destino='Exercicio' 
                                         imagem='butterfly' 
                                         palavrasCorretas={['borboleta']}  
                                         contexto='  '
                                         voltar={'Pop4'}/>{'\n'}

          Stinging like a <Botao palavra='bee'
                                 destino='Exercicio' 
                                 imagem='bee' 
                                 palavrasCorretas={['abelha']}  
                                 contexto='  '
                                 voltar={'Pop4'}/>, I earned my stripes{'\n'}

          I went from zero, to my own hero{'\n'}
          You held me down, but I got up (hey){'\n'}
          Already brushing off the <Botao palavra='dust'
                                          destino='Exercicio' 
                                          imagem='dust' 
                                          palavrasCorretas={['pó', 'poeira']}  
                                          contexto='  '
                                          voltar={'Pop4'}/>{'\n'}

          You hear my <Botao palavra='voice'
                             destino='Exercicio' 
                             imagem='voice' 
                             palavrasCorretas={['voz']}  
                             contexto='  '
                             voltar={'Pop4'}/>, you hear that sound{'\n'}

          Like <Botao palavra='thunder'
                      destino='Exercicio' 
                      imagem='thunder' 
                      palavrasCorretas={['trovão']}  
                      contexto='  '
                      voltar={'Pop4'}/>, gonna shake the ground{'\n'}

          You held me down, but I got up (hey){'\n'}
          Get ready 'cause I've had <Botao palavra='enough'
                                           destino='Exercicio' 
                                           imagem='enough' 
                                           palavrasCorretas={['suficiente']}  
                                           contexto='  '
                                           voltar={'Pop4'}/>{'\n'}
          I see it all, I see it now{'\n'}{'\n'}

          I got the eye of the <Botao palavra='tiger'
                                      destino='Exercicio' 
                                      imagem='tiger' 
                                      palavrasCorretas={['Tigre']}  
                                      contexto='  '
                                      voltar={'Pop4'}/>, a <Botao palavra='fighter'
                                                                            destino='Exercicio' 
                                                                            imagem='fighter' 
                                                                            palavrasCorretas={['lutador']}  
                                                                            contexto='  '
                                                                            voltar={'Pop4'}/>{'\n'}
          Dancing through the fire{'\n'}
          'Cause I am a champion, and you're gonna hear me <Botao palavra='roar'
                                                                  destino='Exercicio' 
                                                                  imagem='roar' 
                                                                  palavrasCorretas={['rugir', 'rugida']}  
                                                                  contexto=' '
                                                                  voltar={'Pop4'}/>{'\n'}
          Louder, louder than a <Botao palavra='lion'
                                       destino='Exercicio' 
                                       imagem='lion' 
                                       palavrasCorretas={['leão']}  
                                       contexto=' '
                                       voltar={'Pop4'}/>{'\n'}

          'Cause I am a champion, and you're gonna hear me <Botao palavra='roar'
                                                                  destino='Exercicio' 
                                                                  imagem='roar' 
                                                                  palavrasCorretas={['rugir', 'rugida']}  
                                                                  contexto=' '
                                                                  voltar={'Pop4'}/>{'\n'}{'\n'}

          Oh-oh-oh-oh-oh{'\n'}
          Oh-oh-oh-oh-oh{'\n'}
          Oh-oh-oh-oh-oh{'\n'}
          You're gonna hear me <Botao palavra='roar'
                                      destino='Exercicio' 
                                      imagem='roar' 
                                      palavrasCorretas={['rugir', 'rugida']}  
                                      contexto='  '
                                      voltar={'Pop4'}/>{'\n'}{'\n'}

          Oh-oh-oh-oh-oh{'\n'}
          Oh-oh-oh-oh-oh (you'll hear me <Botao palavra='roar'
                                                destino='Exercicio' 
                                                imagem='roar' 
                                                palavrasCorretas={['rugir', 'rugida']}  
                                                contexto='  '
                                                voltar={'Pop4'}/>){'\n'}
          Oh-oh-oh-oh-oh{'\n'}
          You're gonna hear me <Botao palavra='roar'
                                      destino='Exercicio' 
                                      imagem='roar' 
                                      palavrasCorretas={['rugir', 'rugida']}  
                                      contexto=' . '
                                      voltar={'Pop4'}/>{'\n'}{'\n'}

          Roar, roar, roar, roar, roar{'\n'}
          I got the eye of the <Botao palavra='tiger'
                                      destino='Exercicio' 
                                      imagem='tiger' 
                                      palavrasCorretas={['Tigre']}  
                                      contexto='  '
                                      voltar={'Pop4'}/>, a <Botao palavra='fighter'
                                                                            destino='Exercicio' 
                                                                            imagem='fighter' 
                                                                            palavrasCorretas={['lutador']}  
                                                                            contexto='  '
                                                                            voltar={'Pop4'}/>{'\n'}
          Dancing through the fire{'\n'}
          'Cause I am a champion, and you're gonna hear me <Botao palavra='roar'
                                                                  destino='Exercicio' 
                                                                  imagem='roar' 
                                                                  palavrasCorretas={['rugir', 'rugida']}  
                                                                  contexto='  '
                                                                  voltar={'Pop4'}/>{'\n'}
          Louder, louder than a <Botao palavra='lion'
                                       destino='Exercicio' 
                                       imagem='lion' 
                                       palavrasCorretas={['leão']}  
                                       contexto='  '
                                       voltar={'Pop4'}/>{'\n'}

          'Cause I am a champion, and you're gonna hear me <Botao palavra='roar'
                                                                  destino='Exercicio' 
                                                                  imagem='roar' 
                                                                  palavrasCorretas={['rugir', 'rugida']}  
                                                                  contexto='  '
                                                                  voltar={'Pop4'}/>{'\n'}{'\n'}

          Oh-oh-oh-oh-oh{'\n'}
          Oh-oh-oh-oh-oh (yeah){'\n'}
          Oh-oh-oh-oh-oh{'\n'}
          You're gonna hear me <Botao palavra='roar'
                                      destino='Exercicio' 
                                      imagem='roar' 
                                      palavrasCorretas={['rugir', 'rugida']}  
                                      contexto='  '
                                      voltar={'Pop4'}/>{'\n'}{'\n'}

          Oh-oh-oh-oh-oh{'\n'}
          Oh-oh-oh-oh-oh (you'll hear me <Botao palavra='roar'
                                                destino='Exercicio' 
                                                imagem='roar' 
                                                palavrasCorretas={['rugir', 'rugida']}  
                                                contexto='  '
                                                voltar={'Pop4'}/>){'\n'}
          Oh-oh-oh-oh-oh{'\n'}
          You're gonna hear me <Botao palavra='roar'
                                      destino='Exercicio' 
                                      imagem='roar' 
                                      palavrasCorretas={['rugir', 'rugida']}  
                                      contexto='  '
                                      voltar={'Pop4'}/>{'\n'}{'\n'}


        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Pop4;