import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Alert, Image, TextInput, TouchableOpacity, ScrollView, Linking } from 'react-native';
import { Cabecalho } from '../componentes/Cabecalho';
import { BotaoVoltar } from '../componentes/Voltar';
import { searchPhotos } from '../pexelsAPI';

export function Exercicio({ route }) {
  const { palavraInterativa, imagem, palavrasCorretas, contexto, voltar, significado } = route.params;

  //-- começo pexels api
  const [photo, setPhoto] = useState(null);

  useEffect(() => {
    const fetchPhoto = async () => {
      const result = await searchPhotos(imagem);
      if (result.length > 0) {
        setPhoto(result[1]); // Pega a primeira imagem dos resultados
      }
    };

    fetchPhoto();
  }, [imagem]);
  //-- fim pexels api

  // Estado para o valor do input
  const [resposta, setResposta] = useState('');

  // Estado para controlar se o significado está visível
  const [mostrarSignificado, setMostrarSignificado] = useState(false);

  // Função para verificar a resposta
  const verificarResposta = () => {
    const respostaLower = resposta.toLowerCase();
    const palavrasCorretasLower = palavrasCorretas.map(palavra => palavra.toLowerCase());

    if (palavrasCorretasLower.includes(respostaLower)) {
      Alert.alert('Correto!', 'Você acertou a palavra!');
    } else {
      Alert.alert('Incorreto', 'Tente novamente.');
    }
    setResposta(''); // Limpar o input após verificar
  };

  return (
    <>
      <Cabecalho />
      <ScrollView contentContainerStyle={estilos.scrollContainer}>
        <View style={estilos.container}>
          <View style={estilos.container2}>
            <BotaoVoltar destino={voltar} />
            <Text style={estilos.titulo}>Qual o significado de "{palavraInterativa}"?</Text>

            <View>
              {photo ? (
                <View style={estilos.photoContainer}>
                  <Image source={{ uri: photo.src.large }} style={estilos.photo} />
                  <TouchableOpacity onPress={() => Linking.openURL(photo.photographer_url)}>
                    <Text style={estilos.credito}>Foto por {photo.photographer} no Pexels</Text>
                  </TouchableOpacity>
                </View>
              ) : (
                <Text>Carregando...</Text>
              )}
            </View>

            <Text style={estilos.contexto}>{contexto}</Text>

            <TextInput
              style={estilos.input}
              placeholder="Digite a palavra"
              value={resposta}
              onChangeText={setResposta}
            />

            <TouchableOpacity style={estilos.containerbotao} onPress={verificarResposta}>
              <Text style={estilos.textoBotao}>Enviar</Text>
            </TouchableOpacity>

            {/* Botão para mostrar o significado */}
            <TouchableOpacity
              style={[estilos.containerbotao, { backgroundColor: '#4CAF50' }]}
              onPress={() => setMostrarSignificado(!mostrarSignificado)}
            >
              <Text style={estilos.textoBotao}>{mostrarSignificado ? 'Ocultar' : 'Mostrar'} Significado</Text>
            </TouchableOpacity>

            {/* Texto do significado, que só aparece se mostrarSignificado for true */}
            {mostrarSignificado && (
              <Text style={estilos.significado}>{palavrasCorretas.join(', ')}</Text>
            )}
          </View>
        </View>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#1a1a1a', 
    paddingVertical: 20,
  },
  container2: {
    backgroundColor: '#333',
    alignItems: 'center',
    width: 400,
    borderRadius: 15, 
    padding: 20, 
  },
  titulo: {
    fontSize: 30,
    marginVertical: 5,
    textAlign: 'center',
    color: '#fff', 
  },
  photoContainer: {
    alignItems: 'center',
    marginVertical: 10,
  },
  photo: {
    width: 300,
    height: 250,
    borderRadius: 10,
  },
  credito: {
    marginTop: 5,
    fontSize: 14,
    color: '#4CAF50', 
    textDecorationLine: 'underline', 
  },
  contexto: {
    marginHorizontal: 20,
    textAlign: 'justify',
    fontSize: 16,
    marginBottom: 20,
    color: '#ddd', 
  },
  input: {
    width: 200,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    paddingHorizontal: 10,
    borderRadius: 10,
    textAlign: 'center',
    backgroundColor: '#fff', 
    color: '#000', 
    marginBottom: 5,
  },
  containerbotao: {
    backgroundColor: '#2d7de6',
    width: 200,
    height: 50,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  textoBotao: {
    color: '#fff',
    fontSize: 20,
  },
  significado: {
    marginTop: 20,
    fontSize: 18,
    color: '#fff', 
    textAlign: 'center',
    backgroundColor: '#4CAF50',
    padding: 15,
    borderRadius: 10,
  },
});
