import React from 'react';
import { StyleSheet, View, ImageBackground, Text, ScrollView, TouchableOpacity } from 'react-native';
import { Cartao } from '../componentes/Cartao';
import { CardMusica } from '../componentes/CardMusica';
import { CardMusicaSaves } from '../componentes/CardMusicaSaves';
import { Cabecalho } from '../componentes/Cabecalho';
import { useMusic } from '../MusicContext';
import { useNavigation } from '@react-navigation/native';

export function Home() {
  const { savedMusics } = useMusic();
  const navigation = useNavigation();

  return (
    <>
      <Cabecalho />
      <ScrollView style={estilos.conteiner} vertical={true}>
        <ImageBackground style={estilos.fundo} source={require('../../assets/fundo.jpg')} opacity={0.5}>
          <TouchableOpacity 
            style={estilos.botaoEstudos}
            onPress={() => navigation.navigate('Estudos')} 
          >
            <Text style={estilos.textoBotao}>Ir para Estudos</Text>
          </TouchableOpacity>

          <Text style={estilos.subtitulos}>Gênero Musical</Text>

          <ScrollView
            horizontal
            style={estilos.ConteinerCards}
            showsHorizontalScrollIndicator={false}
          >
            <View style={estilos.cardsContainer}>
              <Cartao
                titulo="Rock"
                imagem={require('../imgs/rock.jpg')}
                destino="Genero1"
              />
              <Cartao
                titulo="Pop"
                imagem={require('../imgs/pop.jpg')}
                destino="Genero2"
              />
              <Cartao
                titulo="Rap"
                imagem={require('../imgs/rap.jpg')}
                destino="Genero3"
              />
              <Cartao
                titulo="Indie"
                imagem={require('../imgs/indie.jpg')}
                destino="Genero4"
              />
              <Cartao
                titulo="Blues"
                imagem={require('../imgs/blues.jpg')}
                destino="Genero5"
              />
            </View>
          </ScrollView>

          <Text style={estilos.subtitulos}>Recomendações</Text>

          <View style={estilos.conteinerMus}>
            <CardMusica
              titulo="Radio Ga Ga"
              titulo2="Queen"
              imagem={require('../../assets/Radiogaga.jpg')}
              destino="Musica"
            />
            <CardMusica
              titulo="Viva La Vida"
              titulo2="Coldplay"
              imagem={require('../../assets/VivaLaVida.jpg')}
              destino="Musica2"
            />
            <CardMusica
              titulo="Carry Wayward Son"
              titulo2="Kansas"
              imagem={require('../../assets/Carry.jpg')}
              destino="Musica3"
            />
            <CardMusica
              titulo="Rolling in the Deep"
              titulo2="Adele"
              imagem={require('../../assets/Adele.jpg')}
              destino="Musica4"
            />
          </View>

          {savedMusics.length > 0 && (
            <>
              <Text style={estilos.subtitulos}>Músicas Salvas</Text>

              <View style={estilos.conteinerMus}>
                {savedMusics.map((musica, index) => (
                  <CardMusicaSaves
                    key={index}
                    titulo={musica.nome}
                    titulo2={musica.artista}
                    imagem={musica.imagem}
                    destino={musica.destino}
                  />
                ))}
                
              </View>
            </>
          )}
          <TouchableOpacity 
                style={estilos.botaoSugestao}
                  onPress={() => navigation.navigate('Sugestao')} 
              >
                  <Text style={estilos.textoBotao}>Sugira-nos novas músicas</Text>
              </TouchableOpacity>
        </ImageBackground>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteiner: {
    flex: 1,
    backgroundColor: '#000',
  },
  subtitulos: {
    color: 'rgba(255, 255, 255, 0.8)',
    paddingLeft: 15,
    paddingVertical: 10,
    marginTop: 10,
    fontSize: 17,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  fundo: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  ConteinerCards: {
    paddingVertical: 20,
  },
  cardsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 15,
  },
  conteinerMus: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingBottom: 100,
  },
  botaoEstudos: {
    backgroundColor: '#2d7de6',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 25,
    margin: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  botaoSugestao: {
    backgroundColor: '#e05a2f',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 25,
    marginHorizontal: 15,
    marginTop: 15,
    marginBottom: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textoBotao: {
    color: '#fff',
    fontSize: 18,
  },
});
