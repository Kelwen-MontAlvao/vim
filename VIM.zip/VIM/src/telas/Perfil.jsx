import {StyleSheet, View, Image, ImageBackground, Text, TouchableOpacity} from 'react-native'
import {Cabecalho} from '../componentes/Cabecalho'
import {Link} from '../componentes/Links'
import {useNavigation} from '@react-navigation/native'

export function Perfil(){

  const navegacao = useNavigation()

    const navegar = rota => {
        navegacao.navigate(rota)
    }

    return(
        <>
        <Cabecalho />
        <View style={estilos.conteiner}>
            <View style={estilos.conteinerPerfil}>
            <Image
              source={require('../../assets/fundoperfil3.jpg')} // Caminho da imagem local
              style={estilos.fundoperfil}
              resizeMode="contain" // Ajusta a forma como a imagem preenche o fundo
            />

            </View>

            <Image source={require('../../assets/profile4.jpg')} style={estilos.perfil}/>
                <Text style={estilos.texto}> Perfil </Text>
            

            <View style={estilos.conteinerLinks}> 

              <Link titulo="Configurações" destino="Configuracoes" /> 
              <Link titulo="Sobre o app" destino="sobre" /> 

              <TouchableOpacity style={estilos.link} onPress={() => navegar('Login')}>
                <Text style={estilos.textoLink} >Sair</Text> 
              </TouchableOpacity>

            </View>
        </View>
        </>
    )
}

const estilos = StyleSheet.create({
      conteiner: {
        flex: 1,
        backgroundColor: '#000',
        alignItems: "center",
      },

      conteinerPerfil: {
        backgroundColor: "#2d7de6",
        width: '100%',
        height: 180,
        alignItems: 'center',
      },

      conteinerLinks: {
        backgroundColor: "#000",
        width: 520,
        height: 520,
        alignItems: 'center',
        borderRadius: 20,
        marginTop: 40,
      },

      fundoperfil: {
        flex: 1,
        justifyContent: 'center', 
        alignItems: 'center',
        borderStyle: 'solid',
        borderWidth: 5,
      },
      
      perfil: {
        height: 150,
        width: 150,
        borderRadius: 100,
        marginTop: -100,
        borderStyle: 'solid',
        borderWidth: 5,
        borderColor: 'black'
      },
    
      texto: {
        color: "#fff",
        fontSize: 18,
        maxWidth: 300,
        padding: 10,
        textAlign: "center"
      },

      fundo: {
        width: '100%',
        height: '100%',
        resizeMode: 'cover'
    },

    textoLink: {
      color: "#e15244",
      fontSize: 26,
      padding: 10,
      textAlign: "center"
    }
})