import React, { useState, useCallback } from 'react';
import { View, Text, ScrollView, StyleSheet, Dimensions, Alert, Button } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../../componentes/Cabecalho';

export function Videoaulas({ navigation }) { 
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('O vídeo acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const videos = [
    { id: 'FJ0zBvKObG0', title: 'Videoaula 1: Introdução ao Inglês' },
    { id: 'XVUA2dhP4tY', title: 'Videoaula 2: Vocabulário Básico' },
    { id: 'PJT6vROO3eM', title: 'Videoaula 3: Frases Comuns' },
  ];

  return (
    <>
      <Cabecalho />

      <ScrollView style={estilos.scrollContent}>

        {videos.map((video, index) => (
          <View key={index} style={estilos.videoContainer}>
            <YoutubePlayer
              height={heightVideo}
              play={playing}
              videoId={video.id}
              onChangeState={onStateChange}
            />
            <Text style={estilos.videoTitle}>{video.title}</Text>
          </View>
        ))}
        <View style={estilos.buttonContainer}>
          <Button 
            title="Ir para Estudos" 
            onPress={() => navigation.navigate('Estudos')} 
            color="#2d7de6"
          />
        </View>
      </ScrollView>
    </>
  );
}

const { width } = Dimensions.get('window');
const heightVideo = width * (9 / 16); // Proporção 16:9

const estilos = StyleSheet.create({
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
  },
  videoContainer: {
    marginBottom: 20,
    width: '100%',
  },
  videoTitle: {
    color: '#fff',
    marginTop: 10,
    textAlign: 'center',
  },
  buttonContainer: {
    marginVertical: 20,
    alignItems: 'center',
  },
});

export default Videoaulas;
