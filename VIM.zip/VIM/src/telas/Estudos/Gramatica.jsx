import React from 'react';
import { View, Text, ScrollView, StyleSheet, Button } from 'react-native';
import { Cabecalho } from '../../componentes/Cabecalho';
import { Post } from '../../componentes/PostGramatica';
import { useNavigation } from '@react-navigation/native';

export function Gramatica() {
  const navigation = useNavigation();

  return (
    <>
      <Cabecalho />

      <View style={estilos.conteinerTitulo}>
        <Text style={estilos.titulo}>Gramatica:</Text>
      </View>

      <ScrollView style={estilos.scrollContent}>
        <Post
          titulo="Fundamentos da Gramática"
          conteudo={`Partes do Discurso: Substantivos, verbos, adjetivos, advérbios, preposições, conjunções e interjeições.\n 
Estrutura da Frase: Ordem básica da frase (Sujeito + Verbo + Objeto).\n 
Artigos e Determinantes: Uso dos artigos definidos e indefinidos (a, an, the) e outros determinantes.
          \n\nExemplo: "The cat (substantivo) sat (verbo) on the mat (objeto)."`}
        />
        <Post
          titulo="Tempos Verbais Básicos"
          conteudo={`Presente Simples: Formação e uso para ações habituais.\n 
Passado Simples: Formação e uso para ações concluídas no passado.\n
Futuro Simples: Formação e uso para ações futuras.
          \n\nExemplo: 
          - Presente Simples: "She walks to school every day."
          - Passado Simples: "He visited his friend yesterday."
          - Futuro Simples: "They will travel next month."`}
        />
        <Post
          titulo="Tempos Verbais Avançados"
          conteudo={`Presente Contínuo: Formação e uso para ações que estão ocorrendo no momento da fala.\n
Passado Contínuo: Formação e uso para ações que estavam ocorrendo em um momento específico no passado. \n
Futuro Contínuo: Formação e uso para ações que estarão ocorrendo em um momento específico no futuro.
          \n\nExemplo: 
          - Presente Contínuo: "I am reading a book."
          - Passado Contínuo: "She was watching TV when I called her."
          - Futuro Contínuo: "They will be studying at 8 PM."`}
        />
        <Post
          titulo="Aspectos e Vozes"
          conteudo={`Presente Perfeito: Formação e uso para ações que têm relevância no presente. \n
Passado Perfeito: Formação e uso para ações que foram completadas antes de outra ação no passado. \n
Voz Ativa e Voz Passiva: Formação e uso de frases na voz ativa e passiva.
          \n\nExemplo: 
          - Presente Perfeito: "I have finished my homework."
          - Passado Perfeito: "She had left before he arrived."
          - Voz Ativa: "The chef cooked the meal."
          - Voz Passiva: "The meal was cooked by the chef."`}
        />
        <Post
          titulo="Modificadores e Complementos"
          conteudo={`Adjetivos e Advérbios: Formação e uso para modificar substantivos e verbos.\n
Comparativos e Superlativos: Formação e uso para comparar coisas e descrever o grau máximo. \n
Preposições: Uso de preposições para indicar tempo, lugar e outras relações.
          \n\nExemplo: 
          - Adjetivos: "The tall building."
          - Advérbios: "She sings beautifully."
          - Comparativos: "This book is better than that one."
          - Superlativos: "This is the best movie I've ever seen."
          - Preposições: "She arrived at noon."`}
        />
        <Post
          titulo="Frases e Sentenças Complexas"
          conteudo={`Frases Subordinadas: Formação e uso de frases dependentes (causais, condicionais, relativas). \n
Conjunções: Uso de conjunções para conectar frases e orações. \n
Cláusulas Relativas: Uso de cláusulas que fornecem mais informações sobre um substantivo.
          \n\nExemplo: 
          - Frases Subordinadas: "If it rains, we will cancel the picnic."
          - Conjunções: "I want tea and coffee."
          - Cláusulas Relativas: "The book that you gave me is interesting."`}
        />
      </ScrollView>

      <View style={estilos.buttonContainer}>
        <Button
          title="Voltar para Estudos"
          onPress={() => navigation.navigate('Estudos')}
        />
      </View>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center",
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
  },
  buttonContainer: {
    padding: 20,
    backgroundColor: '#000',
  },
});
