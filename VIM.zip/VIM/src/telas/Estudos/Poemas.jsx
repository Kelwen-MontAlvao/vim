import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native'; 
import { Cabecalho } from '../../componentes/Cabecalho';

export function Poemas() {
  const navigation = useNavigation(); 

  // Estado para controlar a tradução visível para cada poema
  const [mostrandoTraducao, setMostrandoTraducao] = useState({
    poema1: false,
    poema2: false,
    poema3: false,
    poema4: false,
    poema5: false,
  });

  // Função para alternar entre original e tradução
  const alternarTraducao = (poema) => {
    setMostrandoTraducao((prevState) => ({
      ...prevState,
      [poema]: !prevState[poema],
    }));
  };

  return (
    <>
      <Cabecalho />

      <View style={estilos.conteinerTitulo}>
        <Text style={estilos.titulo}>Poemas:</Text>
      </View>

      <ScrollView 
        style={estilos.scrollContent}
        vertical={true}
      >
        {/* Poema 1 - Maya Angelou */}
        <View style={estilos.poemaCard}>
          <Text style={estilos.poemaTitulo}>Still I Rise - Maya Angelou</Text>
          <Text style={estilos.poemaTexto}>
            {!mostrandoTraducao.poema1 ? (
              `You may shoot me with your words,\nYou may cut me with your eyes,\nYou may kill me with your hatefulness,\nBut still, like air, I’ll rise.`
            ) : (
              `Você pode me atacar com suas palavras,\nVocê pode me cortar com seus olhos,\nVocê pode me matar com seu ódio,\nMas ainda assim, como o ar, eu me levantarei.`
            )}
          </Text>
          <TouchableOpacity onPress={() => alternarTraducao('poema1')} style={estilos.botaoTraduzir}>
            <Text style={estilos.botaoTraduzirTexto}>
              {mostrandoTraducao.poema1 ? 'Ver Original' : 'Ver Tradução'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Poema 2 - Dylan Thomas */}
        <View style={estilos.poemaCard}>
          <Text style={estilos.poemaTitulo}>Do Not Go Gentle into That Good Night — Dylan Thomas</Text>
          <Text style={estilos.poemaTexto}>
            {!mostrandoTraducao.poema2 ? (
              `Do not go gentle into that good night,\nOld age should burn and rave at close of day;\nRage, rage against the dying of the light.`
            ) : (
              `Não entre gentilmente nessa boa noite,\nA velhice deveria arder e delirar ao fim do dia;\nRevolte-se, revolte-se contra o fim da luz.`
            )}
          </Text>
          <TouchableOpacity onPress={() => alternarTraducao('poema2')} style={estilos.botaoTraduzir}>
            <Text style={estilos.botaoTraduzirTexto}>
              {mostrandoTraducao.poema2 ? 'Ver Original' : 'Ver Tradução'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Poema 3 - If this street was mine */}
        <View style={estilos.poemaCard}>
          <Text style={estilos.poemaTitulo}>If this street was mine</Text>
          <Text style={estilos.poemaTexto}>
            {!mostrandoTraducao.poema3 ? (
              `If this street, if this street was mine\nI would bid, I would bid someone to tile it\nWith pebbles, with pebbles made of diamond\nOnly for my, only for my love to walk by.`
            ) : (
              `Se esta rua, se esta rua fosse minha,\nEu mandaria, eu mandaria ladrilhar,\nCom pedrinhas, com pedrinhas de brilhante,\nSomente para o meu, para o meu amor passar.`
            )}
          </Text>
          <TouchableOpacity onPress={() => alternarTraducao('poema3')} style={estilos.botaoTraduzir}>
            <Text style={estilos.botaoTraduzirTexto}>
              {mostrandoTraducao.poema3 ? 'Ver Original' : 'Ver Tradução'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Poema 4 - Pablo Neruda */}
        <View style={estilos.poemaCard}>
          <Text style={estilos.poemaTitulo}>XVII - Pablo Neruda</Text>
          <Text style={estilos.poemaTexto}>
            {!mostrandoTraducao.poema4 ? (
              `I do not love you as if you were salt-rose, or topaz,\nor the arrow of carnations the fire shoots off.\nI love you as certain dark things are to be loved,\nin secret, between the shadow and the soul.`
            ) : (
              `Eu não te amo como se fosses rosa de sal, topázio,\nou flecha de cravos que propagam o fogo:\neu te amo como certas coisas obscuras são amadas,\nem segredo, entre a sombra e a alma.`
            )}
          </Text>
          <TouchableOpacity onPress={() => alternarTraducao('poema4')} style={estilos.botaoTraduzir}>
            <Text style={estilos.botaoTraduzirTexto}>
              {mostrandoTraducao.poema4 ? 'Ver Original' : 'Ver Tradução'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Poema 5 - Shakespeare */}
        <View style={estilos.poemaCard}>
          <Text style={estilos.poemaTitulo}>William Shakespeare</Text>
          <Text style={estilos.poemaTexto}>
            {!mostrandoTraducao.poema5 ? (
              `But, soft! what light through yonder window breaks?\nIt is the east, and Juliet is the sun.\nHer vestal livery is but sick and green\nAnd none but fools do wear it; cast it off.`
            ) : (
              `Mas, suavemente! que luz brilha através daquela janela?\nÉ o leste, e Julieta é o sol.\nSeu traje virginal está doente e verde\nE só os tolos o vestem; tire-o.`
            )}
          </Text>
          <TouchableOpacity onPress={() => alternarTraducao('poema5')} style={estilos.botaoTraduzir}>
            <Text style={estilos.botaoTraduzirTexto}>
              {mostrandoTraducao.poema5 ? 'Ver Original' : 'Ver Tradução'}
            </Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={estilos.voltarButton} onPress={() => navigation.navigate('Estudos')}>
          <Text style={estilos.voltarButtonText}>Voltar para Estudos</Text>
        </TouchableOpacity>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
    paddingVertical: 15,
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    textAlign: "center",
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  poemaCard: {
    backgroundColor: '#333',
    borderRadius: 10,
    padding: 15,
    marginVertical: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 5,
  },
  poemaTitulo: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  poemaTexto: {
    color: '#fff',
    fontSize: 16,
    lineHeight: 24,
  },
  botaoTraduzir: {
    backgroundColor: '#2d7de6',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 5,
    marginTop: 10,
    alignItems: 'center',
  },
  botaoTraduzirTexto: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  voltarButton: {
    backgroundColor: '#2d7de6',
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 15,
    alignItems: 'center',
    marginVertical: 20,
  },
  voltarButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default Poemas;
