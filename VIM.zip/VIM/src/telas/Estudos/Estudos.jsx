import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, ImageBackground } from 'react-native';
import { Cabecalho } from '../../componentes/Cabecalho';
import { useNavigation } from '@react-navigation/native';

export function Estudos() {
  const navigation = useNavigation();

  return (
    <>
      <Cabecalho />

      <ImageBackground
        style={estilos.fundo}
        source={require('../../../assets/fundo.jpg')}
        opacity={0.5}
      >
        <View style={estilos.conteinerTitulo}>
          <Text style={estilos.titulo}>Estudos:</Text>
        </View>

        <ScrollView style={estilos.scrollContent} vertical={true}>
          <TouchableOpacity
            style={estilos.botao}
            onPress={() => navigation.navigate('Gramatica')}
          >
            <Text style={estilos.textoBotao}>Revisão gramática</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={estilos.botao}
            onPress={() => navigation.navigate('LetrasVagalume')}
          >
            <Text style={estilos.textoBotao}>Letras Vagalume</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={estilos.botao}
            onPress={() => navigation.navigate('Poemas')}
          >
            <Text style={estilos.textoBotao}>Poemas para estudos</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={estilos.botao}
            onPress={() => navigation.navigate('MeusPoemas')}
          >
            <Text style={estilos.textoBotao}>Meus Poemas</Text>
          </TouchableOpacity>

          <View style={estilos.centralizado}>
            <Text style={estilos.textoClasses}>------ Classes ------</Text>
          </View>

          <TouchableOpacity
            style={estilos.botao}
            onPress={() => navigation.navigate('Videoaulas')}
          >
            <Text style={estilos.textoBotao}>Videoaulas</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={estilos.botao}
            onPress={() => navigation.navigate('Exercicios')}
          >
            <Text style={estilos.textoBotao}>Exercícios</Text>
          </TouchableOpacity>
        </ScrollView>
      </ImageBackground>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center",
  },
  fundo: {
    flex: 1,
    resizeMode: 'cover',
    width: '100%',
    height: '100%',
  },
  scrollContent: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
  },
  botao: {
    backgroundColor: '#295c9e',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 20,
    margin: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textoBotao: {
    color: '#fff',
    fontSize: 18,
  },
  centralizado: {
    alignItems: 'center',
    marginVertical: 15,
  },
  textoClasses: {
    color: '#fff',
    fontSize: 23,
    textAlign: 'center',
    padding: 4,
  },
});

export default Estudos;

