import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, TextInput, Button, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native'; 
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Cabecalho } from '../../componentes/Cabecalho';

export function MeusPoemas() {
  const navigation = useNavigation(); 
  const [poemas, setPoemas] = useState([]);
  const [novoPoema, setNovoPoema] = useState('');

  useEffect(() => {
    carregarPoemas();
  }, []);

  const carregarPoemas = async () => {
    try {
      const poemasSalvos = await AsyncStorage.getItem('poemas');
      if (poemasSalvos) {
        setPoemas(JSON.parse(poemasSalvos));
      }
    } catch (error) {
      console.error('Erro ao carregar poemas:', error);
    }
  };

  const salvarPoema = async () => {
    if (!novoPoema.trim()) {
      Alert.alert('O poema não pode estar vazio!');
      return;
    }
    try {
      const novosPoemas = [...poemas, novoPoema];
      await AsyncStorage.setItem('poemas', JSON.stringify(novosPoemas));
      setPoemas(novosPoemas);
      setNovoPoema('');
      Alert.alert('Poema salvo com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar poema:', error);
    }
  };

  const excluirPoema = async (index) => {
    try {
      const novosPoemas = poemas.filter((_, i) => i !== index);
      await AsyncStorage.setItem('poemas', JSON.stringify(novosPoemas));
      setPoemas(novosPoemas);
      Alert.alert('Poema excluído com sucesso!');
    } catch (error) {
      console.error('Erro ao excluir poema:', error);
    }
  };

  return (
    <>
      <Cabecalho />

      <View style={estilos.conteinerTitulo}>
        <Text style={estilos.titulo}>Poemas:</Text>
      </View>

      <ScrollView style={estilos.scrollContent} vertical={true}>
        {poemas.map((poema, index) => (
          <View key={index} style={estilos.poemaCard}>
            <Text style={estilos.poemaTexto}>{poema}</Text>
            <TouchableOpacity
              style={estilos.excluirButton}
              onPress={() => excluirPoema(index)}
            >
              <Text style={estilos.excluirButtonText}>Excluir Poema</Text>
            </TouchableOpacity>
          </View>
        ))}

        <View style={estilos.poemaCard}>
          <TextInput
            style={estilos.input}
            multiline
            placeholder="Escreva um novo poema aqui..."
            value={novoPoema}
            onChangeText={setNovoPoema}
            placeholderTextColor="#aaa"
          />
          <Button title="Salvar Poema" onPress={salvarPoema} />
        </View>

        <TouchableOpacity style={estilos.voltarButton} onPress={() => navigation.navigate('Estudos')}>
          <Text style={estilos.voltarButtonText}>Voltar para Estudos</Text>
        </TouchableOpacity>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
    paddingVertical: 15,
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    textAlign: "center",
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  poemaCard: {
    backgroundColor: '#333',
    borderRadius: 10,
    padding: 15,
    marginVertical: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 5,
  },
  poemaTexto: {
    color: '#fff',
    fontSize: 16,
    lineHeight: 24,
  },
  input: {
    height: 100,
    borderColor: '#555',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    padding: 10,
    color: '#fff',
  },
  excluirButton: {
    backgroundColor: '#e63946',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 5,
    marginTop: 10,
    alignItems: 'center',
  },
  excluirButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  voltarButton: {
    backgroundColor: '#2d7de6',
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 15,
    alignItems: 'center',
    marginVertical: 20,
  },
  voltarButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default MeusPoemas;
