import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, ImageBackground } from 'react-native';
import { Cabecalho } from '../../componentes/Cabecalho';
import { useNavigation } from '@react-navigation/native';

export function Classes() {
  const navigation = useNavigation();

  return (
    <>
      <Cabecalho />

      <ImageBackground
        style={estilos.fundo}
        source={require('../../../assets/fundo.jpg')}
        opacity={0.5} 
      >
        <View style={estilos.conteinerTitulo}>
          <Text style={estilos.titulo}>Classes:</Text>
        </View>

        <ScrollView style={estilos.scrollContent} vertical={true}>
          <TouchableOpacity
            style={estilos.botao}
            onPress={() => navigation.navigate('VideoAulas')}
          >
            <Text style={estilos.textoBotao}>Videoaulas</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={estilos.botao}
            onPress={() => navigation.navigate('Exercicios')}
          >
            <Text style={estilos.textoBotao}>Exercicios</Text>
          </TouchableOpacity>
          <TouchableOpacity style={estilos.voltarButton} onPress={() => navigation.navigate('Estudos')}>
          <Text style={estilos.voltarButtonText}>Voltar para Estudos</Text>
        </TouchableOpacity>
        </ScrollView>
        
      </ImageBackground>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center",
  },
  fundo: {
    flex: 1,
    resizeMode: 'cover',  
    width: '100%',
    height: '100%',
  },
  scrollContent: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',  
  },
  botao: {
    backgroundColor: '#295c9e',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 20,
    margin: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textoBotao: {
    color: '#fff',
    fontSize: 18,
  },
  voltarButton: {
    backgroundColor: '#2d7de6',
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 15,
    alignItems: 'center',
    marginVertical: 20,
  },
  voltarButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  }
});

export default Classes;

