import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Alert, TouchableOpacity, Text } from 'react-native';
import { Cabecalho } from '../../componentes/Cabecalho';
import { addDoc, collection } from 'firebase/firestore';
import { db, auth } from '../../../firebaseConfig'; // Import auth
import { useNavigation } from '@react-navigation/native';

export function CriarExercicio() {
  const navigation = useNavigation();
  const [titulo, setTitulo] = useState('');
  const [pergunta, setPergunta] = useState('');
  const [respostaCorreta, setRespostaCorreta] = useState('');

  // Função para salvar um novo exercício no Firestore
  const handleCriarExercicio = async () => {
    if (!titulo || !pergunta || !respostaCorreta) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }

    try {
      // Obtenha o UID do usuário autenticado
      const user = auth.currentUser;
      if (!user) {
        Alert.alert('Erro', 'Usuário não autenticado.');
        return;
      }
      
      // Salvando no Firestore
      await addDoc(collection(db, 'exercicios'), {
        titulo,
        pergunta,
        respostaCorreta,
        userId: user.uid,  // Adiciona o UID do usuário
        createdAt: new Date(),
      });

      // Limpar o formulário
      setTitulo('');
      setPergunta('');
      setRespostaCorreta('');

      Alert.alert('Sucesso', 'Exercício criado e salvo!');
      
      // Navegar de volta à página de exercícios
      navigation.navigate('Exercicios');
    } catch (error) {
      console.error('Erro ao criar exercício:', error);
      Alert.alert('Erro', 'Ocorreu um erro ao criar o exercício.');
    }
  };

  return (
    <>
      <Cabecalho />

      <View style={estilos.container}>
        <TextInput
          style={estilos.input}
          placeholder="Título"
          value={titulo}
          onChangeText={setTitulo}
        />
        <TextInput
          style={estilos.input}
          placeholder="Pergunta"
          value={pergunta}
          onChangeText={setPergunta}
        />
        <TextInput
          style={estilos.input}
          placeholder="Resposta Correta"
          value={respostaCorreta}
          onChangeText={setRespostaCorreta}
        />
        <Button title="Criar Exercício" onPress={handleCriarExercicio} />

        {/* Botão para voltar para a página de Exercícios */}
        <TouchableOpacity
          style={estilos.botaoVoltar}
          onPress={() => navigation.navigate('Exercicios')}
        >
          <Text style={estilos.textoVoltar}>Voltar para Exercícios</Text>
        </TouchableOpacity>
      </View>
    </>
  );
}

const estilos = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    padding: 20,
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
  botaoVoltar: {
    backgroundColor: '#2d7de6',
    padding: 15,
    borderRadius: 5,
    marginTop: 20,
  },
  textoVoltar: {
    color: '#fff',
    textAlign: 'center',
    fontSize: 18,
  },
});

export default CriarExercicio;
