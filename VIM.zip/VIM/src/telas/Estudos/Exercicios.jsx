import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, ScrollView, StyleSheet, Alert, TouchableOpacity } from 'react-native';
import { Cabecalho } from '../../componentes/Cabecalho';
import { useNavigation } from '@react-navigation/native';
import { getDocs, collection, deleteDoc, doc } from 'firebase/firestore';
import { db, auth } from '../../../firebaseConfig'; 

export function Exercicios() {
  const navigation = useNavigation();
  const [exercicios, setExercicios] = useState([]);
  const [carregando, setCarregando] = useState(false);
  const [filtro, setFiltro] = useState('');
  const [exerciciosFiltrados, setExerciciosFiltrados] = useState([]);
  const [respostas, setRespostas] = useState({}); // Armazenar as respostas do usuário

  // Função para carregar exercícios do Firestore
  const carregarExercicios = async () => {
    setCarregando(true);
    try {
      const querySnapshot = await getDocs(collection(db, 'exercicios'));
      const listaExercicios = [];
      querySnapshot.forEach((doc) => {
        listaExercicios.push({ id: doc.id, ...doc.data() });
      });
      setExercicios(listaExercicios);
      setExerciciosFiltrados(listaExercicios); // Inicialmente, sem filtro
    } catch (error) {
      console.error('Erro ao carregar exercícios:', error);
    } finally {
      setCarregando(false);
    }
  };

  // Função para filtrar exercícios com base no titulo ou pergunta
  const handleFiltrar = (texto) => {
    setFiltro(texto);
    if (texto.trim() === '') {
      setExerciciosFiltrados(exercicios);
    } else {
      const filtrados = exercicios.filter((exercicio) => 
        exercicio.titulo.toLowerCase().includes(texto.toLowerCase()) || 
        exercicio.pergunta.toLowerCase().includes(texto.toLowerCase())
      );
      setExerciciosFiltrados(filtrados);
    }
  };

  // Função para lidar com a resposta do usuário
  const handleResponder = (id, respostaUsuario, respostaCorreta) => {
    if (respostaUsuario.trim().toLowerCase() === respostaCorreta.toLowerCase()) {
      Alert.alert('Correto!', 'Você acertou a resposta.');
    } else {
      Alert.alert('Incorreto', 'Tente novamente.');
    }
  };

  // Função para armazenar a resposta inserida pelo usuário
  const handleChangeResposta = (id, texto) => {
    setRespostas(prevState => ({ ...prevState, [id]: texto }));
  };

  // Função para excluir um exercício
  const handleExcluir = (id) => {
    Alert.alert(
      'Confirmar Exclusão',
      'Você tem certeza que deseja excluir este exercício?',
      [
        {
          text: 'Cancelar',
          style: 'cancel',
        },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: async () => {
            try {
              // Excluir do Firestore
              await deleteDoc(doc(db, 'exercicios', id));

              // Atualizar a lista de exercícios
              setExercicios((prevState) => prevState.filter((exercicio) => exercicio.id !== id));
              setExerciciosFiltrados((prevState) => prevState.filter((exercicio) => exercicio.id !== id));
              
              Alert.alert('Sucesso', 'Exercício excluído com sucesso.');
            } catch (error) {
              console.error('Erro ao excluir exercício:', error);
              Alert.alert('Erro', 'Ocorreu um erro ao excluir o exercício.');
            }
          },
        },
      ],
      { cancelable: true }
    );
  };

  useEffect(() => {
    carregarExercicios();
  }, []);

  return (
    <>
      <Cabecalho />

      <View style={estilos.conteinerTitulo}>
        <Text style={estilos.titulor}>Exercícios:</Text>
      </View>

      <ScrollView style={estilos.scrollContent}>
        <View style={estilos.formContainer}>
          <TextInput
            style={estilos.input}
            placeholder="Pesquisar exercícios (por titulo ou Pergunta)"
            value={filtro}
            onChangeText={handleFiltrar}
          />
        </View>

        <View style={estilos.exerciciosContainer}>
          {carregando ? (
            <Text style={estilos.loadingText}>Carregando exercícios...</Text>
          ) : (
            exerciciosFiltrados.map((exercicio) => (
              <View key={exercicio.id} style={estilos.exercicio}>
                <Text style={estilos.pergunta}>
                  <Text style={estilos.titulo}>{exercicio.titulo}: </Text>
                  {exercicio.pergunta}
                </Text>

                {/* Campo de resposta do usuário */}
                <TextInput
                  style={estilos.inputResposta}
                  placeholder="Sua resposta"
                  value={respostas[exercicio.id] || ''}
                  onChangeText={(texto) => handleChangeResposta(exercicio.id, texto)}
                />

                {/* Botão para enviar a resposta */}
                <Button
                  title="Responder"
                  onPress={() => handleResponder(exercicio.id, respostas[exercicio.id], exercicio.respostaCorreta)}
                />

                {/* Botão para excluir o exercício */}
                {auth.currentUser && auth.currentUser.uid === exercicio.userId && (
                  <TouchableOpacity
                    style={estilos.botaoExcluir}
                    onPress={() => handleExcluir(exercicio.id)}
                  >
                    <Text style={estilos.textoExcluir}>Excluir</Text>
                  </TouchableOpacity>
                )}
              </View>
            ))
          )}
        </View>

        <TouchableOpacity style={estilos.botaoCriarExercicio} onPress={() => navigation.navigate('CriarExercicio')}>
          <Text style={estilos.textoCriarExercicio}>Criar Exercício</Text>
        </TouchableOpacity>

        {/* Botão para navegar para a página Estudos */}
        <TouchableOpacity style={estilos.botaoEstudos} onPress={() => navigation.navigate('Estudos')}>
          <Text style={estilos.textoEstudos}>Ir para Estudos</Text>
        </TouchableOpacity>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulor: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 20,
  },
  formContainer: {
    marginBottom: 20,
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
  exerciciosContainer: {
    marginTop: 20,
  },
  exercicio: {
    backgroundColor: '#333',
    borderRadius: 5,
    padding: 15,
    marginBottom: 20,
  },
  pergunta: {
    color: '#fff',
    fontSize: 18,
    marginBottom: 10,
  },
  titulo: {
    fontWeight: 'bold',
  },
  loadingText: {
    color: '#fff',
    fontSize: 18,
    textAlign: 'center',
  },
  inputResposta: {
    backgroundColor: '#fff',
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
    marginTop: 10,
  },
  botaoCriarExercicio: {
    backgroundColor: '#2d7de6',
    padding: 15,
    borderRadius: 5,
    marginTop: 20,
  },
  textoCriarExercicio: {
    color: '#fff',
    textAlign: 'center',
    fontSize: 18,
  },
  botaoEstudos: {
    backgroundColor: '#2d7de6',
    padding: 15,
    borderRadius: 5,
    marginTop: 20,
    marginBottom: 30,
  },
  textoEstudos: {
    color: '#fff',
    textAlign: 'center',
    fontSize: 18,
  },
  botaoExcluir: {
    backgroundColor: '#e74c3c',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  textoExcluir: {
    color: '#fff',
    textAlign: 'center',
    fontSize: 16,
  },
});

export default Exercicios;
