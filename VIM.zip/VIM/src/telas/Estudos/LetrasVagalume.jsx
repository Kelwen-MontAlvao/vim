import React, { useState } from 'react';
import { View, Text, TextInput, Button, ScrollView, StyleSheet, Image, TouchableOpacity } from 'react-native';
import axios from 'axios';
import { useNavigation } from '@react-navigation/native'; // Para navegação
import { Cabecalho } from '../../componentes/Cabecalho';

export function LetrasVagalume() {
  const [searchQuery, setSearchQuery] = useState('');
  const [lyrics, setLyrics] = useState('');
  const [translation, setTranslation] = useState('');
  const [error, setError] = useState('');
  const [showTranslation, setShowTranslation] = useState(false);

  const navigation = useNavigation(); // Hook de navegação

  const fetchLyrics = async () => {
    if (!searchQuery.trim()) {
      setError('Por favor, insira um termo de pesquisa.');
      return;
    }

    try {
      // Fetch music data
      const response = await axios.get('https://api.vagalume.com.br/search.php', {
        params: {
          art: searchQuery.split(' - ')[0], // Artista
          mus: searchQuery.split(' - ')[1], // Música
          apikey: '1fc6a797fb0fc9ffc1ff6af91e9d71a5',
        }
      });

      if (response.data && response.data.mus && response.data.mus.length > 0) {
        const musicId = response.data.mus[0].id;

        // Fetch lyrics
        const lyricsResponse = await axios.get('https://api.vagalume.com.br/search.php', {
          params: {
            musid: musicId,
            apikey: '1fc6a797fb0fc9ffc1ff6af91e9d71a5',
          }
        });
        console.log('Lyrics Response:', lyricsResponse.data); 
        setLyrics(lyricsResponse.data.mus[0].text || '');

        // Fetch translation (do inglês para o português)
        const translationResponse = await axios.get('https://api.vagalume.com.br/search.php', {
          params: {
            musid: musicId,
            extra: 'translate',
            apikey: '1fc6a797fb0fc9ffc1ff6af91e9d71a5',
          }
        });
        setTranslation(translationResponse.data.mus[0].translate?.[0]?.text || '');

        setError('');
        setShowTranslation(false); 
      } else {
        setError('Sem resultados encontrados.');
      }
    } catch (err) {
      console.error('Request Error:', err); 
      setError('Ocorreu um erro ao buscar os dados.');
    }
  };

  const handleToggleTranslation = () => {
    setShowTranslation(!showTranslation);
  };

  return (
    <>
      <Cabecalho />

      <View style={estilos.conteinerTitulo}>
        <Text style={estilos.titulo}>Letras:</Text>
      </View>

      {/* Botão para voltar para a página Estudos */}
      <View style={estilos.voltarContainer}>
        <TouchableOpacity style={estilos.voltarBotao} onPress={() => navigation.navigate('Estudos')}>
          <Text style={estilos.voltarBotaoTexto}>Voltar para Estudos</Text>
        </TouchableOpacity>
      </View>

      <View style={estilos.searchContainer}>
        <TextInput
          style={estilos.searchInput}
          placeholder="Procure por uma música (Artista - Música)..."
          placeholderTextColor="#ccc"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        <Button title="Buscar" onPress={fetchLyrics} />
      </View>

      <ScrollView style={estilos.scrollContent}>
        {error ? (
          <Text style={estilos.error}>{error}</Text>
        ) : (
          <>
            <View style={estilos.lyricsContainer}>
              <Text style={estilos.lyrics}>
                {showTranslation ? translation : lyrics}
              </Text>
            </View>
            <Button
              title={showTranslation ? 'Mostrar letra original' : 'Mostrar tradução'}
              onPress={handleToggleTranslation}
            />
            <View style={estilos.creditContainer}>
              <Image
                source={require('../../imgs/vagalume-logo.png')}
                style={estilos.logo}
              />
              <Text style={estilos.creditText}>Dados fornecidos por Vagalume</Text>
            </View>
          </>
        )}
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  voltarContainer: {
    backgroundColor: '#000', // Fundo escuro ao redor do botão
    padding: 10,
  },
  voltarBotao: {
    backgroundColor: '#2d7de6', // Azul escuro no botão
    padding: 10,
    alignItems: 'center',
    borderRadius: 5,
  },
  voltarBotaoTexto: {
    color: '#fff', // Texto branco no botão
    fontSize: 16,
    fontWeight: 'bold',
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  searchContainer: {
    padding: 10,
    backgroundColor: '#333',
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  searchInput: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    paddingHorizontal: 10,
    marginBottom: 10,
    backgroundColor: '#555', 
    color: '#fff', 
  },
  lyricsContainer: {
    marginBottom: 20,
  },
  lyrics: {
    color: '#fff',
  },
  creditContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  logo: {
    width: 100,
    height: 30,
    resizeMode: 'contain',
    marginBottom: 5,
  },
  creditText: {
    color: '#fff',
    fontSize: 12,
  },
  error: {
    color: 'red',
    textAlign: 'center',
    padding: 20,
  },
});

export default LetrasVagalume;
