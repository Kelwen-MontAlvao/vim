import React from 'react';
import { View, Text, Image, ScrollView, StyleSheet, Linking, TouchableOpacity } from 'react-native';
import { Cabecalho } from '../componentes/Cabecalho';

export function Contatenos() {
  const openInstagram = () => {
    Linking.openURL('https://www.instagram.com/projeto_v_i_m'); // Substitua pelo link do Instagram do projeto
  };

  const openLinkedIn = (url) => {
    Linking.openURL(url);
  };

  return (
    <>
      <Cabecalho />

      <View style={estilos.conteinerTitulo}>
        <Text style={estilos.titulo}>Contate-nos:</Text>
      </View>

      <ScrollView style={estilos.scrollContent}>
        <TouchableOpacity onPress={openInstagram} style={estilos.instagramContainer}>
          <Text style={estilos.instagramText}>Siga-nos no Instagram</Text>
        </TouchableOpacity>

        <View style={estilos.integrante}>
          <Image source={require('../imgs/neves.jpg')} style={estilos.foto} />
          <Text style={estilos.nome}>Gabriel Neves da Rocha</Text>
          <Text style={estilos.contato}>Telefone: (19)97159-6613</Text>
          <Text style={estilos.contato}>Email: gabriel.nr07@gmail.com</Text>
          <Text style={estilos.contato}>Instagram: @garbelvenes</Text>
          <TouchableOpacity onPress={() => openLinkedIn('https://www.linkedin.com/in/gabriel-rocha-09b399249/')}>
            <Text style={estilos.contatolinkedin}>LinkedIn: Gabriel Neves</Text>
          </TouchableOpacity>
        </View>

        <View style={estilos.integrante}>
          <Image source={require('../imgs/gui.jpg')} style={estilos.foto} />
          <Text style={estilos.nome}>Guilherme Oliveira Costa</Text>
          <Text style={estilos.contato}>Telefone: (19)99834-4377</Text>
          <Text style={estilos.contato}>Email: gcostaravenal@gmail.com</Text>
          <Text style={estilos.contato}>Instagram: @oliveira_006_</Text>
          <TouchableOpacity onPress={() => openLinkedIn('https://www.linkedin.com/in/guilherme-oliveira-costa-97b516302/')}>
            <Text style={estilos.contatolinkedin}>LinkedIn: Guilherme Oliveira Costa</Text>
          </TouchableOpacity>
        </View>

        <View style={estilos.integrante}>
          <Image source={require('../imgs/kel.jpg')} style={estilos.foto} />
          <Text style={estilos.nome}>Kelwen Gonçalves Mont'Alvão</Text>
          <Text style={estilos.contato}>Telefone: (19)97124-0792</Text>
          <Text style={estilos.contato}>Email: kelwenmontalvao@gmail.com</Text>
          <Text style={estilos.contato}>Instagram: @kel_gonmont</Text>
          <TouchableOpacity onPress={() => openLinkedIn('https://www.linkedin.com/in/kelwen-mont-alv%C3%A3o-743059194/')}>
            <Text style={estilos.contatolinkedin}>LinkedIn: Kelwen Gonçalves</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center",
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
  },
  instagramContainer: {
    alignItems: 'center',
    padding: 20,
  },
  instagramText: {
    color: '#2d9ce6',
    fontSize: 18,
    textDecorationLine: 'underline',
  },
  integrante: {
    alignItems: 'center',
    marginBottom: 20,
  },
  foto: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  nome: {
    color: '#fff',
    fontSize: 20,
    marginVertical: 5,
  },
  bio: {
    color: '#ccc',
    textAlign: 'center',
    marginBottom: 10,
  },
  contato: {
    color: '#fff',
    marginBottom: 5,
  },
  contatolinkedin: {
    color: '#2d9ce6',
    marginBottom: 5,
  },
});

export default Contatenos;
