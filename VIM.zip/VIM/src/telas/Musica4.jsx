import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../componentes/Cabecalho';
import { Botao } from '../componentes/Botao';
import { BotaoVoltar } from '../componentes/Voltar';

export function Musica4() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'rYEDA3JcQqw'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='home'/>
        <Text style={estilos.titulo}>
          Adele - Rolling in the Deep
        </Text>

        <Text style={estilos.letraMusica}>

            There's a <Botao palavra='fire'
                             destino='Exercicio' 
                             imagem='fire'
                             palavrasCorretas={['fogo', 'chama']}
                             voltar={'Musica4'}/>starting in my heart{"\n"}

            <Botao palavra='Reaching a fever pitch'
                   destino='Exercicio' 
                   imagem='fever'
                   palavrasCorretas={['Ficando com febre', 'Ficando febril', 'Atingindo nivel febril', 'atingindo nível febril']}
                   contexto={"Uma ação que está acontecendo, está chegando lá"}
                   voltar={'Musica4'}/>and it's bringing me out the dark{"\n"}
                   
            Finally, I can see you crystal <Botao palavra='clear'
                                                  destino='Exercicio' 
                                                  imagem='clean home' 
                                                  palavrasCorretas={['claro']}
                                                  contexto={"Quando algo está limpo na sua mente, de fácil entendimento, está ______"}
                                                  voltar={'Musica4'}/>{"\n"}

            <Botao palavra='Go Ahead'
                   destino='Exercicio' 
                   imagem='go ahead' 
                   palavrasCorretas={['Vá em frente']}
                   voltar={'Musica4'}/>and sell me out and I'll
                   
                   <Botao palavra='lay'
                          destino='Exercicio' 
                          imagem='lecture'
                          palavrasCorretas={['Expor']}
                          contexto={"A pessoa ira fazer isso, ela vai te _______ (infinitivo)"}
                          voltar={'Musica4'}/>your
                          
                   <Botao palavra='shit bare'
                          destino='Exercicio' 
                          imagem='shit bare'
                          palavrasCorretas={['Merda', 'Bosta', 'Cocô']}
                          contexto='Quando alguém faz algo ruim, que possivelmente gere outros problemas: ele fez _____.'
                          voltar={'Musica4'}/>{"\n"}{"\n"}

            See how I'll leave with every piece of you{"\n"}
            Don't <Botao palavra='underestimate'
                         destino='Exercicio' 
                         imagem='down arrow plate'
                         palavrasCorretas={['Subestimar']}
                         contexto={"Quando alguém espera muito pouco da outra pessoa"}
                         voltar={'Musica4'}/> the things that I will do{"\n"}{"\n"}

            There's a fire starting in my heart{"\n"}
            <Botao palavra='Reaching a fever pitch'
                   destino='Exercicio' 
                   imagem='fever'
                   palavrasCorretas={['Ficando com febre', 'Ficando febril', 'Atingindo nivel febril', 'atingindo nível febril']}
                   contexto={"Uma ação que está acontecendo, está chegando lá"}
                   voltar={'Musica4'}/> and it's bringing me out the dark{"\n"}{"\n"}

            The <Botao palavra='scars'
                       destino='Exercicio' 
                       imagem='scars'
                       palavrasCorretas={['Cicatrizes', 'Cicatriz']}
                       voltar={'Musica4'}/>of your love remind me of us{"\n"}

            They keep me thinking that we almost had it all{"\n"}
            The scars of your love, they leave me <Botao palavra='breathless'
                                                         destino='Exercicio' 
                                                         imagem='breathless'
                                                         palavrasCorretas={['sem fôlego', 'sem folego']}
                                                         contexto={"Quando as pessoas acabam ficando com dificuldades de respirar, após correr muito(exemplo)"}
                                                         voltar={'Musica4'}/>{"\n"}
            I can't help feeling{"\n"}{"\n"}

            We could've had it all{"\n"}
            (You're gonna wish you never had met me){"\n"}
            <Botao palavra='Rolling in the deep'
                   destino='Exercicio' 
                   imagem='lost in the woods'
                   palavrasCorretas={['Perdido', 'Perdidamente']}
                   contexto={"Um contexto onde alguém não sabe como voltar"}
                   voltar={'Musica4'}/>{"\n"}

            (<Botao palavra='Tears'
                   destino='Exercicio' 
                   imagem='tears'
                   palavrasCorretas={['Lágrimas']}
                   voltar={'Musica4'}/>are gonna fall, rolling in the deep){"\n"}

            You had my heart <Botao palavra='inside of your hand'
                                    destino='Exercicio' 
                                    imagem='rule the world'
                                    palavrasCorretas={['Na palma da mão', 'dentro da mão']}
                                    contexto={"Quando está segurando algo, ao seu controle"}
                                    voltar={'Musica4'}/>{"\n"}

            (You're gonna wish you never had met me){"\n"}
            And you played it to the <Botao palavra='beat'
                                            destino='Exercicio' 
                                            imagem='beat'
                                            palavrasCorretas={['Ritmo', 'beat', 'batida']}
                                            contexto={"Quando se canta, você tem que cantar no _______ da música"}
                                            voltar={'Musica4'}/>{"\n"}

            (Tears are gonna fall, rolling in the deep){"\n"}{"\n"}

            Baby, I have no story to be told{"\n"}
            But I've heard one of you and I'm gonna make your head <Botao palavra='burn'
                                                                          destino='Exercicio' 
                                                                          imagem='burn'
                                                                          palavrasCorretas={['queimar', 'queimando']}
                                                                          contexto={"O verbo."}
                                                                          voltar={'Musica4'}/>{"\n"}
            Think of me in the <Botao palavra='depths'
                                      destino='Exercicio' 
                                      imagem='depths'
                                      palavrasCorretas={['profundezas', 'Profundo', 'Profundeza']}
                                      contexto={"A palavra está se referindo a algo que está muito embaixo, bem perto da raízes de qualquer coisa"}
                                      voltar={'Musica4'}/> of your 
                                      
                               <Botao palavra='despair'
                                      destino='Exercicio' 
                                      imagem='someone desperate'
                                      palavrasCorretas={['desespero']}
                                      voltar={'Musica4'}/>{"\n"}

            Making home down there, as mine sure won't be <Botao palavra='shared'
                                                                 destino='Exercicio' 
                                                                 imagem='shared'
                                                                 palavrasCorretas={['Compartilhado']}
                                                                 contexto={"A ação de dividir (passado)"}
                                                                 voltar={'Musica4'}/>{"\n"}{"\n"}

            (You're gonna wish you never had met me){"\n"}
            The scars of your love remind me of us{"\n"}
            (Tears are gonna <Botao palavra='fall'
                                    destino='Exercicio' 
                                    imagem='someone falling' 
                                    palavrasCorretas={['Cair']}
                                    voltar={'Musica4'}/>, rolling in the deep){"\n"}

            They keep me thinking that we almost had it all{"\n"}
            (You're gonna wish you never had met me){"\n"}
            The scars of your love, they leave me <Botao palavra='breathless'
                                                         destino='Exercicio' 
                                                         imagem='breathless'
                                                         palavrasCorretas={['sem fôlego', 'sem folego']}
                                                         contexto={"Quando as pessoas acabam ficando com dificuldades de respirar, após correr muito(exemplo)"}
                                                         voltar={'Musica4'}/>{"\n"}
            (Tears are gonna fall, rolling in the deep){"\n"}
            I can't help feeling{"\n"}{"\n"}

            We could've had it all{"\n"}
            (You're gonna wish you never had met me){"\n"}
            Rolling in the deep{"\n"}
            (Tears are gonna fall, rolling in the deep){"\n"}
            You had my heart inside of your hand{"\n"}
            (You're gonna wish you never had met me){"\n"}
            And you played it to the beat{"\n"}
            (Tears are gonna fall, rolling in the deep){"\n"}{"\n"}

            We could've had it all{"\n"}
            Rolling in the deep{"\n"}
            You had my heart inside of your hand{"\n"}
            But you played it with a beating{"\n"}{"\n"}

            <Botao palavra='Throw'
                   destino='Exercicio' 
                   imagem='Throw'
                   palavrasCorretas={['Jogar', 'Lançar']}
                   voltar={'Musica4'}/> your 
                   
            <Botao palavra='soul'
                   destino='Exercicio' 
                   imagem='soul'
                   palavrasCorretas={['Alma']}
                   contexto='Está dentro de nós'
                   voltar={'Musica4'}/> through every open door{"\n"}

            Count your <Botao palavra='blessings'
                              destino='Exercicio' 
                              imagem='bless'
                              palavrasCorretas={['Bençãos', 'Benção']}
                              voltar={'Musica4'}/> to find what you look for{"\n"}

            Turn my <Botao palavra='sorrow'
                           destino='Exercicio' 
                           imagem='sorrow'
                           palavrasCorretas={['Tristeza', 'Triste']}
                           voltar={'Musica4'}/> into 
                           
                    <Botao palavra='treasured'
                           destino='Exercicio' 
                           imagem='treasure'
                           palavrasCorretas={['Precioso', 'important']}
                           contexto={"Algo extremamente importante e que deve ser guardado com carinho"}
                           voltar={'Musica4'}/> gold{"\n"}
                           
            You pay me back <Botao palavra='in kind and reap just what you sow'
                                   destino='Exercicio' 
                                   imagem='cultivation' 
                                   palavrasCorretas={['você colhe o que planta']}
                                   contexto={"Ditado muito famoso"}
                                   voltar={'Musica4'}/> gold{"\n"}{"\n"}{"\n"}

            (You're gonna wish you never had met me){"\n"}
            We could've had it all{"\n"}
            (Tears are gonna fall, rolling in the deep){"\n"}
            We could've had it all{"\n"}
            (You're gonna wish you never had met me){"\n"}
            It all, it all, it all{"\n"}
            (Tears are gonna fall, rolling in the deep){"\n"}{"\n"}

            We could've had it all{"\n"}
            (You're gonna wish you never had met me){"\n"}
            Rolling in the deep{"\n"}
            (Tears are gonna fall, rolling in the deep){"\n"}
            You had my heart inside of your hand{"\n"}
            (You're gonna wish you never had met me){"\n"}
            And you played it to the beat{"\n"}
            (Tears are gonna fall, rolling in the deep){"\n"}{"\n"}

            Could've had it all{"\n"}
            (You're gonna wish you never had met me){"\n"}
            Rolling in the deep{"\n"}
            (Tears are gonna fall, rolling in the deep){"\n"}
            You had my heart inside of your hand{"\n"}
            (You're gonna wish you never had met me){"\n"}{"\n"}

            But you played it{"\n"}
            You played it{"\n"}
            You played it{"\n"}
            You played it to the beat{"\n"}{"\n"}

        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Musica4;