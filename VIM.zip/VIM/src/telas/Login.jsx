import React, { useState } from 'react';
import { View, Text, Image, TextInput, ScrollView, StyleSheet, TouchableOpacity, Alert, StatusBar } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { auth } from '../../firebaseConfig'; 
import { signInWithEmailAndPassword } from 'firebase/auth';

export function Login() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const navegacao = useNavigation();

  const handleLogin = async () => {
    if (!email || !senha) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos');
      return;
    }

    try {
      await signInWithEmailAndPassword(auth, email, senha);
      navegacao.navigate('Inicial');
    } catch (error) {
      console.error(error);
      Alert.alert('Erro', 'Não foi possível realizar o login. Verifique suas credenciais.');
    }
  };

  const handleLoginSemConta = () => {
    // Navegar para a tela inicial ou uma tela sem necessidade de login
    navegacao.navigate('Inicial');
  };

  return (
    <ScrollView contentContainerStyle={estilos.scrollContainer} style={estilos.scrollContent}>
      <StatusBar hidden={true} />
      <View style={estilos.conteinerTitulo}>
        <Text style={estilos.titulo}>LOGIN</Text>
      </View>
      <View style={estilos.formContainer}>
        <Image
          source={require('../../assets/logo.png')} 
          style={estilos.imagem}
        />
        <TextInput
          style={estilos.input}
          placeholder="Email"
          placeholderTextColor="#999"
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
        />
        <TextInput
          style={estilos.input}
          placeholder="Senha"
          placeholderTextColor="#999"
          secureTextEntry
          value={senha}
          onChangeText={setSenha}
        />
        <TouchableOpacity style={estilos.botao} onPress={handleLogin}>
          <Text style={estilos.textoBotao}>Login</Text>  
        </TouchableOpacity>
        <TouchableOpacity style={estilos.link} onPress={() => navegacao.navigate('Cadastro')}>
          <Text style={estilos.textoLink}>Não possuo conta</Text> 
        </TouchableOpacity>
        <TouchableOpacity style={estilos.link2} onPress={handleLoginSemConta}>
          <Text style={estilos.textoLink}>Logar sem conta</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
    paddingVertical: 10,
    width: '100%',
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center",
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
  },
  scrollContainer: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  formContainer: {
    alignItems: 'center',
    width: '80%',
  },
  imagem: {
    width: 250,
    height: 250,
    marginVertical: 10,
  },
  input: {
    width: '100%',
    height: 40,
    backgroundColor: '#fff',
    marginBottom: 10,
    paddingHorizontal: 10,
    borderRadius: 5,
  },
  botao: {
    backgroundColor: '#2d7de6',
    borderRadius: 20,
    width: 250,
    marginTop: 20
  },
  textoBotao: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center"
  },
  link: {
    marginTop: 10,
  },
  link2: {
    marginTop: 0,
  },
  textoLink: {
    color: 'rgba(255, 255, 255, 0.8)', // Meio transparente
    fontSize: 18,
    padding: 5,
    textAlign: "center",
    textDecorationLine: 'underline'
  }
});

export default Login;
