import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import axios from 'axios';
import { Cabecalho } from '../componentes/Cabecalho';

export function Dicionario() {
  const [word, setWord] = useState('');
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  const fetchWordData = async () => {
    try {
      const response = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
      setData(response.data[0]);
      setError(null);
    } catch (err) {
      setError('Palavra não encontrada!');
      setData(null);
    }
  };

  return (
    <>
      <Cabecalho />

      <View style={estilos.conteinerTitulo}>
        <Text style={estilos.titulo}>Dicionário:</Text>
      </View>

      <View style={estilos.searchContainer}>
        <TextInput
          style={estilos.input}
          placeholder="Escreva uma palavra"
          placeholderTextColor="rgba(255, 255, 255, 0.6)"
          value={word}
          onChangeText={setWord}
        />

        <TouchableOpacity onPress={fetchWordData} style={estilos.button}>
          <Text style={estilos.buttonText}>Procurar</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={estilos.scrollContent} contentContainerStyle={estilos.scrollContainer}>
        {error && <Text style={estilos.errorText}>{error}</Text>}

        {data && (
          <>
            <Text style={estilos.word}>{data.word}</Text>
            {data.phonetics.map((phonetic, index) => (
              <View key={index} style={estilos.phoneticContainer}>
                <Text style={estilos.phonetic}>{phonetic.text}</Text>
              </View>
            ))}
            {data.meanings.map((meaning, index) => (
              <View key={index} style={estilos.meaningContainer}>
                <Text style={estilos.partOfSpeech}>{meaning.partOfSpeech}</Text>

                {meaning.definitions.map((definition, defIndex) => (
                  <View key={defIndex} style={estilos.definitionContainer}>
                    <Text style={estilos.definition}>{definition.definition}</Text>
                    {definition.example && <Text style={estilos.example}>Exemplo: {definition.example}</Text>}
                  </View>
                ))}
              </View>
            ))}
          </>
        )}
      </ScrollView>

      <View style={estilos.footer}>
        <Text style={estilos.footerText}>Powered by FreeDictionaryAPI</Text>
      </View>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    paddingHorizontal: 20,
  },
  scrollContainer: {
    alignItems: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    padding: 10,
    backgroundColor: '#333',
  },
  input: {
    flex: 1,
    borderColor: '#2d7de6',
    borderWidth: 1,
    padding: 10,
    marginRight: 10,
    borderRadius: 5,
    color: '#fff',
  },
  word: {
    fontSize: 30,
    color: '#fff',
    marginVertical: 10,
  },
  phoneticContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 5,
  },
  phonetic: {
    fontSize: 20,
    color: '#ccc',
    marginRight: 10,
  },
  audioText: {
    fontSize: 18,
    color: '#1E90FF',
    textDecorationLine: 'underline',
  },
  meaningContainer: {
    marginVertical: 10,
  },
  partOfSpeech: {
    fontSize: 22,
    color: '#ff6',
    marginBottom: 5,
  },
  definitionContainer: {
    marginBottom: 10,
  },
  definition: {
    fontSize: 18,
    color: '#fff',
  },
  example: {
    fontSize: 16,
    color: '#aaa',
    fontStyle: 'italic',
  },
  errorText: {
    color: 'red',
    fontSize: 18,
    marginVertical: 20,
  },
  button: {
    backgroundColor: '#2d7de6',
    padding: 15,
    borderRadius: 5,
    alignSelf: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  footer: {
    backgroundColor: '#333',
    padding: 10,
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#444',
  },
  footerText: {
    color: '#ccc',
    fontSize: 14,
  },
});

export default Dicionario;
