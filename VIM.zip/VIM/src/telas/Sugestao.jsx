import React, { useState } from 'react';
import { View, Text, TextInput, Button, ScrollView, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import { Cabecalho } from '../componentes/Cabecalho';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '../../firebaseConfig'; 

export function Sugestao() {
  const [titulo, setTitulo] = useState('');
  const [artista, setArtista] = useState('');
  const [linkYoutube, setLinkYoutube] = useState('');
  const [palavrasInterativas, setPalavrasInterativas] = useState('');
  const [motivo, setMotivo] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async () => {
    if (!titulo || !artista || !linkYoutube || !palavrasInterativas || !motivo) {
      Alert.alert('Erro', 'Todos os campos são obrigatórios.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const sugestoesRef = collection(db, 'sugestoes');
      await addDoc(sugestoesRef, {
        titulo,
        artista,
        linkYoutube,
        palavrasInterativas,
        motivo,
        createdAt: new Date(),
      });
      Alert.alert('Sucesso', 'Sugestão enviada com sucesso!');
      // Limpar os campos do formulário após o envio
      setTitulo('');
      setArtista('');
      setLinkYoutube('');
      setPalavrasInterativas('');
      setMotivo('');
    } catch (error) {
      console.error('Erro ao enviar a sugestão:', error);
      setError('Ocorreu um erro ao enviar a sugestão. Tente novamente mais tarde.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Cabecalho />

      <View style={estilos.conteinerTitulo}>
        <Text style={estilos.titulo}>Sugestão:</Text>
      </View>

      <ScrollView style={estilos.scrollContent}>
        <View style={estilos.formContainer}>
          <TextInput
            style={estilos.input}
            placeholder="Título da Música"
            value={titulo}
            onChangeText={setTitulo}
          />
          <TextInput
            style={estilos.input}
            placeholder="Artista"
            value={artista}
            onChangeText={setArtista}
          />
          <TextInput
            style={estilos.input}
            placeholder="Link do YouTube"
            value={linkYoutube}
            onChangeText={setLinkYoutube}
          />
          <TextInput
            style={estilos.input}
            placeholder="Palavras Interativas"
            value={palavrasInterativas}
            onChangeText={setPalavrasInterativas}
          />
          <TextInput
            style={[estilos.input, { height: 100 }]}
            placeholder="Motivo para Adicionar"
            value={motivo}
            onChangeText={setMotivo}
            multiline
          />
          <Button title="Enviar Sugestão" onPress={handleSubmit} />
          {loading && <ActivityIndicator size="large" color="#fff" style={estilos.loadingIndicator} />}
          {error && <Text style={estilos.errorText}>{error}</Text>}
        </View>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
  },
  formContainer: {
    padding: 20,
    backgroundColor: '#333',
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 5,
    padding: 10,
    marginBottom: 15,
  },
  loadingIndicator: {
    marginTop: 20,
  },
  errorText: {
    color: '#f00',
    marginTop: 10,
  },
});

export default Sugestao;
