import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../componentes/Cabecalho';
import { Botao } from '../componentes/Botao';
import { BotaoVoltar } from '../componentes/Voltar';

export function Musica2() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'dvgZkm1xWPE'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='home'/>
        <Text style={estilos.titulo}>
          ColdPlay - Viva la Vida
        </Text>

        <Text style={estilos.letraMusica}>

        I used to <Botao palavra='rule'
                         destino='Exercicio' 
                         imagem='rule the world'
                         palavrasCorretas={['dominar', 'mandar', 'ditar']} 
                         contexto={"A palavra sugere que o 'cantor' exercia poder sobre o mundo."}
                         voltar={'Musica2'}/>the
                         

                     <Botao palavra='world' 
                            destino='Exercicio' 
                            imagem='earth planet'
                            palavrasCorretas={['mundo']}
                            voltar={'Musica2'}/>{"\n"}

          <Botao palavra='Seas' 
                 destino='Exercicio' 
                 imagem='seas'
                 palavrasCorretas={['mar', 'mares']}
                 voltar={'Musica2'}/>would
                 
                 <Botao palavra='rise' 
                     destino='Exercicio' 
                     imagem='rise'
                     palavrasCorretas={['subiria', 'subir']}
                     contexto={"A palavra se refere ao verbo no passado, sendo algo no qual 'seria feito' se outra coisa acontecesse"}
                     voltar={'Musica2'}/>when I gave the word{"\n"}

          Now in the morning i<Botao palavra='sleep'
                                     destino='Exercicio' 
                                     imagem='sleep'
                                     palavrasCorretas={['dormir']}
                                     voltar={'Musica2'}/>alone{"\n"}

          <Botao palavra='Sweep' 
                 destino='Exercicio' 
                 imagem='Sweep'
                 palavrasCorretas={['varrer']}
                 voltar={'Musica2'}/>the
          
          <Botao palavra='streets'
                 destino='Exercicio' 
                 imagem='streets with car passing '
                 palavrasCorretas={['ruas', 'rua']}
                 voltar={'Musica2'}/>i used to own{"\n"}{"\n"}

          I used to <Botao palavra='roll'
                           destino='Exercicio' 
                           imagem='roll'
                           palavrasCorretas={['jogar', 'lançar', 'rolar']}
                           contexto={'Refere-se completamente a ação sendo feita (e também pode estar relacionada a qualquer objeto)'}
                           voltar={'Musica2'}/>the

                    <Botao palavra='dice'
                           destino='Exercicio' 
                           imagem='dice'
                           palavrasCorretas={['dado', 'dados']}
                           voltar={'Musica2'}/>{"\n"}

          Feel the <Botao palavra='fear' 
                          destino='Exercicio' 
                          imagem='fear'
                          palavrasCorretas={['medo']}
                          voltar={'Musica2'}/>in my enemy's eyes{"\n"}

          Listened as the <Botao palavra='crowd' 
                                 destino='Exercicio' 
                                 imagem='crowd'
                                 palavrasCorretas={['multidão', 'multidao']} 
                                 contexto={'Quando há muitas pessoas'}
                                 voltar={'Musica2'}/>would sing{"\n"}

          Now the old <Botao palavra='King' 
                             destino='Exercicio' 
                             imagem='King'
                             palavrasCorretas={['rei']} 
                             voltar={'Musica2'}/>is dead!{"\n"}
                             

          Long live the king!{"\n"}{"\n"}

          One minute I <Botao palavra='held'
                              destino='Exercicio' 
                              imagem='Held'
                              palavrasCorretas={['segurei']} 
                              contexto={'Ele está com algo nas mãos, logo ele fazendo uma ação, a palavra é o verbo no passado'}
                              voltar={'Musica2'}/>the 

                       <Botao palavra='key' 
                              destino='Exercicio' 
                              imagem='key'
                              palavrasCorretas={['chave']}
                              voltar={'Musica2'}/>{"\n"}

          Next the <Botao palavra='walls' 
                          destino='Exercicio' 
                          imagem='walls'
                          palavrasCorretas={['paredes', 'parede']} 
                          voltar={'Musica2'}/> were closed on me{"\n"}

          And I discovered that my <Botao palavra='castles'
                                          destino='Exercicio' 
                                          imagem='castles'
                                          palavrasCorretas={['castelos', 'castelo']} 
                                          voltar={'Musica2'}/>stand{"\n"}

          Upon <Botao palavra='pillars' 
                      destino='Exercicio' 
                      imagem='pillars'
                      palavrasCorretas={['pilares', 'pilar']} 
                      voltar={'Musica2'}/> of salt and pillars of
                      
               <Botao palavra='sand'
                      destino='Exercicio' 
                      imagem='desert'
                      palavrasCorretas={['areia']} 
                      voltar={'Musica2'}/>{"\n"}{"\n"}

          I hear Jerusalem <Botao palavra='bells' 
                                  destino='Exercicio' 
                                  imagem='bells'
                                  palavrasCorretas={['sino', 'sinos']} 
                                  voltar={'Musica2'}/>are ringing{"\n"}

          Roman <Botao palavra='cavalry choirs' 
                       destino='Exercicio' 
                       imagem='cavalry choirs'
                       palavrasCorretas={['cavalaria', 'coros de cavalaria']} 
                       contexto={"Quando há muitos cavalos em conjunto"}
                       voltar={'Musica2'}/>are singing{"\n"}

          Be my <Botao palavra='mirror' 
                       destino='Exercicio' 
                       imagem='mirrors'
                       palavrasCorretas={['espelho', 'espelhos']} 
                       voltar={'Musica2'}/>, my

                <Botao palavra='sword' 
                       destino='Exercicio' 
                       imagem='sword'
                       palavrasCorretas={['espada']} 
                       voltar={'Musica2'}/>and

                <Botao palavra='shield' 
                       destino='Exercicio' 
                       imagem='shield'
                       palavrasCorretas={['escudo']}
                       voltar={'Musica2'}/>{"\n"}

          My missionaries in a foreign <Botao palavra='field' 
                                      destino='Exercicio' 
                                      imagem='green fields'
                                      palavrasCorretas={['campo', 'campos']}
                                      contexto={""}
                                      voltar={'Musica2'}/>{"\n"}{"\n"}

          For some reason I can't explain{"\n"}
          Once you'd gone, there was never{"\n"}
          Never an honest word{"\n"}
          That was when I ruled the world{"\n"}{"\n"}

          It was the <Botao palavra='wicked' 
                            destino='Exercicio' 
                            imagem='wicked '
                            palavrasCorretas={['perverso']} 
                            contexto={"Alguém com outras intenções do que mostra"}
                            voltar={'Musica2'}/>and

                     <Botao palavra='wild' 
                            destino='Exercicio' 
                            imagem='wild'
                            palavrasCorretas={['selvagem']} 
                            contexto={"Algo hostil, perigoso, geralmente dizemos algo como..."}
                            voltar={'Musica2'}/>wind{"\n"}


                   <Botao palavra='Blew Down' 
                          destino='Exercicio' 
                          imagem='Blew Down'
                          palavrasCorretas={['derrubar']} 
                          voltar={'Musica2'}/>the doors to let me in{"\n"}

                   <Botao palavra='Shattered' 
                          destino='Exercicio' 
                          imagem='shattered glass'
                          palavrasCorretas={['quebrado', 'quebrada', 'quebrar']} 
                          contexto={"Adjetivo de um objeto, quando cai por exemplo"}
                          voltar={'Musica2'}/>windows and the sound of 
                          
                   <Botao palavra='Drums' 
                          destino='Exercicio' 
                          imagem='drums'
                          palavrasCorretas={['tambor', 'tambores', 'bateria', 'baterias']} 
                          voltar={'Musica2'}/>{"\n"}

          People couldn't believe what I'd become{"\n"}{"\n"}

          Revolutionaries wait{"\n"}
          For my head on a <Botao palavra='silver plate' 
                                  destino='Exercicio' 
                                  imagem='silver plate'
                                  palavrasCorretas={['bandeja de prata', 'prato de prata']} 
                                  contexto={"Ela é feita de uma matéria diferente, relacionado a ouro"}
                                  voltar={'Musica2'}/>{"\n"}


          Just a <Botao palavra='puppet' 
                        destino='Exercicio' 
                        imagem='puppet'
                        palavrasCorretas={['marionete']} 
                        voltar={'Musica2'}/>on a lonely

                 <Botao palavra='string' 
                        destino='Exercicio' 
                        imagem='string'
                        palavrasCorretas={['corda']} 
                        voltar={'Musica2'}/>{"\n"}
                         

          Oh, who would ever want to be king?{"\n"}{"\n"}

          I hear Jerusalem bells are ringing{"\n"}
          Roman Cavalry choirs are singing{"\n"}
          Be my mirror, my sword and shield{"\n"}
          My missionaries in a foreign field{"\n"}{"\n"}

          For some reason I can't explain{"\n"}
          I know Saint Peter won't call my name{"\n"}
          Never an honest word{"\n"}
          But that was when I ruled the world{"\n"}{"\n"}

          Ooh, ooh, ooh, ooh{"\n"}{"\n"}

          Hear Jerusalem <Botao palavra='bells'
                                destino='Exercicio' 
                                imagem='bells'
                                palavrasCorretas={['sinos', 'sino']}
                                voltar={'Musica2'}/> are ringing{"\n"}

          Roman <Botao palavra='Cavalry choirs'
                       destino='Exercicio' 
                       imagem='Cavalry choirs'
                       palavrasCorretas={['cavalaria', 'coros de Cavalaria']}
                       voltar={'Musica2'}/> are singing{"\n"}

          Be my <Botao palavra='mirror'
                       destino='Exercicio' 
                       imagem='mirror'
                       palavrasCorretas={['espelho']}
                       voltar={'Musica2'}/>, my 
                       
                <Botao palavra='sword'
                       destino='Exercicio' 
                       imagem='sword'
                       palavrasCorretas={['espada']}
                       voltar={'Musica2'}/> and 
                       
                <Botao palavra='shield'
                       destino='Exercicio' 
                       imagem='shield'
                       palavrasCorretas={['escudo']}
                       voltar={'Musica2'}/>{"\n"}

          My missionaries in a foreign <Botao palavra='field'
                                      destino='Exercicio' 
                                      imagem='field'
                                      palavrasCorretas={['campo', 'campos']}
                                      voltar={'Musica2'}/>{"\n"}{"\n"}

          For some reason I can't explain{"\n"}
          I know Saint Peter won't call my name{"\n"}
          Never an honest word{"\n"}
          But that was when I ruled the world{"\n"}{"\n"}


        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Musica2;