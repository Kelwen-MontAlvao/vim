import React, {useState} from 'react';
import { View, Text, Button, StyleSheet, ScrollView, Animated, Switch, TouchableOpacity} from 'react-native';
import { useNavigation } from '@react-navigation/native'; 
import { Cabecalho } from '../componentes/Cabecalho';
import { BotaoVoltar } from '../componentes/Voltar';

export function Configuracoes() {
  const navigation = useNavigation(); 

  const [fontSize, setFontSize] = useState(16); // Tamanho da fonte
  const [highContrast, setHighContrast] = useState(false); // Modo de alto contraste
  const [isLargeText, setIsLargeText] = useState(false); // Texto grande

  // Animação de transição para o botão
  const [animation] = useState(new Animated.Value(1));

  const toggleButtonAnimation = () => {
    Animated.sequence([ 
      Animated.timing(animation, { 
        toValue: 1.1, 
        duration: 150, 
        useNativeDriver: true, 
      }),
      Animated.timing(animation, { 
        toValue: 1, 
        duration: 150, 
        useNativeDriver: true, 
      }),
    ]).start();
  };

  return (
    <>
      <Cabecalho />
      <View style={estilos.conteinerTitulo}>
        <Text style={estilos.titulo}>Acessibilidade:</Text>
      </View>

      <View style={[estilos.container, highContrast && estilos.highContrast]}>
        <Text style={[estilos.title, { fontSize }, highContrast && estilos.highContrastText]}>Configurações de Acessibilidade:</Text>

        {/* Tamanho da fonte */}
        <View style={estilos.settingContainer}>
          <Text style={[estilos.text, { fontSize }, highContrast && estilos.highContrastText]}>Tamanho da Fonte</Text>
          <TouchableOpacity
            style={estilos.button}
            onPress={() => setFontSize(fontSize === 16 ? 20 : 16)}
          >
            <Animated.Text style={[estilos.buttonText, { transform: [{ scale: animation }] }, highContrast && estilos.highContrastText]}>
              Alterar Tamanho
            </Animated.Text>
          </TouchableOpacity>
        </View>

        {/* Modo de Alto Contraste */}
        <View style={estilos.settingContainer}>
          <Text style={[estilos.text, { fontSize }, highContrast && estilos.highContrastText]}>Modo Alto Contraste</Text>
          <Switch value={highContrast} onValueChange={() => setHighContrast(!highContrast)} 
            trackColor={{ false: '#767577', true: '#767577' }} // Cor do fundo (track)
          />
        </View>

        {/* Texto Grande */}
        <View style={estilos.settingContainer}>
          <Text style={[estilos.text, { fontSize }, highContrast && estilos.highContrastText]}>Texto Grande</Text>
          <Switch value={isLargeText} onValueChange={() => setIsLargeText(!isLargeText)} 
            trackColor={{ false: '#767577', true: '#767577' }} // Cor do fundo (track)
          />
        </View>

        {/* Voltar */}
        <TouchableOpacity
          style={estilos.backButton}
          onPress={() => {navigation.navigate('Perfil')} }
        >
          <Text style={[estilos.backButtonText, highContrast && estilos.highContrastText]}>Voltar</Text>
        </TouchableOpacity>
      </View>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    padding: 10,
    textAlign: "center",
  },

  // Opções de acessibilidade

  container: {
    flex: 1,
    backgroundColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  
  highContrast: {
    backgroundColor: '#f5f5f5', // Cor de fundo escuro no modo de alto contraste
  },
  highContrastText: {
    color: '#000', // Texto branco no modo de alto contraste
  },

  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#fff', // Cor do texto padrão
  },
  settingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 20,
  },
  text: {
    fontSize: 16,
    color: '#fff', // Cor padrão do texto
  },
  button: {
    backgroundColor: '#2d7de6',
    padding: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  backButton: {
    backgroundColor: '#e15244',
    padding: 15,
    borderRadius: 5,
    marginTop: 20,
  },
  backButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default Configuracoes;
