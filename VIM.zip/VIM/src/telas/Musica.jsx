import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import YoutubePlayer from 'react-native-youtube-iframe';
import { Cabecalho } from '../componentes/Cabecalho';
import { Botao } from '../componentes/Botao';
import { BotaoVoltar } from '../componentes/Voltar';

export function Musica() {
  const [playing, setPlaying] = useState(false);

  const onStateChange = useCallback(state => {
    if (state === 'ended') {
      setPlaying(false);
      Alert.alert('A música acabou!');
    }
  }, []);

  const togglePlaying = useCallback(() => {
    setPlaying(prev => !prev);
  }, []);

  const bancodedadosId = 'azdwsXLmrHE'; // Extraia o ID do vídeo da URL

  return (
    <>
      <Cabecalho />

      <View style={estilos.videoContainer}>
        <YoutubePlayer
          height={200}
          play={playing}
          videoId={bancodedadosId}
          onChangeState={onStateChange}
        />
      </View>

      <ScrollView style={estilos.scrollContent}>
      <BotaoVoltar destino='home'/>
        <Text style={estilos.titulo}>
          Queen - Radio Ga Ga
        </Text>

        <Text style={estilos.letraMusica}>
          I'd <Botao palavra='sit' 
                     destino='Exercicio' 
                     imagem='sit' 
                     palavrasCorretas={['sentar', 'sentaria']}  
                     contexto=' '
                     voltar={'Musica'}
                     /> 

          alone and <Botao palavra='watch' 
                           destino='Exercicio' 
                           imagem='watching television' 
                           palavrasCorretas={['observar', 'assistir', 'observaria', 'assistiria']} 
                           contexto=' ' 
                           voltar={'Musica'}
                           />  

          your <Botao palavra='light' 
                      destino='Exercicio' 
                      imagem='lamp'
                      palavrasCorretas={['luz']}  
                      voltar={'Musica'}/>  {"\n"}

          My only friend through <Botao palavra='teenage' 
                                        destino='Exercicio' 
                                        imagem='teenage'
                                        palavrasCorretas={['adolescência', 'adolescente', 'adolescentes']}
                                        voltar={'Musica'}/>nights{"\n"}
                                        

          And everything I had to know{"\n"}
          I <Botao palavra='heard' 
                   destino='Exercicio' 
                   imagem='hearing' 
                   palavrasCorretas={['ouvir', 'ouviu', 'escutou']}  
                   voltar={'Musica'}/> it on my 
                                        
          <Botao palavra='radio' 
                 destino='Exercicio' 
                 imagem='radio'
                 palavrasCorretas={['radio', 'rádio']}  
                 voltar={'Musica'}/>{"\n"}{"\n"}

          You gave them all those old time <Botao palavra='stars' 
                                                  destino='Exercicio' 
                                                  imagem='star'
                                                  palavrasCorretas={['estrelas', 'estrela']}  
                                                  voltar={'Musica'}/>{"\n"}
          Through <Botao palavra='wars' 
                         destino='Exercicio' 
                         imagem='people in war'
                         palavrasCorretas={['guerras']}  
                         voltar={'Musica'}/> of worlds invaded by
                         
          <Botao palavra='Mars' 
                 destino='Exercicio' 
                 imagem='Mars Planet'
                 palavrasCorretas={['Marte', 'marte']}  
                 voltar={'Musica'}/>{"\n"}

          You made'em<Botao palavra='laugh' 
                              destino='Exercicio' 
                              imagem='Laughing'
                              palavrasCorretas={['rir', 'risada']}  
                              voltar={'Musica'}/>, you made 'em 
                              
          <Botao palavra='cry' 
                 destino='Exercicio' 
                 imagem='cry'
                 palavrasCorretas={['chorar']}  
                 voltar={'Musica'}/>{"\n"}

          You made us feel like we could <Botao palavra='fly' 
                                                destino='Exercicio' 
                                                imagem='flying'
                                                palavrasCorretas={['voar']}  
                                                voltar={'Musica'}/>{"\n"}{"\n"}

          So don't become some background noise{"\n"}
          A backdrop for the girls and boys{"\n"}
          Who just don't know or just don't care{"\n"}
          And just complain when you're not there{"\n"}{"\n"}

          You had your <Botao palavra='time' 
                              destino='Exercicio' 
                              imagem='time'
                              palavrasCorretas={['tempo']}  
                              voltar={'Musica'}/>{"\n"}
          You had the power{"\n"}
          You've yet to have your finest hour{"\n"}
          Radio{"\n"}{"\n"}

          All we hear is radio ga ga{"\n"}
          Radio goo goo{"\n"}
          Radio ga ga{"\n"}
          All we hear is radio ga ga{"\n"}
          Radio blah blah{"\n"}{"\n"}

          Radio, what's new?{"\n"}
          Radio, someone still loves you{"\n"}{"\n"}

          We watch the shows, we watch the stars{"\n"}
          On videos for hours and hours{"\n"}
          We hardly need to use our <Botao palavra='ears' 
                                           destino='Exercicio' 
                                           imagem='ears'
                                           palavrasCorretas={['Ouvidos', 'ouvidos']}  
                                           voltar={'Musica'}/>{"\n"}

          How music changes through the years{"\n"}{"\n"}

          Let's <Botao palavra='hope' 
                       destino='Exercicio' 
                       imagem='hope'
                       palavrasCorretas={['esperar', 'esperança']}  
                       voltar={'Musica'}/> you never leave, old friend {"\n"}

          Like all good things, on you we depend{"\n"}
          So <Botao palavra='Stick Around' 
                    destino='Exercicio' 
                    imagem='two people together'
                    palavrasCorretas={['fique por perto', 'fique perto', 'fique por aqui']}  
                    voltar={'Musica'}/>, 'cause we might miss you{"\n"}

          When we <Botao palavra='Grow Tired' 
                         destino='Exercicio' 
                         imagem='Grow Tired'
                         palavrasCorretas={['cansamos', 'cansar', 'cansaço']}  
                         voltar={'Musica'}/> of all this visual{"\n"}{"\n"}

          You had your time{"\n"}
          You had the power{"\n"}
          You've yet to have your finest hour{"\n"}
          Radio{"\n"}{"\n"}

          All we hear is radio ga ga{"\n"}
          Radio goo goo{"\n"}
          Radio ga ga{"\n"}
          All we hear is radio ga ga{"\n"}
          Radio goo goo{"\n"}
          Radio ga ga{"\n"}
          All we hear is radio ga ga{"\n"}
          Radio blah blah{"\n"}{"\n"}

          Radio, what's new?{"\n"}
          Someone still loves you{"\n"}{"\n"}

          Radio ga ga{"\n"}
          Radio ga ga{"\n"}
          Radio ga ga{"\n"}{"\n"}

          You had your time{"\n"}
          You had the power{"\n"}
          You've yet to have your finest hour{"\n"}
          Radio{"\n"}{"\n"}


        </Text>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
  },
  titulo: {
    color: '#fff',
    fontSize: 26,
    padding: 10,
    textAlign: 'center',
  },
  videoContainer: {
    backgroundColor: '#000', // fundo preto
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
    padding: 10,
  },
  letraMusica: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'left',
    marginHorizontal: 10, 
    marginVertical: 10,
  },
});

export default Musica;


