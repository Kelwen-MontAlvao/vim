import React from 'react';
import { View, Text, Image, ScrollView, StyleSheet, Button } from 'react-native';
import { Cabecalho } from '../componentes/Cabecalho';

export function Sobre({ navigation }) {
  return (
    <>
      <Cabecalho />

      <ScrollView style={estilos.scrollContent}>
        <View style={estilos.conteiner}>
          <View style={estilos.conteinerTitulo}>
            <Text style={estilos.titulo}>Sobre:</Text>
          </View>

          <View style={estilos.secao}>
            <Text style={estilos.descricao}>
              {"   "}O projeto visa utilizar a música como ferramenta para auxiliar na expansão do vocabulário da língua inglesa, tornando o aprendizado mais atraente e eficaz para os jovens. Através de letras de músicas cuidadosamente selecionadas, os alunos são expostos a uma variedade de vocabulário e expressões idiomáticas em um contexto autêntico e culturalmente rico.{"\n"}{"\n"}
              {"   "}O aplicativo permite que os usuários ouçam as músicas, leiam as letras e aprendam o significado das palavras e frases destacadas.{"\n"}{"\n"}
              {"   "}Outro aspecto importante do projeto é a inclusão de diferentes gêneros musicais, proporcionando uma experiência diversificada e atendendo aos gostos variados dos usuários. O objetivo é criar um ambiente de aprendizado envolvente e motivador, que incentive os jovens a praticarem inglês de forma regular e prazerosa.{"\n"}{"\n"}
              {" "}Com a integração de recursos multimídia e interatividade, o projeto busca transformar o aprendizado do inglês em uma experiência dinâmica e divertida, contribuindo para a melhoria das habilidades linguísticas dos jovens de maneira natural e intuitiva.
            </Text>
          </View>

          <View style={estilos.secao}>
            <Text style={estilos.titulo}>Integrantes:</Text>

            <View style={estilos.integrante}>
              <Image source={require('../imgs/neves.jpg')} style={estilos.foto} />
              <Text style={estilos.nome}>Gabriel Neves da Rocha</Text>
              <Text style={estilos.bio}>Programador Front-End, trabalha com suas ideias inovadoras e empolgantes de design e funcionalidades interessantes.</Text>
            </View>

            <View style={estilos.integrante}>
              <Image source={require('../imgs/gui.jpg')} style={estilos.foto} />
              <Text style={estilos.nome}>Guilherme Oliveira Costa</Text>
              <Text style={estilos.bio}>Programador Back-end, monitora os bancos de dados e APIs, fazendo o projeto funcionar.</Text>
            </View>

            <View style={estilos.integrante}>
              <Image source={require('../imgs/kel.jpg')} style={estilos.foto} />
              <Text style={estilos.nome}>Kelwen Gonçalves Mont'Alvão</Text>
              <Text style={estilos.bio}>Idealizadora do Projeto, Trabalha com a parte de documentação, organização e monitoramento do projeto.</Text>
            </View>
          </View>

          <View style={estilos.secao}>
            <Text style={estilos.titulo}>Ferramentas e APIs Utilizadas:</Text>

            <View style={estilos.toolsAndApis}>
              <Text style={estilos.descricao}>
                {"   "}Ferramentas:{"\n"}
                {"\n"}- React Native: Framework para desenvolvimento de aplicativos móveis usando JavaScript e React.
                {"\n"}- Visual Studio Code: Editor de código-fonte leve e poderoso, ideal para desenvolvimento.
                {"\n"}- Expo Go: Ferramenta para desenvolvimento e testes rápidos de aplicativos React Native.
                {"\n"}{"\n"}
                {"   "}APIs:{"\n"}
                {"\n"}- Pexels: API para acesso a uma vasta biblioteca de imagens gratuitas e de alta qualidade.
                {"\n"}- Free dictionary API: API para consulta de definições e exemplos de palavras em inglês.
                {"\n"}- Vagalume: API para acesso a letras de músicas, permitindo que o aplicativo exiba e estude as letras das canções.
              </Text>
            </View>
          </View>
          <View style={estilos.buttonContainer}>
            <Button
              title="Contate-nos"
              onPress={() => navigation.navigate('Contatenos')}
              color="#2d7de6"
            />
          </View>

          <View style={estilos.infoFinal}>
            <Text style={estilos.copyright}>
              &copy; 2024 Etec de Hortolândia - Este é um projeto acadêmico.
            </Text>
          </View>
        </View>
      </ScrollView>
    </>
  );
}

const estilos = StyleSheet.create({
  conteiner: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#000',
    padding: 20,
  },
  conteinerTitulo: {
    alignItems: 'center',
    backgroundColor: '#2d7de6',
    borderRadius: 10,
    paddingVertical: 10,
    marginBottom: 20,
    width: '100%',
  },
  titulo: {
    color: "#fff",
    fontSize: 26,
    textAlign: "center",
  },
  descricao: {
    color: "#fff",
    fontSize: 18,
    textAlign: 'justify',
    paddingHorizontal: 20,
  },
  integrante: {
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 20,
    backgroundColor: '#1a1a1a',
    borderRadius: 10,
    padding: 15,
    width: '100%',
    alignItems: 'center',
    elevation: 5,
  },
  foto: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 10,
  },
  nome: {
    color: "#fff",
    fontSize: 20,
    fontWeight: 'bold',
  },
  bio: {
    color: "#fff",
    fontSize: 16,
    textAlign: 'center',
    paddingHorizontal: 10,
  },
  scrollContent: {
    flex: 1,
    backgroundColor: '#000',
  },
  secao: {
    marginBottom: 30,
    width: '100%',
  },
  toolsAndApis: {
    backgroundColor: '#1a1a1a',
    borderRadius: 10,
    padding: 15,
    elevation: 5,
  },
  infoFinal: {
    marginTop: 30,
    alignSelf: 'center',
  },
  copyright: {
    color: "#fff",
    fontSize: 14,
    fontStyle: 'italic',
  },
  buttonContainer: {
    marginTop: 20,
    width: '100%',
    alignItems: 'center',
  },
});

export default Sobre;
