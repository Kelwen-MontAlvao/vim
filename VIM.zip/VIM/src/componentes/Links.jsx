import {StyleSheet, Image, Text, TouchableOpacity, ImageBackground} from 'react-native'
import {useNavigation} from '@react-navigation/native'

export function Link({titulo, destino}){

    const navegacao = useNavigation()

    const navegar = rota => {
        navegacao.navigate(rota)
    }

    return(
        <TouchableOpacity 
            style={estilos.conteiner}
            onPress={() => navegar(destino)}
        >

            <Text style={estilos.titulo}> {titulo} </Text>
        </TouchableOpacity>
    )
}

const estilos = StyleSheet.create({
    conteiner:{
        width: 1000
    },

    titulo: {
        color: "#fff",
        fontSize: 26,
        padding: 10,
        textAlign: "center"
    }
})