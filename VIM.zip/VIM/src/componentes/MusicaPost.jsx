// MusicaPost.js
import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

export function MusicaPost({ titulo, artista, imagem }) {
    return (
        <View style={styles.postContainer}>
            <Image source={{ uri: imagem }} style={styles.image} />
            <View style={styles.textContainer}>
                <Text style={styles.titulo}>{titulo}</Text>
                <Text style={styles.artista}>{artista}</Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    postContainer: {
        flexDirection: 'row',
        backgroundColor: '#1e1e1e',
        padding: 10,
        marginVertical: 5,
        borderRadius: 5,
    },
    image: {
        width: 60,
        height: 60,
        borderRadius: 30,
    },
    textContainer: {
        marginLeft: 10,
        justifyContent: 'center',
    },
    titulo: {
        color: '#fff',
        fontSize: 18,
        fontWeight: 'bold',
    },
    artista: {
        color: '#ccc',
        fontSize: 16,
    },
});
