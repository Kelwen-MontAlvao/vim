import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export function Post({ titulo, conteudo }) {
  return (
    <View style={styles.post}>
      <Text style={styles.titulo}>{titulo}</Text>
      <Text style={styles.conteudo}>{conteudo}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  post: {
    marginBottom: 20,
    padding: 15,
    backgroundColor: '#333', 
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  titulo: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#fff', 
  },
  conteudo: {
    fontSize: 16,
    color: '#ddd', 
  },
});
