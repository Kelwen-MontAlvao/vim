import {StyleSheet, Image, Text, TouchableOpacity, ImageBackground} from 'react-native'
import {useNavigation} from '@react-navigation/native'

export function Cartao({titulo, imagem, destino}){

    const navegacao = useNavigation()

    const navegar = rota => {
        navegacao.navigate(rota)
    }

    return(
        <TouchableOpacity 
            style={estilos.conteiner}
            onPress={() => navegar(destino)}
        >

            <ImageBackground 
                style={estilos.imagemCartao}
                source={imagem}
            >

            <Text style={estilos.titulo}> {titulo} </Text>
            
            </ImageBackground>

        </TouchableOpacity>
    )
}

const estilos = StyleSheet.create({
    conteiner: { 
        backgroundColor: '#fff' ,
        opacity: 1,
        height: 75,
        width: 75,
        marginHorizontal: 7,
        borderRadius: 50,
        overflow: 'hidden',
    },

    imagemCartao: {
        width: '100%',
        height: 100,
        objectFit: 'cover'
    },
    
    titulo: {
        textAlign: 'center',
        fontSize: 16,
        fontWeight: '900',
        marginTop: 25,
        color: '#fff',
    }
})