import React from 'react';
import { TouchableOpacity, StyleSheet, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';

export function BotaoRetorno() { 
  const navigation = useNavigation();

  const handlePress = () => {
    navigation.goBack(); 
  };

  return (
    <TouchableOpacity onPress={handlePress} style={styles.button}>
      {/* Adicione um ícone ou apenas texto */}
      <Image 
        source={require('../../assets/voltar.png')} // Imagem do ícone de voltar
        style={styles.icon}
      />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row',
    alignContent: 'center',
    alignItems: 'center',
    margin: 10,
  },

  icon: {
    width: 40,
    height: 40,
  },
});
