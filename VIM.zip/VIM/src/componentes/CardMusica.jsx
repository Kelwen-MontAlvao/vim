import {StyleSheet, Image, Text, TouchableOpacity, ImageBackground} from 'react-native'
import {useNavigation} from '@react-navigation/native'

export function CardMusica({titulo, titulo2, imagem, destino}){

    const navegacao = useNavigation()

    const navegar = rota => {
        navegacao.navigate(rota)
    }

    return(
        <TouchableOpacity 
            style={estilos.conteiner}
            onPress={() => navegar(destino)}
        >

            <Image 
                style={estilos.imagemCartao}
                source={imagem}
            />

            <Text style={estilos.titulo}> {titulo} </Text>
            <Text style={estilos.titulo2}> {titulo2} </Text>
        </TouchableOpacity>
    )
}

const estilos = StyleSheet.create({
    conteiner: { 
        backgroundColor: '#fff',
        height: 150,
        width: 150,
        marginTop: 20,
        marginHorizontal: 10,
        borderRadius: 10,
        overflow: 'hidden'
    },

    imagemCartao: {
        width: '100%',
        height: 100,
        objectFit: 'cover'
    },

    titulo: {
        textAlign: 'center',
        fontSize: 16,
        fontWeight: '900',
        marginTop: 4
    },

    titulo2: {
        textAlign: 'center',
        fontSize: 16,
        fontWeight: '900',
        marginTop: -2
    }
})