import {StyleSheet, Image, Text, TouchableOpacity, ImageBackground} from 'react-native'
import {useNavigation} from '@react-navigation/native'

export function Botao({palavra, imagem, destino, palavrasCorretas, contexto, voltar}){

    const navegacao = useNavigation()

    const handlePress = () => {
        navegacao.navigate(destino, {
            palavraInterativa: 
            palavra, 
            imagem, 
            palavrasCorretas, 
            contexto,
            voltar
        });
    };

    return(
    <TouchableOpacity onPress={handlePress} style={estilos.conteiner}>
        <Text style={estilos.palavra}> {palavra} </Text>
    </TouchableOpacity>
    )
}

const estilos = StyleSheet.create({
    conteiner:{
        flex: 1,
        flexDirection: 'row',
        alignContent:'center',
        alignItems: 'center', 
    },

    palavra: {
        color: "#9dc3ff",
        fontSize: 20,
        textAlign: "center",
        fontWeight: 'bold',
        verticalAlign: 'bottom',
        marginBottom: -5
    }
})