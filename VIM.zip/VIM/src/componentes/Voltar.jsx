import React from 'react';
import { TouchableOpacity, Text, StyleSheet, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';

export function BotaoVoltar({ destino }) {
  const navigation = useNavigation();

  const handlePress = () => {
    navigation.navigate(destino); // Volta para a tela anterior
  };

  return (
    <TouchableOpacity onPress={handlePress} style={styles.button}>
      {/* Adicione um ícone ou apenas texto */}
      <Image 
        source={require('../../assets/voltar.png')} // Imagem do ícone de voltar
        style={styles.icon}
      />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row',
    alignContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    margin: 10,
    backgroundColor: '#333',
    width: 70,
    height: 50,
    borderRadius: 10
  },

  icon: {
    width: 40,
    height: 40,
    marginLeft: 15
  },
});
