import { View, Text, StyleSheet, Image } from "react-native"

export function Cabecalho({}){
    return(
        <View style={estilos.header}> 
            <Text style={estilos.texto}> VIM </Text>
            <Image source={require('../../assets/logo.png')} style={estilos.logo}/>
            
            
        </View>
     
    )
}

const estilos = StyleSheet.create({
    header: {
        backgroundColor: '#000',
        height: 60,  
        opacity: 1,
        paddingHorizontal: 20,
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between',
    },

    texto:{
        color: '#fff',
        fontSize: 45
    },  

    image:{
        width: 40,
        height: 40,
    },

    logo: {
        width: 100,
        height: 100,
        marginRight: -15,
        marginTop: 10
    }
  });