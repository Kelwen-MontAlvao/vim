import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useMusic } from '../MusicContext';

export function CardMusicaSaves({ titulo, titulo2, imagem, destino }) {
  const { removeMusic } = useMusic();
  const navigation = useNavigation();

  const handleRemove = () => {
    removeMusic({ nome: titulo, artista: titulo2 });
  };

  const handleNavigate = () => {
    navigation.navigate(destino);
  };

  return (
    <View style={estilos.card}>
      <TouchableOpacity onPress={handleNavigate}>
        <Image source={imagem} style={estilos.imagem} />
        <Text style={estilos.titulo}>{titulo}</Text>
        <Text style={estilos.artista}>{titulo2}</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={handleRemove} style={estilos.botaoRemover}>
        <Text style={estilos.textoBotao}>Excluir</Text>
      </TouchableOpacity>
    </View>
  );
}

const estilos = StyleSheet.create({
  card: {
    backgroundColor: '#333',
    borderRadius: 8,
    margin: 10,
    width: 150,
    alignItems: 'center',
    padding: 10,
  },
  imagem: {
    width: 120,
    height: 120,
    borderRadius: 8,
  },
  titulo: {
    color: '#fff',
    fontSize: 16,
    marginTop: 5,
  },
  artista: {
    color: '#bbb',
    fontSize: 14,
  },
  botaoRemover: {
    marginTop: 10,
    backgroundColor: '#f00',
    padding: 10,
    borderRadius: 5,
  },
  textoBotao: {
    color: '#fff',
    fontWeight: 'bold',
  },
});
