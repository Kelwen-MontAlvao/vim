import { View, TextInput, StyleSheet } from 'react-native';
import React, { useState } from 'react';
import { MaterialIcons } from '@expo/vector-icons'

export function BarraPesquisa(){
  const [Pesquisar, setPesquisar] = useState('');

  return (
    <View style={estilos.container}>

      <TextInput
        style={estilos.input}
        placeholder="Pesquisar..."
        value={Pesquisar}
        onChangeText={(text) => setPesquisar(text)}
      />

      <MaterialIcons name="search" size={25} color={'rgba(255, 255, 255, 0.5)'}/>
    </View>
  );
};

const estilos = StyleSheet.create({
    container: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.5)',
        borderRadius: 50,
        paddingHorizontal: 10,
        paddingVertical: 5,
        margin: 10,
    },

    icone: {
        marginRight: 10,
    },

    input: {
        flex: 1,
        fontSize: 18,
        paddingLeft: 10,
    },
});
