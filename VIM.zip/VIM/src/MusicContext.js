import React, { createContext, useState, useContext } from 'react';

const MusicContext = createContext();

export const MusicProvider = ({ children }) => {
  const [savedMusics, setSavedMusics] = useState([]);

  const saveMusic = (musica) => {
    setSavedMusics((prevMusics) => [...prevMusics, musica]);
  };

  const removeMusic = (musica) => {
    setSavedMusics((prevMusics) =>
      prevMusics.filter(
        (item) =>
          item.nome !== musica.nome || 
          item.artista !== musica.artista 
      )
    );
  };

  return (
    <MusicContext.Provider value={{ savedMusics, saveMusic, removeMusic }}>
      {children}
    </MusicContext.Provider>
  );
};

export const useMusic = () => useContext(MusicContext);
