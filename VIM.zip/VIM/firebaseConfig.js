import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth, initializeAuth, getReactNativePersistence } from "firebase/auth";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getStorage } from 'firebase/storage'; 

const firebaseConfig = {
  apiKey: "AIzaSyAHy0g-2XtBI9C7NC3TZDOQ9g6oI1HhCYo",
  authDomain: "vim-alpha-1941d.firebaseapp.com",
  projectId: "vim-alpha-1941d",
  storageBucket: "vim-alpha-1941d.appspot.com",
  messagingSenderId: "758340990785",
  appId: "1:758340990785:web:fbb0aa2808c1b237f793c0",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage)
});
const storage = getStorage(app);

export { db, auth, storage };
