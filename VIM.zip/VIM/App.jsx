import React from 'react';
import { StatusBar, View, StyleSheet } from 'react-native';
import { RotasStack } from './src/rotas/RotasStack';
import { MusicProvider } from './src/MusicContext'; 

export default function App() {
  return (
    <MusicProvider>
      <View style={estilos.conteiner}>
        <StatusBar barStyle='default' />
        <RotasStack />
      </View>
    </MusicProvider>
  );
}

const estilos = StyleSheet.create({
  conteiner: {
    flex: 1,
  },
});
